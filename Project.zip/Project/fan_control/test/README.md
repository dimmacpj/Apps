# File Setup

## Unity
Unity is the test harness used for testing. To learn more about it, follow the link below. 

Why Unity / A test Harness / Test Framework?

Say you want to test the following function,

```
int add_2(int a, int b)
{
	return a+b;
}
```
To test this, one usually will do,

```
int main()
{
  if (add_2(5,10) == 15)
  {
    printf("Test Successfull\n");
  }
  else
  {
    printf("Error: expected %d, got %d"\n, 15, add_2(5,10));
  } 
}

```
But, by using Unity, this is made lot simpler,

```
int main()
{
	TEST_ASSERT_EQUAL_INT(15, add_2(5,10));
}
```
This may not seem like much help, but once you start writing more test cases, it saves significant time and effort. For example, say you wanted to test if the function works with negative values, you will need to write a whole new set of if-else statements whereas using Unity, can get away with just a single line. 

Download unity from http://www.throwtheswitch.org/unity, can either download a zip source file or git clone.
Place unity folder in the test folder (discussed below).
If want to place this elsewhere, just be careful to update the includes in the test files and the makefile dedicated to test. 

## Test Folder

Create a test folder also in the main directory.

This test folder is to contain everything to do with tests. It will include the test framework (unity), will also contain all source test folders for a source file under test. For example, say you want to write a test for the temperature.c function, you would need to create a folder for it, say, temperature_test (this can have any name) and inside this temperature_test folder you will have the test files as shown below, another example for ena_maths.c is also shown. 


```
.
├── firmware
│   └── ena_common
│       └── temperature.c
├── test
│   └── temperature_test
│       └── Testtemperature.c
│   └── mathFunc_test
│       └── Testena_maths.c
│   ├── unity
│   ├── makefile_test.mk
│   └── README.md
└── README.md
```
## Test file

Test files go inside test folder (as shown above in the tree diagram) and follow a naming convention so that the makefile can automatically find the test source file. The convention to be followed is as follows,

If the source under test is named `temperature.c` then the test source file must be named `Testtemperature.c` i.e., `Test(source under test file name).c`

If the source file under test has multiple functions, the same test file can be used. If want to use different test source file, place in the same test folder. As unity will run every test inside a folder given that it follows convention.

## Makefile

To run the test automatically, makefile is used. Unity provides a makefile which can be used without much modifications. The important parts where modifications are needed are discussed below. For a more thorough treatment visit http://www.throwtheswitch.org/build/make which explains in detail all of the code. Incidently, the makefile is located inside the `test` folder as shown in the tree diagram above. 

The only bits that have to be modified inside the makefile is the PATH variables. If you followed the above instructions regarding where to place the files then you would have the PATHS as shown below, if not, then they must be modified accordingly. These PATH locations are relative to the makefile. For this example, I am testing the temperature function located inside `temperature.c` which is located in the `ena_common` folder inside `firmware` folder. The test file is named `Testtemperature.c`. 


`PATHU = ../unity/src/`       : location of unity source and header file

`PATHS = ../firmware/ena_common/` : location of source file under test, this will need to be changed if not testing source files located in the ena_common folder. 

`PATHT = temperature_test` : location of Testtemperature.c

Everytime you want to change the source file under test, you will need to edit the PATHT which can be a hassle and therefore a more efficient process using variables is undertaken as follows, 

`TEST_FILE = some_default_test_folder_name`

`PATHT = ./$(TEST_FILE)/`

Now when you run make in command line add `TEST_FILE=some_test_folder_name` and it will overwrite the default. 

For example,

`make test TEST_FILE=some_test_folder_name`. If the TEST_FILE is not specified, it will just run some_default_test_folder_name. 

And that is all.

However, to make things easier, this makefile is linked to the main makefile located in the main directory. So that you can run test while in the main directory. To do this, add the following section into the main makefile. 

```
#test stuff------------------------------------------------------

MAKEFILE_NAME = makefile_test.mk
TEST_DIR = test

.PHONY: testrun
.PHONY: testclean

testrun:
	$(MAKE) -C ./$(TEST_DIR)/ -f $(MAKEFILE_NAME) test

testclean:
	$(MAKE) -C ./$(TEST_DIR)/ -f $(MAKEFILE_NAME) clean

#-------------------------------------------------------------
```
To avoid confusion the makefile is named differently as to differentiate it from the main makefile. If you wish to call the test makefile separately, go to the directory it is contained in and type the following,

`make -f makefile_test.mk TEST_FILE=some_test_folder_name`
# Examples

## Example 1: Temperature function 
Assuming you have setup everything mentioned above,

1st) Create a folder to hold the test source file.

`test->temperature_test`

2nd) Create a .c file for the test inside the folder mentioned right above. Remember to follow convention mentioned previously. 

`test->temperature_test->Testtemperature.c`

3rd) inside the test source file, include the required headers. Typically this includes only the unity header and the source file under test header. 

```
#include "../../unity/src/unity.h"
#include "../../firmware/ena_common/temperature.h"
```
4th) Next stage is writing the test. Essentially you are testing if the function functions as expected. 

> "The goal is not to prove that the code will work in the hardware, but that the tests do show that the code meets one's understanding of what the hardware is supposed to do." 

To come up with the test cases, ask a few questions as follows,

Q1) What does the temperature function do?
1) Takes in unsigned integer ADC output and an adress to be pointed by a float32_t pointer. 
2) Uses the ADC output to determine a index value to index into a LUT.
3) After getting the value from the LUT, it updates the value at the adress pointed to by the float32_t pointer
4) If the ADC value is within range, the function returns 1 else returns 0. 

Q2) What checks does the temperature function perform?
1) checks if the ADC output is within a certain range. 
2) checks if the fraction between the index entries is greater than 0. 

Q3) Are there any math operations where potentially the denominator can be zero or cause overflow or underflow? or indexing out of range?
1) There are two division operation but the denominator is a const which is not zero therefore impossible for divide by zero error.
2) There is a operation where uint16_t temp = adc_val - ntc_adc_offset but the lowest it can get is 0 so is safe from underflow. The higest it can get is 3840 so safe from overflow. 

Now test if it does the things mentioned above. 

```
float32_t temperature;

void test_ntc_lookup_WithinRangeADC(void)
{
  //boundary values within range
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(192, &temperature));
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(4032, &temperature));
  //arbitary values within range
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(500, &temperature));
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(3000, &temperature));

}

```
`float32_t` is a custom data type used by the tempeature function and can be used for the test. 

A test function is to test one idea, in this example it is testing the function's functionality when given sensible values. 

The naming of the function should follow convention `test_funcName_ideaOfTest` so when a test fails it will be easier to identify what exactly failed. Because as soon as a Test statement (for example TEST_ASSER_EQUAL..) fails, other test statements in the same function are not run but moves to other test function if any. These conventions are further shown practically below,

```
void test_ntc_lookup_OutOfRangeADC(void)
{
  //boundary values outside range
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(191, &temperature));
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(4033, &temperature));
  //arbitary values outside range
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(0, &temperature));
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(5000, &temperature));
}
```
```
void test_ntc_lookup_UpdateOfTestPointer(void)
{
  //temp within range, expect temp to change
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(192, &temperature));
  TEST_ASSERT_EQUAL_FLOAT((float32_t)157.3714, temperature);
  //temp out of range, expect temp to be the non-sensicle -100deg
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(0, &temperature));
  TEST_ASSERT_EQUAL_FLOAT(-100, temperature);
}
```
Unity requires you define the setUp and tearDown functions as shown below. In this case they were of no use for this is a simple function. 
```
void setUp (void) {} /* Is run before every test, put unit init calls here. */
void tearDown (void) {} /* Is run after every test, put unit clean-up calls here. */
```
And finally the main function which calls the test functions,
```
int main(void)
{
  UNITY_BEGIN();
  RUN_TEST(test_ntc_lookup_WithinRangeADC);
  RUN_TEST(test_ntc_lookup_OutOfRangeADC);
  RUN_TEST(test_ntc_lookup_UpdateOfTestPointer);
  return UNITY_END();
}
```
And that is all. To run the test from the main directory,

`make testrun TEST_FILE=temp_test`

else, go into the test directory and,

`make -f makefile_test.mk TEST_FILE=temp_test`

To clean the test results / outputs from the main directory do,

`make testclean`

or if in the test directory,

`make -f makefile_test clean`

## Example 2: static functions or static inline or __STATIC_FORCEINLINE

When function is declared as `static`, `static inline` or `__STATIC_FORCEINLINE`, can be tested without any further modification.
(For `__STATIC_FORCEINLINE` will say undeclared if the source file doesn't have include/access to cmsis_compiler.h)

functions declared `static` are restricted to the file where they are declared. There can be two cases of this,

A) `static` function is located in the `.h` file : follow the same procedure as for the temperature function. As the `.h` file is already included in the test file it makes no difference. 
B) `static` function is located in the `.c` file : there are few ways to go about this, some require modifications to the production code while others don't. The best one to use varies by situation. Therefore make judgment as required. Three common approaches are described as follows, 

### 1) Make a wrapper function

```
// mymodule.c
#include "mymodule.h"

...

static int add(int a, int b) {
    return a + b;
}

...

// Wrapper function for testing the static function
int wrapper_add(int a, int b) {
    return add(a, b);
}
```

```
#ifndef MYMODULE_H
#define MYMODULE_H

...

// Declaration for the wrapper function
int wrapper_add(int a, int b);

...

#endif // MYMODULE_H

```

and so the test file would be,

```
// test_mymodule.c
#include "unity.h"
#include "mymodule.h"

...

void test_add() {
    TEST_ASSERT_EQUAL_INT(5, wrapper_add(2, 3));
    // Add more test cases as needed
}

...

int main() {
    UNITY_BEGIN();
    RUN_TEST(test_add);  // Test the static function indirectly
    return UNITY_END();
}
```

### 2) Use Pre-Processor Directives

```
// mymodule.c
#include "mymodule.h"

...

#ifndef TEST
static
#endif
int add(int a, int b) {
    return a + b;
}

...

```

```
#ifndef MYMODULE_H
#define MYMODULE_H

...

// Declaration for the static function (visible during testing)
#ifdef TEST
int add(int a, int b);
#endif

...

#endif // MYMODULE_H

```

and so the test file is as follows,

```
// test_mymodule.c
#define TEST  // Define TEST to expose static functions
#include "unity.h"
#include "mymodule.h"

void test_add() {
    TEST_ASSERT_EQUAL_INT(5, add(2, 3));
    // Add more test cases as needed
}

int main() {
    UNITY_BEGIN();
    RUN_TEST(test_add);
    return UNITY_END();
}

```

### 3) Include the source file. 