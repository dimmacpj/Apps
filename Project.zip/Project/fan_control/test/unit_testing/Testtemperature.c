#include "../unity/src/unity.h"
#include "../../firmware/ena_common/temperature.h"
#include "../../firmware/ena_common/ena_datatype.h"

float32_t temperature;


void test_ntc_lookup_WithinRangeADC(void)
{
  //boundary values within range
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(192, &temperature));
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(4032, &temperature));
  //arbitary values within range
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(500, &temperature));
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(3000, &temperature));

  // for (int i=192; i<=(4032); i++)
  // {
  //   TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(i, &temperature));
  // }

}

void test_ntc_lookup_OutOfRangeADC(void)
{
  //boundary values outside range
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(191, &temperature));
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(4033, &temperature));
  //arbitary values outside range
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(0, &temperature));
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(5000, &temperature));

  // for (int i=0; i<(192); i++)
  // {
  //   TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(i, &temperature));
  // }
  // for (int i=4033; i<(65536); i++)
  // {
  //   TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(i, &temperature));
  // }
}

void test_ntc_lookup_UpdateOfTestPointer(void)
{
  //temp within range, expect temp to change
  TEST_ASSERT_EQUAL_UINT8(1, ntc_lookup(192, &temperature));
  TEST_ASSERT_FLOAT_WITHIN(0.0001F, 157.3714F, temperature);
  //temp out of range, expect temp to be the non-sensicle -100deg
  TEST_ASSERT_EQUAL_UINT8(0, ntc_lookup(0, &temperature));
  TEST_ASSERT_EQUAL_FLOAT(-100, temperature);
  
}

void setUp (void) {} 
void tearDown (void) {} 

int main(void)
{
  UNITY_BEGIN();
  RUN_TEST(test_ntc_lookup_WithinRangeADC);
  RUN_TEST(test_ntc_lookup_OutOfRangeADC);
  RUN_TEST(test_ntc_lookup_UpdateOfTestPointer);
  return UNITY_END();
}