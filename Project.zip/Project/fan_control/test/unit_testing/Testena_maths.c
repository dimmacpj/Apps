#include "../../firmware/ena_common/ena_datatype.h"
#include "../unity/src/unity.h"
#include "../../firmware/ena_common/ena_maths.h"

#include "../fff/fff.h"

void setUp (void) {}
void tearDown (void) {} 


//---------------FUNCTION UNDER TEST------------------//
//------------ff_PI_controller(const tPI_modes t_mode, const float f_error, volatile tPIsat *tPIsat_params,
//                       const float f_ll, const float f_ul)-------//

void test_ff_PI_controller_PIMODE_PI_NORMAL(void)
{
  const float f_error = 0;
  const float f_ll = 1;
  const float f_ul = 3;
  volatile tPIsat satur;
  satur.f_integrator = 1.5;
  const tPI_modes PIMODE = PI_NORMAL;

  //the returned value should be within the upper and lower limit
  TEST_ASSERT_FLOAT_WITHIN(2, 3, ff_PI_controller(PIMODE, f_error, &satur, f_ll, f_ul));
  TEST_ASSERT_FLOAT_WITHIN(2, 1, ff_PI_controller(PIMODE, f_error, &satur, f_ll, f_ul));

}

void test_ff_PI_controller_PIMODE_PI_HOLD(void)
{
  const float f_error = 1.7;
  const float f_ll = 1;
  const float f_ul = 3;
  volatile tPIsat satur;
  satur.f_integrator = 1;
  const tPI_modes PIMODE = PI_HOLD;

  //expect the f_integrator value to be returned an unchanged
  TEST_ASSERT_EQUAL_FLOAT(satur.f_integrator, ff_PI_controller(PIMODE, f_error, &satur, f_ll, f_ul));

}

void test_ff_PI_controller_PIMODE_PI_DISABLE(void)
{
  const float f_error = 1.7;
  const float f_ll = 1;
  const float f_ul = 3;
  volatile tPIsat satur;
  satur.f_integrator = 1;
  const tPI_modes PIMODE = PI_DISABLE;

  //expect the return value to be zero and the f_integrator to be zero
  TEST_ASSERT_EQUAL_FLOAT(0, ff_PI_controller(PIMODE, f_error, &satur, f_ll, f_ul));
  TEST_ASSERT_EQUAL_FLOAT(0, satur.f_integrator);

}

void test_ff_PI_controller_PIMODE_PI_INIT(void)
{
  const float f_error = 1.7;
  const float f_ll = 1;
  const float f_ul = 3;
  volatile tPIsat satur;
  satur.f_integrator = 1;
  const tPI_modes PIMODE = PI_INIT;

  //same as for the case of PI_DISABLE i.e., expect the return value to be zerp and the f_integrator to be zero
  TEST_ASSERT_EQUAL_FLOAT(0, ff_PI_controller(PIMODE, f_error, &satur, f_ll, f_ul));
  TEST_ASSERT_EQUAL_FLOAT(0, satur.f_integrator);

}


//---------------FUNCTION UNDER TEST------------------//
//------------float third_order_integrator(float f_uk, t3int *t3int_uk, const float f_Ts_12)-------//
// y(n) = y(n-1) + Ts/12*[23u(n-1)-16u(n-2)+5u(n-3)]
void test_third_order_integrator_uk1_uk2_Zero_Zero(void)
{
  t3int t3int_uk;
  //truth table style
  const float f_Ts_12_zero=0;
  const float f_Ts_12_one=1;
  float f_uk_zero=0;
  float f_uk_one= 1.0 * 12.0;

  //f_uk =0. Ts/12 = 0 : expect 0
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(0, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_zero));

  //f_uk = 1 , Ts/12 = 0 : expect 0
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(0, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_zero));

  //f_uk = 0 , Ts/12 = 1 : expect 0
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(0, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_one));

  //f_uk = 1 , Ts/12 = 1 : expect 23
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(23, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_one));

}

void test_third_order_integrator_uk1_uk2_One_Zero(void)
{
  t3int t3int_uk;
  //truth table style
  const float f_Ts_12_zero=0;
  const float f_Ts_12_one=1;
  float f_uk_zero=0;
  float f_uk_one = 1.0 * 12.0;

  //f_uk =0. Ts/12 = 0 : expect 7
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(7, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_zero));

  //f_uk = 1 , Ts/12 = 0 : expect 7
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(7, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_zero));

  //f_uk = 0 , Ts/12 = 1 : expect 7
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(7, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_one));

  //f_uk = 1 , Ts/12 = 1 : expect 30
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 0;
  TEST_ASSERT_EQUAL_FLOAT(30, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_one));
}

void test_third_order_integrator_uk1_uk2_Zero_One(void)
{
  t3int t3int_uk;
  //truth table style
  const float f_Ts_12_zero=0;
  const float f_Ts_12_one=1;
  float f_uk_zero=0;
  float f_uk_one = 1.0 * 12.0;

  //f_uk =0. Ts/12 = 0 : expect 5
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(5, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_zero));

  //f_uk = 1 , Ts/12 = 0 : expect 5
  //prevent overwriting
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(5, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_zero));

  //f_uk = 0 , Ts/12 = 1 : expect 5
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(5, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_one));

  //f_uk = 1 , Ts/12 = 1 : expect 28
  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(28, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_one));
}

void test_third_order_integrator_uk1_uk2_One_One(void)
{
  t3int t3int_uk;
  //truth table style
  const float f_Ts_12_zero=0;
  const float f_Ts_12_one=1;
  float f_uk_zero=0;
  float f_uk_one = 1.0 * 12.0;

  //f_uk =0. Ts/12 = 0 : expect 12
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(12, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_zero));

  //f_uk = 1 , Ts/12 = 0 : expect 12
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(12, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_zero));

  //f_uk = 0 , Ts/12 = 1 : expect 12
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(12, third_order_integrator(f_uk_zero, &t3int_uk, f_Ts_12_one));

  //f_uk = 1 , Ts/12 = 1 : expect 35
  t3int_uk.f_uk_1 = 1;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(35, third_order_integrator(f_uk_one, &t3int_uk, f_Ts_12_one));
}

void test_third_order_integrator_Integration(void)
{
  //repeat calls with the same initilized values, expect f_uk_1, f_uk_2 to change as they are shifted in the said function
  t3int t3int_uk;
 
  const float f_Ts_12=1;

  float f_uk = 1.0 * 12.0;

  t3int_uk.f_uk_1 = 0;
  t3int_uk.f_uk_2 = 1;
  TEST_ASSERT_EQUAL_FLOAT(28, third_order_integrator(f_uk, &t3int_uk, f_Ts_12));
  TEST_ASSERT_EQUAL_FLOAT(1, t3int_uk.f_uk_1);
  TEST_ASSERT_EQUAL_FLOAT(0, t3int_uk.f_uk_2);

  TEST_ASSERT_EQUAL_FLOAT(30, third_order_integrator(f_uk, &t3int_uk, f_Ts_12));
  TEST_ASSERT_EQUAL_FLOAT(2, t3int_uk.f_uk_1);
  TEST_ASSERT_EQUAL_FLOAT(1, t3int_uk.f_uk_2);

  TEST_ASSERT_EQUAL_FLOAT(42, third_order_integrator(f_uk, &t3int_uk, f_Ts_12));
  TEST_ASSERT_EQUAL_FLOAT(3, t3int_uk.f_uk_1);
  TEST_ASSERT_EQUAL_FLOAT(2, t3int_uk.f_uk_2);
}

//---------------FUNCTION UNDER TEST------------------//
//------------static inline void first_order_filter(float f_uk, volatile float *pf_yk, const float f_a0)-------//
void test_first_order_filter_functionality(void)
{
  float f_uk =1.0f;
  const float f_a0 = 1.0f;
  volatile float f_yk;
  first_order_filter(f_uk, &f_yk, f_a0);
  TEST_ASSERT_EQUAL_FLOAT(1, f_yk);
  // Test with initial value of 0
  f_uk = 2.0f;
  f_yk = 0.0f;
  first_order_filter(f_uk, &f_yk, f_a0);
  TEST_ASSERT_EQUAL_FLOAT(2, f_yk);
  

  // Test with initial value of 1
  f_yk = 1.0f;
  f_uk = 2.0f;
  first_order_filter(0.2f, &f_yk, f_a0);
  TEST_ASSERT_EQUAL_FLOAT(0.2f, f_yk);
}


//---------------FUNCTION UNDER TEST------------------//
//------------static inline int32_t fl_mul_pu_l_f(int32_t l_x, const float f_y)-------//
void test_fl_mul_pu_l_f_functionality(void)
{
  int32_t l_x = 190;
  const float f_y = 2.21052;
  
  TEST_ASSERT_EQUAL_INT32(420, fl_mul_pu_l_f(l_x, f_y));

// Test with zero input
  int32_t result1 = fl_mul_pu_l_f(0, 1.5f);
  TEST_ASSERT_EQUAL_INT32(0, result1);

  // // Test with positive fixed-point value and positive scale
  // int32_t result2 = fl_mul_pu_l_f(stod(2.5f), 1.2f);
  // TEST_ASSERT_EQUAL_INT32(stod(3.0f), result2);

  // // Test with negative fixed-point value and negative scale
  // int32_t result3 = fl_mul_pu_l_f(stod(-1.5f), -2.0f);
  // TEST_ASSERT_EQUAL_INT32(stod(3.0f), result3);

}


int main(void)
{
  UNITY_BEGIN();

  // Function Under Test: ff_PI_controller
  RUN_TEST(test_ff_PI_controller_PIMODE_PI_NORMAL);
  RUN_TEST(test_ff_PI_controller_PIMODE_PI_HOLD);
  RUN_TEST(test_ff_PI_controller_PIMODE_PI_DISABLE);
  RUN_TEST(test_ff_PI_controller_PIMODE_PI_INIT);

  //Function Under Test: third_order_integrator 
  RUN_TEST(test_third_order_integrator_uk1_uk2_Zero_Zero);
  RUN_TEST(test_third_order_integrator_uk1_uk2_One_Zero);
  RUN_TEST(test_third_order_integrator_uk1_uk2_Zero_One);
  RUN_TEST(test_third_order_integrator_uk1_uk2_One_One);
  RUN_TEST(test_third_order_integrator_Integration);

  //Function Under Test: test_first_order_filter_functionality
  RUN_TEST(test_first_order_filter_functionality);

  //Function Under Test: fl_mul_pu_l_f
  RUN_TEST(test_fl_mul_pu_l_f_functionality);

  return UNITY_END();
}