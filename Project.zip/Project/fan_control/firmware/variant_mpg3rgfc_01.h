/**************************************************************************//**
  \file   variant_mpg3rgfc_01.h
  \brief  Name, HW Version, variant specific values header file
  \author Joseph Cooper
  \date   2023 June 28 (created)

  model dependent default values and limits.
  PCB-MPG3RGFC-00

******************************************************************************/
#ifndef FILE_VARIANT_NAME_01_H        /* sentinel */
#define FILE_VARIANT_NAME_01_H

#ifdef DEFINE_VARS
const tV vrnt_mpg3rgfc_01 =
{
  .product_id     = 0x000100E9,
  .board_version  =    1,
};
#endif

#endif                                     /* end sentinel */
