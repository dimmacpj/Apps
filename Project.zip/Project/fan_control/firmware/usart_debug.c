/**************************************************************************//**
  \file   usart_debug.c
  \brief  usart for debug purposes
  \author Arthur de Beun
  \date   2014 March 24 (created)

******************************************************************************/
#include <stdlib.h>

#include "ena_datatype.h"
#include "ena_driver_stm32g4.h"

#include "hardware.h"
#include "main.h"
#include "usart_debug.h"


/**
  * @brief  Initialise debug USART
  * @retval None
  * Clocked from the peripheral clock at 170MHz
  */

void usart_debug_init(void)
{
  DEBUG_UART_RCC_CLK_EN = 1;   // enable the peripheral clock

  /* Connect PXx to USARTx_Tx */
  ena_gpio_set_af_pin(DEBUG_TX_PORT, DEBUG_TX_PIN, DEBUG_TX_AF);
  LL_GPIO_SetPinMode(DEBUG_TX_PORT, DEBUG_TX_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinSpeed(DEBUG_TX_PORT, DEBUG_TX_PIN, LL_GPIO_SPEED_FREQ_HIGH);
  LL_GPIO_SetPinOutputType(DEBUG_TX_PORT, DEBUG_TX_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinPull(DEBUG_TX_PORT, DEBUG_TX_PIN, LL_GPIO_PULL_NO);

#if defined DEBUG_RX_PIN
  /* Connect PXx to USARTx_Rx */
  ena_gpio_set_af_pin(DEBUG_RX_PORT, DEBUG_RX_PIN, DEBUG_RX_AF);
  LL_GPIO_SetPinMode(DEBUG_RX_PORT, DEBUG_RX_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(DEBUG_RX_PORT, DEBUG_RX_PIN, DEBUG_RX_PULL);
#endif

  /* USART configuration */
  DEBUG_UART->CR1 = 0;                           // disable USART
  DEBUG_UART->CR2 = LL_USART_STOPBITS_1;
  DEBUG_UART->CR1 = LL_USART_DATAWIDTH_8B | LL_USART_PARITY_NONE | LL_USART_DIRECTION_TX;
  DEBUG_UART->CR3 = LL_USART_HWCONTROL_NONE;
  DEBUG_UART->BRR = 1476;                        // 115200 @ 170MHz clock
  PERIPH_BB(DEBUG_UART->CR1, USART_CR1_UE_Pos) = 1; // enable uart
}

int16_t __io_putchar(int16_t ch)
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  DEBUG_UART->TDR = ch;

  /* Loop until the end of transmission */
  while(!LL_USART_IsActiveFlag_TC(DEBUG_UART)) {}

  return ch;
}

