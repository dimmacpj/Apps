/**************************************************************************//**
  \file   db_table.h
  \brief  database table header file
  \author Arthur de Beun
  \date   2015 August 31 (created)


******************************************************************************/

#ifndef FILE_DB_TABLE_H /* sentinel */
#define FILE_DB_TABLE_H

#include "ena_datatype.h"
#include "ena_error_codes.h"

#ifdef SKIPSIZE                             /* don't include db_table_size.h when making db_table.i */
#define DB_TABLE_SIZE (1)
#else
#include "db_table_size.h"
#endif

#define LONGEST_STRING (16)                 /* allow for notepad, serial number, etc. */

/* The different variable types in DBArray.
   For the limits always use either int32_t or float.
*/
typedef enum
{
  DB_S = 0,                                 // pointer to string (null terminated)
  DB_8 = 1,                                 // 8-bit parameter value (1 byte), = sizof(int8_t)
  DB_16 = 2,                                // 16-bit parameter value (2 bytes), = sizeof(int16_t)
  DB_F = 3,                                 // float32_t (4 bytes)
  DB_32 = 4,                                // 32-bit parameter value (4 bytes), = sizeof(int32_t)
  DB_B = 6,                                 // pointer to binary array with bootloader data, does not have EEPROM
} DB_type;

#define DB_TYPE_LENGTH_MAX (4)              // largest number of bytes for DB_type

typedef struct
{
  uint8_t attrib;                        // parameter attributes, such as read, write, array
  DB_type type;
} tDB_type;

/* NOTE: this works because the start of each element is aligned with the address of the union itself
   C99 - section 6.7.2.1 Structure and union specifiers (paragraph 14):
   ... A pointer to a union object, suitably converted, points to each of its members (or if a member
   is a bitfield, then to the unit in which it resides), and vice versa. */
typedef union uDB_init
{
  uint8_t aub_buffer[DB_TYPE_LENGTH_MAX];
  int8_t b;
  uint8_t ub;
  int16_t w;
  uint16_t uw;
  int32_t l;
  uint32_t ul;
  float32_t f;
  const uint8_t* const paub;                // string
  const volatile float32_t * const pkf;
  const volatile int32_t* const pkl;
  const volatile uint32_t* const pkul;
  struct                                    /* little-endian */
  {
    uint8_t b0;
    uint8_t b1;
    uint8_t b2;
    uint8_t b3;
  } byte;
} uDB_init;

/* database array entry */
typedef struct DB_entry_struct
{
  volatile void *const        ram_addr;        /* pointer to RAM variable */
  const tDB_type              db_type;         /* type/size of parameter */
  const uint16_t              param_name;      /* parameter name */
  const uint16_t              eeprom_addr;     /* EEPROM address */
  const uDB_init              default_value;   /* default value (either int32_t or float) */
  const uDB_init              minimum_value;   /* minimum value (either int32_t or float) or min string length */
  const uDB_init              maximum_value;   /* maximum value (either int32_t or float) or max string length */
  const uDB_init              scaling;         /* multiply internal value last on read, divide external value first on write, not implemented for DB_8 and DB_32 */
  t_error_code (*const some_function)(tMSG, uint32_t, uint32_t); /* some optional function to execute after writing or before reading */
} tDB_entry;

_Static_assert((1 == sizeof(DB_type)), "DB_type size is expected to be 1 byte");
_Static_assert((32 == sizeof(tDB_entry)), "tDB_entry size is expected to be 32 bytes");

/* global function prototypes */

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

EXTERN volatile uDB_init u_ui_temp;         /* temporary variable to pass to function */
EXTERN volatile float32_t f_debug_var_1;
EXTERN volatile float32_t f_debug_var_2;
EXTERN volatile float32_t f_debug_var_3;
EXTERN volatile float32_t f_debug_var_4;
EXTERN volatile int32_t l_debug_var_1;
EXTERN volatile int32_t l_debug_var_2;
EXTERN volatile int32_t l_debug_var_3;
EXTERN volatile int32_t l_debug_var_4;
EXTERN volatile uint8_t notepad[LONGEST_STRING];
EXTERN volatile uint8_t serial_number[11];


#undef EXTERN
#undef INIT

extern const tDB_entry DBArray[];

/* attributes */
#define ATTR_RD            (0x01)           /* read permission */
#define ATTR_WR            (0x02)           /* write permission */
#define ATTR_FWR           (0x04)           /* factory password write */
#define ATTR_WR_MASK       (0x06)           /* write permission coded in 2 bits */
#define ATTR_PTR_DEFAULT   (0x08)           /* default value is a pointer (for the purpose of different variants/models) */
#define ATTR_PTR_MIN       (0x10)           /* min value is a pointer (for the purpose of different variants/models) */
#define ATTR_PTR_MAX       (0x20)           /* max value is a pointer (for the purpose of different variants/models) */
#define ATTR_SPARE         (0x40)           /* available */
#define ATTR_AC            (0x80)           /* reserved for dual controllers */

/* parameter name macro */
#define PARNAME(a, b) (((a) <<8) | (b))

/* start of second EEPROM table */
#define SECOND_TABLE_OFFSET (E2END / 2 + 1) /* E2END is defined in hardware.h */

#endif /* sentinel */
