/**************************************************************************//**
  \file   db.h
  \brief  database access functions
  \author Joseph Cooper
  \date   2023 June 09 (created)


******************************************************************************/

#ifndef FILE_DB_H /* sentinel */
#define FILE_DB_H

#include "ena_datatype.h"
#include "ena_error_codes.h"

#include "db_table.h"

/* global function prototypes */
uint16_t db_param_to_index(uint16_t uw_addr);
uint8_t db_type_size(uint16_t table_index);
bool db_check_range(uint16_t table_index, uDB_init u_DB);

t_error_code fdb_parameter_table_size(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_sbi_port_number(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_timestamp(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_name(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_default(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_max(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_min(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_eeprom(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_index(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_attrib(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code fdb_parameter_type(tMSG read_write, uint32_t timestamp, uint32_t port);

#endif /* sentinel */
