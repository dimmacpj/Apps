/**************************************************************************//**
  \file   sbi.c
  \brief  sbi protocol
  \author Arthur de Beun
  \date   2015 September 03 (created)

 Description : Serial Bus Interface Task

   The USART is set to 19200, N, 8, 1

   Extend the protocol to have a variable number of characters for the
   parameter value field. The asterisk then indicates the end of the parameter
   field.

   Remove telecom type backward compatibility.

   ----------------------------------------------------------------

   There are two variations of the parameter input sentence:

   1) Setting a variable:

   $AA,PP,VVVV*SS                            --- 10 + n bytes long

   where
   $        Start of Sentence (SOS), ASCII 0x24
   AA       Address of the device to be queried [hex], 2 ASCII
            characters, range 0..7Fh
   ,        Delimiter, ASCII 0x2C
   PP       Parameter name, 2 ASCII characters, the parameter field
            in DBArray[]
   ,        Delimiter, ASCII 0x2C
   VVVV     Parameter value [hex], n ASCII characters
   *        Start of checksum, ASCII 0x2A
   SS       Checksum [hex], the 1's complement sum of data fields,
            not including the $ and * and ,


   2) Reading a variable:

   $AA,PP*SS                                 --- 9 bytes long

   where
   $        Start of Sentence (SOS), ASCII 0x24
   AA       Address of the device to be queried [hex], 2 ASCII
            characters, range 0..7Fh
   ,        Delimiter, ASCII 0x2C
   PP       Parameter name, 2 ASCII characters, the parameter field
            in DBArray[]
   *        Start of checksum, ASCII 0x2A
   SS       Checksum [hex], the 1's complement sum of data fields,
            not including the $ and * and ,


   The response, three possibilities:

   1) Success

   :AA,PP,VVVV*SS                            --- 10 + n bytes long

   where
   :        Start of Sentence (SOS), ASCII 0x3A
   AA       Address of the responding device [hex], 2 ASCII
            characters, range 1..FFh
   ,        Delimiter, ASCII 0x2C
   PP       Parameter name, 2 ASCII characters, the parameter field
            in DBArray[]
   ,        Delimiter, ASCII 0x2C
   VVVV     Parameter value [hex], n ASCII characters
   *        Start of checksum, ASCII 0x2A
   SS       Checksum [hex], the 1's complement sum of data fields,
            not including the : and * and ,

   When setting a variable the response is essentially identical to
   the input sentence
   When reading a variable, VVVV will contain the value requested

   If the device wants to signal a problem (alarms, errors, etc),
   it will reply with the MSbit of the address field (AA) set. The
   master device can then make further queries to determine the
   actual error code.

   2) Fail

   If the message received was correct, but the variable is not
   readable or writable because it doesn't exist, is password
   protected, is write only or read only, or is out of bounds:

   :AA,PP*SS

   i.e. much the same as for success above, but without the value


   3) Not addressed, broadcast or corrupted

   If (1) the address (AA field) doesn't match
      (2) the message is a broadcast message (AA field = 0)
      (3) the message failed to follow the prescribed format
      (4) the checksum doesn't match

   No response, but in the case of the broadcast write message, the
   value is written, if permitted to do so.
******************************************************************************/

/* FreeRTOS */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#include <stdio.h>

#include "ena_datatype.h"
#include "ena_error_codes.h"
#include "ena_mem.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "variants.h"

#include "db_func.h"
#include "db_table.h"
#include "db.h"
#include "eeprom.h"
#include "events.h"
#include "main.h"
#include "usart_sbi1.h"
#include "usart_sbi2.h"
#define DEFINE_VARS
#include "sbi.h"
#undef DEFINE_VARS
#include "sbi_buffer.h"

#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif


/* local variable definitions */
static uint8_t ub_pw_state;                 // set when password is correct

static t_error_code process_received_frame(const t_sbi_rx_frame* const frame, uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access);
static t_error_code process_request_read(const t_sbi_rx_frame* const frame, uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access);
static t_error_code process_request_write(const t_sbi_rx_frame* const frame, const uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access);
/******************************************************************************

  Serial Bus Interface Task

******************************************************************************/
portTASK_FUNCTION(SBI_Task, pvParameters)
{
  static t_sbi_rx_frame sbi1_rx_frame = {0};
  static uint8_t payload_1[MAX_PAYLOAD_SIZE];
  static t_sbi_rx_frame sbi2_rx_frame = {0};
  static uint8_t payload_2[MAX_PAYLOAD_SIZE];
  static uint32_t comms_timeout_tmr = 0;
  uint8_t sbi_device_addr;                      // this device's communications address

  ( void ) pvParameters; // Stop compiler warning for unused parameter

  printf("SBI_Task start.\n");

  /* SBI access via the UART */
  const t_hw_sbi *const p_hw_sbi1_access = p_uart_sbi1_access;
  const t_hw_sbi *const p_hw_sbi2_access = p_uart_sbi2_access;
  uart_sbi1_init();
  uart_sbi2_init();

  while(1)  // SBI task loop
  {

    if(read_address_select_pin())
    {
      sbi_device_addr = SBI_DEVICE_ADDR_HIGH;
    }
    else
    {
      sbi_device_addr = SBI_DEVICE_ADDR_LOW;
    }

    if(comms_timeout > 0)
    {
      comms_timeout_tmr++;
      if(comms_timeout_tmr >= comms_timeout)
      {   // Comms has timed out
        comms_timeout_tmr = comms_timeout;
        BB(pbb_alarms, FLT_COMMS_TIMEOUT) = 1;
      }
    }
    else
    {                                       // not used when timeout = zero or auto-on enabled
      BB(pbb_alarms, FLT_COMMS_TIMEOUT) = 0;
    }

    t_error_code receive_status_1 = receive_frame(&sbi1_rx_frame, payload_1, sbi_device_addr, p_hw_sbi1_access);
    if(ERR_SUCCESS == receive_status_1)
    {
      comms_timeout_tmr = 0;              // have a message, either broadcast or specifically addressed
      PRINTF("sbi.c 1: MPSM_PROCESSING %c%c , L=%u \n", sbi1_rx_frame.message_parm >> 8, sbi1_rx_frame.message_parm & 0x00FF, sbi1_rx_frame.length);
      receive_status_1 = process_received_frame(&sbi1_rx_frame, payload_1, p_hw_sbi1_access);
      PRINTF("err 1 code %u \n", receive_status_1);
    }

    t_error_code receive_status_2 = receive_frame(&sbi2_rx_frame, payload_2, sbi_device_addr, p_hw_sbi2_access);
    if(ERR_SUCCESS == receive_status_2)
    {
      comms_timeout_tmr = 0;              // have a message, either broadcast or specifically addressed
      PRINTF("sbi.c 2: MPSM_PROCESSING %c%c , L=%u \n", sbi2_rx_frame.message_parm >> 8, sbi2_rx_frame.message_parm & 0x00FF, sbi2_rx_frame.length);
      receive_status_2 = process_received_frame(&sbi2_rx_frame, payload_2, p_hw_sbi2_access);
      PRINTF("err 2 code %u \n", receive_status_2);
    }

    if((ERR_BUFFER_EMPTY == receive_status_1) &&  (ERR_BUFFER_EMPTY == receive_status_2))
    {  // both receive buffers empty
      vTaskDelay(1);
    }

  } /* while (1) */
} /* portTASK_FUNCTION( MonitorComms_Task, pvParameters ) */


static t_error_code process_received_frame(const t_sbi_rx_frame* const frame, uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access)
{
  t_error_code error = ERR_REASON_UNKOWN;
  if(frame->request)
  {
    switch (frame->message_type)
    {
      case MESSAGE_READ:
        error = process_request_read(frame, payload, hw_sbi_access);
        break;

      case MESSAGE_WRITE:
        error = process_request_write(frame, payload, hw_sbi_access);
        break;

      case MESSAGE_WRITE_INIT:
      default: //unsupported operation
        error = ERR_OPERATION_UNSUPPORTED;
        break;
    } /* switch(t_rx_comms_frame->data_type) */
    if((error != ERR_SUCCESS) && (frame->unicast))
    {                                               // only respond if we're specifically addressed
      const bool alarm_active = alarms_mono != 0;
      transmit_error_frame(frame->message_addr, alarm_active, frame->message_parm, hw_sbi_access);
    }
  }
  else
  {
    error = ERR_RESPONSE;
  }
  return error;
}

static t_error_code process_request_read(const t_sbi_rx_frame* const frame, uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access)
{
  t_error_code error = ERR_REASON_UNKOWN;
  uDB_init u_temp;
  int32_t l_temp;

  const uint16_t db_table_index = db_param_to_index(frame->message_parm); // find the parameter name in the database
  if(0xFFFFU == db_table_index)                // check if parameter was found
  {
    /* parameter not found */
    PRINTF(" - not found\n");
    return ERR_PARAM_NOT_FOUND;
  }
  const uint8_t attrib = DBArray[db_table_index].db_type.attrib;
  if(!frame->unicast)
  {                                 // broadcast message so read makes no sense
    return ERR_BROADCAST;
  }

  if(ATTR_RD == (attrib & ATTR_RD))
  {                                 // the variable is readable
    error = ERR_SUCCESS;
    /* execute "some function" if it exists */
    t_error_code (*some_function)(tMSG, uint32_t, uint32_t) = DBArray[db_table_index].some_function;
    if(NULL != some_function)
    {
      error = some_function(MESSAGE_READ, frame->timestamp, frame->port);
    }
    if(ERR_SUCCESS == error)
    {
      const bool alarm_active = alarms_mono != 0;
      switch(DBArray[db_table_index].db_type.type)
      {
        case DB_8:
          u_temp.ub = *((volatile uint8_t*)DBArray[db_table_index].ram_addr);
          /* no scaling */
          payload[0] = u_temp.ub;
          transmit_frame(false, frame->message_addr, alarm_active, 1, frame->message_parm, payload, hw_sbi_access);
          break;

        case DB_16:
          u_temp.w = *((volatile int16_t*)DBArray[db_table_index].ram_addr);
          if(0 != DBArray[db_table_index].scaling.w)
          {    /* apply scaling */
            l_temp = (int32_t)u_temp.w * (int32_t)DBArray[db_table_index].scaling.w;
            u_temp.w = (int16_t)(l_temp >> 13);
          }
          payload[0] = u_temp.byte.b1;
          payload[1] = u_temp.byte.b0;
          transmit_frame(false, frame->message_addr, alarm_active, 2, frame->message_parm, payload, hw_sbi_access);
          break;

        case DB_32:
          u_temp.l = *((volatile int32_t*)DBArray[db_table_index].ram_addr);
          /* scaling not implemented, because the 64-bit division in the corresponding write is too costly code-wise */
          payload[0] = u_temp.byte.b3;
          payload[1] = u_temp.byte.b2;
          payload[2] = u_temp.byte.b1;
          payload[3] = u_temp.byte.b0;
          transmit_frame(false, frame->message_addr, alarm_active, 4, frame->message_parm, payload, hw_sbi_access);
          PRINTF("tx %d \n", frame->message_parm);
          break;

        case DB_F:
          u_temp.f = *((volatile float32_t*)DBArray[db_table_index].ram_addr);
          if(0 != DBArray[db_table_index].scaling.l) // compare as int32 type to keep compiler happy
          {   /* apply scaling */
            u_temp.f *= DBArray[db_table_index].scaling.f;
          }
          payload[0] = u_temp.byte.b3;
          payload[1] = u_temp.byte.b2;
          payload[2] = u_temp.byte.b1;
          payload[3] = u_temp.byte.b0;
          transmit_frame(false, frame->message_addr, alarm_active, 4, frame->message_parm, payload, hw_sbi_access);
          break;

        case DB_S:
          if(DBArray[db_table_index].maximum_value.ul < MAX_PAYLOAD_SIZE)
          {
            ena_memcpy(payload, DBArray[db_table_index].ram_addr, DBArray[db_table_index].maximum_value.ul);
            transmit_frame(false, frame->message_addr, alarm_active, (uint8_t)DBArray[db_table_index].maximum_value.ul, frame->message_parm, payload, hw_sbi_access);
          }
          break;

        case DB_B:                  // not used
        default:
          error = ERR_OPERATION_UNSUPPORTED;
          break;
      }
    }
  } /* if(attrib & ATTR_RD) */
  else
  {
    error = ERR_PARM_NO_READ;
  }
  return error;
}

static t_error_code process_request_write(const t_sbi_rx_frame* const frame, const uint8_t payload[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access)
{
  t_error_code error = ERR_REASON_UNKOWN;
  uDB_init u_temp;
  int32_t l_temp;

  const uint16_t db_table_index = db_param_to_index(frame->message_parm); // find the parameter name in the database
  if(0xFFFFU == db_table_index)                // check if parameter was found
  {
    /* parameter not found */
    PRINTF(" - not found\n");
    return ERR_PARAM_NOT_FOUND;
  }
  const uint8_t attrib = DBArray[db_table_index].db_type.attrib;

  if( (ATTR_WR == (attrib & ATTR_WR_MASK)) ||
    ((ATTR_FWR == (attrib & ATTR_WR_MASK)) && (PW_FACTORY_UNLOCKED == ub_pw_state))
  )
  {
    if(NULL != DBArray[db_table_index].ram_addr)
    {
      switch(DBArray[db_table_index].db_type.type)
      {
        case DB_8:
          if(1 == frame->length)
          {
            u_temp.ub = payload[0];
          }
          else
          {                         // payload size does not match variable type
            error = ERR_PAYLOAD_LENGTH;
            break;
          }

          /* no scaling */
          if(!db_check_range(db_table_index, u_temp))
          {
            error = ERR_OUT_OF_RANGE;
            break;
          }
          *((volatile int8_t*)DBArray[db_table_index].ram_addr) = u_temp.b;
          error = ERR_SUCCESS;
          break;

        case DB_16:
          if(2 == frame->length)
          {
            u_temp.byte.b1 = payload[0];
            u_temp.byte.b0 = payload[1];
          }
          else
          {                         // payload size does not match variable type
            error = ERR_PAYLOAD_LENGTH;
            break;
          }
          if(0 != DBArray[db_table_index].scaling.w)
          {   /* apply scaling */
            l_temp = (int32_t)u_temp.w << 13;
            u_temp.w = (int16_t)(l_temp / DBArray[db_table_index].scaling.w);
          }
          if(!db_check_range(db_table_index, u_temp))
          {
            error = ERR_OUT_OF_RANGE;
            break;
          }
          *((volatile int16_t*)DBArray[db_table_index].ram_addr) = u_temp.w;
          error = ERR_SUCCESS;
          break;

        case DB_32:
          if(4 == frame->length)
          {
            u_temp.byte.b3 = payload[0];
            u_temp.byte.b2 = payload[1];
            u_temp.byte.b1 = payload[2];
            u_temp.byte.b0 = payload[3];
          }
          else
          {                          // payload size does not match variable type
            error = ERR_PAYLOAD_LENGTH;
            break;
          }

          /* the 64-bit division is very expensive, code-wise (about 1500 bytes), and not used, so leave it out */

          if(!db_check_range(db_table_index, u_temp))
          {
            error = ERR_OUT_OF_RANGE;
            break;
          }
          *((volatile int32_t*)DBArray[db_table_index].ram_addr) = u_temp.l;
          error = ERR_SUCCESS;
          break;

        case DB_F:
          if(4 == frame->length)
          {
            u_temp.byte.b3 = payload[0];
            u_temp.byte.b2 = payload[1];
            u_temp.byte.b1 = payload[2];
            u_temp.byte.b0 = payload[3];
          }
          else
          {                          // payload size does not match variable type
            error = ERR_PAYLOAD_LENGTH;
            break;
          }
          if(0 != DBArray[db_table_index].scaling.l) // compare as int32 to keep the compiler happy
          {   /* apply scaling */
            u_temp.f /= DBArray[db_table_index].scaling.f;
          }
          /* check range */
          if(!db_check_range(db_table_index, u_temp))
          {
            error = ERR_OUT_OF_RANGE;
            break;
          }
          *((volatile float32_t*)DBArray[db_table_index].ram_addr) = u_temp.f;
          error = ERR_SUCCESS;
          break;

        case DB_S:
          if(frame->length <= DBArray[db_table_index].maximum_value.ul)
          {
            ena_memcpy(DBArray[db_table_index].ram_addr, payload, frame->length);
            error = ERR_SUCCESS;
          }
          else
          { // the string is too long
            error = ERR_OUT_OF_RANGE;
          }
          break;

        case DB_B:                  // not used
        default:
          error = ERR_OPERATION_UNSUPPORTED;
          break;
      } /* switch(DBArray[db_table_index].ku_type.type) */
    } /* if(DBArray[db_table_index].ram_addr) */
    if(ERR_SUCCESS == error)
    {
      /* execute "some function" if it exists */
      t_error_code (*some_function)(tMSG, uint32_t, uint32_t) = DBArray[db_table_index].some_function;
      if(NULL != some_function)
      {
        error = some_function(MESSAGE_WRITE, frame->timestamp, frame->port);
      }
    }
    if(ERR_SUCCESS == error)
    {
      if((0 != DBArray[db_table_index].eeprom_addr) && (0 != eequeue))
      {
        xQueueSend(eequeue, &db_table_index, 2);
      }
    }
    if(frame->unicast)
    {
      if(ERR_SUCCESS == error)
      {
        const bool alarm_active = alarms_mono != 0;
        transmit_frame(false, frame->message_addr, alarm_active, frame->length, frame->message_parm, payload, hw_sbi_access); // echo the received buffer back
      }
    }
  } /* if ( (ub_permission ... */
  return error;
}

#define SBI_TASK_STACK_SIZE (configMINIMAL_STACK_SIZE + 20)

TaskHandle_t sbi_task_create(void)
{
  static StaticTask_t sbi_task_buffer;
  static StackType_t sbi_task_stack[SBI_TASK_STACK_SIZE];

  return(xTaskCreateStatic(SBI_Task, "SBIS", SBI_TASK_STACK_SIZE, NULL, SBI_TASK_PRIORITY, sbi_task_stack, &sbi_task_buffer));
}
