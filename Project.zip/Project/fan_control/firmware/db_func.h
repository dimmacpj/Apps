/**************************************************************************//**
  \file   db_func.h
  \brief  DB table functions header file
  \author Arthur de Beun
  \date   2013 September 17 (created)

******************************************************************************/

#ifndef FILE_DB_FUNC_H                      /* sentinel */
#define FILE_DB_FUNC_H

#include "ena_datatype.h"
#include "ena_error_codes.h"

/* global function prototypes */

t_error_code fdb_fans_on_off(tMSG read_write, uint32_t timestamp, uint32_t port);

/* Flash memory read only functions */
t_error_code read_sw_checksum(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code read_sw_build_time(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code read_sw_version(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code read_bootloader_checksum(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code read_bootloader_id(tMSG read_write, uint32_t timestamp, uint32_t port);

t_error_code FreeRTOS_tick_count(tMSG read_write, uint32_t timestamp, uint32_t port);

/* Stack high-water marks */
t_error_code Eeprom_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code Control_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code SBI_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port);
t_error_code SBI_Master_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port);

t_error_code start_bootloader(tMSG read_write, uint32_t timestamp, uint32_t port);


#endif                                      /* end sentinel */

