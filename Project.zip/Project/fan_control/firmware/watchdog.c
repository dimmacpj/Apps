/**************************************************************************//**
 *
 * \file    : watchdog.c
 * \brief   : Watchdog
 * \details : Watchdog task and related functions
 * \authors : Kevin Vernon / Joseph Cooper
 * \date    : 2024 August 21 (created)
 *
 *****************************************************************************/

#define DEFINE_VARS
#include "watchdog.h"
#undef DEFINE_VARS
#include "main.h"
#include "hardware.h"

#include <stdio.h>

#define WATCHDOG_TASK_PERIOD   (20U)  //ms
#define HEARTBEAT_PERIOD     (1000U)  //ms

portTASK_FUNCTION(Watchdog_Task, pvParameters)
{
  uint8_t ub_heartbeat_ctr = 0;
  TickType_t t_LastWakeTime;

  ( void ) pvParameters; // Stop compiler warning for unused parameter

  printf("Watchdog_Task start.\n");

  /* keep the reset reason for diagnostic purposes, read with parameter |r */
  reset_flags_cpy = RCC->CSR & 0xFE000000U;
  reset_flags_cpy |= reset_flags;         // copy for comms

  RCC->CSR |= RCC_CSR_RMVF;                 // clear reset flags
  reset_flags = 0;

#if 0
    if(FLASH_OB_GetUser() & OB_SRAM_PARITY_RESET)
      printf("SRAM Parity Check NOT Enabled\n\r");
    else
      printf("SRAM Parity Check Enabled\n\r");
#endif
  t_LastWakeTime = xTaskGetTickCount();
  while(1)
  {
    ub_heartbeat_ctr++;
    if(ub_heartbeat_ctr >= (HEARTBEAT_PERIOD/WATCHDOG_TASK_PERIOD))
    {
      LED_heartbeat_on();                    // low duty cycle to save power
      ub_heartbeat_ctr = 0;
    }
    else
    {
      LED_heartbeat_off();
    }
    xTaskDelayUntil(&t_LastWakeTime, WATCHDOG_TASK_PERIOD);
  }
}

#define WATCHDOG_TASK_STACK_SIZE (configMINIMAL_STACK_SIZE + 20)

TaskHandle_t watchdog_task_create(void)
{
  static StaticTask_t watchdog_task_buffer;
  static StackType_t watchdog_task_stack[WATCHDOG_TASK_STACK_SIZE];

  return(xTaskCreateStatic(Watchdog_Task, "WDOG", WATCHDOG_TASK_STACK_SIZE, NULL, WATCHDOG_TASK_PRIORITY, watchdog_task_stack, &watchdog_task_buffer));
}
