/**************************************************************************//**
  \file   eepromrw.h
  \brief  eeprom read/write interface header file
  \author Arthur de Beun
  \date   2013 September 30 (created)

  EEPROM read and write routines
  Part number CAT24C08, 8 kBit, 1 kByte, On Semiconductor
  All the address inputs are low (only A2 matters). This results in an I2C
  address of 1 0 1 0 0 A9 A8 r/!w.

******************************************************************************/
#ifndef FILE_EEPROMRW_H /* sentinel */
#define FILE_EEPROMRW_H

#include "ena_datatype.h"

void eeprom_init(void);

uint8_t eeprom_rd(uint16_t ee_addr, uint8_t* p_buffer, uint8_t num_to_read);  /* read from EEPROM */
uint8_t eeprom_wr(uint16_t ee_addr, const uint8_t* p_buffer, uint8_t num_to_write); /* write to EEPROM */

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

#undef EXTERN
#undef INIT

#endif /* end sentinel */

