/**************************************************************************//**
  \file   main_main.h
  \brief  main header file
  \author Arthur de Beun
  \date   2015 August 31 (created)

******************************************************************************/
#ifndef FILE_MAIN_MAIN_H                         /* sentinel */
#define FILE_MAIN_MAIN_H

#include "ena_datatype.h"

void main(void);

/* FreeRTOS task priorities, lower number means lower priority. Idle task has FreeRTOS priority 0. */
#define SBI_TASK_PRIORITY ( tskIDLE_PRIORITY + 1UL )
#define EEPROM_TASK_PRIORITY ( tskIDLE_PRIORITY + 1UL )
/* software timers have priority 2, see configTIMER_TASK_PRIORITY in FreeRTOSConfig.h */
#define CONTROL_TASK_PRIORITY ( tskIDLE_PRIORITY + 4UL )
#define WATCHDOG_TASK_PRIORITY ( configMAX_PRIORITIES - 1UL )

/* peripheral priorities are in main.h */

/* global constants */
extern const uint32_t sw_id;              // software ID
extern const uint32_t sw_time;            // software build time (unix time GMT)
extern const uint32_t sw_version;         // software version (high word) and build number (low word)
extern const uint32_t sw_checksum;        // software checksum

/* global variable definitions/declarations */

extern volatile uint32_t reset_flags;      // uninitialised variable for reset reason, defined in linker script

#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

EXTERN volatile uint32_t reset_flags_cpy;     // reset flags for comms purposes

#undef EXTERN
#undef INIT


#endif                                      /* sentinel */
