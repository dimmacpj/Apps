/**************************************************************************//**
  \file   usart_sb2.c
  \brief  usart for sbi comms to monitor
  \author Arthur de Beun
  \date   2015 September 03 (created)

******************************************************************************/
#include <stdlib.h>

#include "ena_datatype.h"
#include "periph_bb.h"
#include "ena_driver_stm32g4.h"

#include "hardware.h"
#include "main.h"
#include "timestamp.h"
#include "usart_sbi2.h"

/* UART receive and transmit buffer sizes, number of message bytes doubles when expressed in hex */
/*                            $AA,PP,                        *SS       */
#define UART_SBI2_TX_BUFFER_SIZE (7 + (2 * MAX_PAYLOAD_SIZE) + 4)
#define UART_SBI2_RX_BUFFER_SIZE (7 + (2 * MAX_PAYLOAD_SIZE) + 4)

static void uart_sbi2_tx_buffer_write(uint8_t ub_tx_data);
static void uart_sbi2_tx_buffer_transmit(void);
static uint8_t uart_sbi2_rx_buffer_read(void);
static uint32_t uart_sbi2_get_rx_timestamp(void);

static const t_hw_sbi uart_sbi2_access = { .tx_write = &uart_sbi2_tx_buffer_write,
                                          .tx_transmit = &uart_sbi2_tx_buffer_transmit,
                                          .rx_read = &uart_sbi2_rx_buffer_read,
                                          .rx_timestamp = &uart_sbi2_get_rx_timestamp,
                                          .port = 2};

const t_hw_sbi *const  p_uart_sbi2_access = &uart_sbi2_access;

/* local variable definitions */
static volatile uint8_t uart_sbi2_rx_buffer[UART_SBI2_RX_BUFFER_SIZE];
static volatile uint8_t uart_sbi2_tx_buffer[UART_SBI2_TX_BUFFER_SIZE]; // transmit circular buffer
static volatile uint8_t uart_sbi2_tx_buffer_wp;  // write pointer
static volatile uint8_t uart_sbi2_rx_buffer_wp;  // write pointer
static volatile uint32_t uart_sbi2_rx_timestamp = 0;

__STATIC_FORCEINLINE void uart_sbi2_send_data(uint16_t c)
{
  SBI2_UART->TDR = c;
}
__STATIC_FORCEINLINE void uart_sbi2_txe_disable(void)
{
  PERIPH_BB(SBI2_UART->CR1, USART_CR1_TXEIE_Pos) = 0;
}
__STATIC_FORCEINLINE void uart_sbi2_txe_enable(void)
{
  PERIPH_BB(SBI2_UART->CR1, USART_CR1_TXEIE_Pos) = 1;
}
__STATIC_FORCEINLINE void uart_sbi2_rxne_enable(void)
{
  PERIPH_BB(SBI2_UART->CR1, USART_CR1_RXNEIE_Pos) = 1;
}

/**
  * @brief  Initialise sbi UART
  * @retval None
  * Clocked from the peripheral clock at 170MHz
  * Includes setting up the NVIC, but does not enable any interrupts
  */

void uart_sbi2_init(void)
{
  /* Configure and enable the USART and relevant IO pins */

  SBI2_RCC_CLK_EN = 1;   // enable the peripheral clock

  /* Configure UART Tx and Rx as alternate function push-pull */
  /* Connect PXx to UARTx_Tx */
  ena_gpio_set_af_pin(SBI2_TX_PORT, SBI2_TX_PIN, SBI2_TX_AF);
  LL_GPIO_SetPinMode(SBI2_TX_PORT, SBI2_TX_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinSpeed(SBI2_TX_PORT, SBI2_TX_PIN, LL_GPIO_SPEED_FREQ_HIGH);
  LL_GPIO_SetPinOutputType(SBI2_TX_PORT, SBI2_TX_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinPull(SBI2_TX_PORT, SBI2_TX_PIN, LL_GPIO_PULL_NO);

  /* Connect PXx to UARTx_Rx */
  ena_gpio_set_af_pin(SBI2_RX_PORT, SBI2_RX_PIN, SBI2_RX_AF);
  LL_GPIO_SetPinMode(SBI2_RX_PORT, SBI2_RX_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(SBI2_RX_PORT, SBI2_RX_PIN, SBI2_RX_PULL);

  /* UART configuration */
  SBI2_UART->CR1 = 0;                           // disable UART
  SBI2_UART->CR2 = LL_USART_STOPBITS_1 | LL_USART_TXPIN_LEVEL_INVERTED;
  SBI2_UART->CR1 = LL_USART_DATAWIDTH_8B | LL_USART_PARITY_NONE | LL_USART_DIRECTION_TX_RX;
  SBI2_UART->CR3 = LL_USART_HWCONTROL_NONE;
  SBI2_UART->BRR = 8854;                        // 19200 @ 170MHz
  PERIPH_BB(SBI2_UART->CR1, USART_CR1_UE_Pos) = 1; // enable uart

  /* Configure the Nested Vectored Interrupt Controller */
  NVIC_SetPriority(SBI2_IRQ_N, INTERRUPT_PRIORITY_SBI);
  NVIC_EnableIRQ(SBI2_IRQ_N);

  uart_sbi2_rxne_enable();             // enable receive interrupt
}

/* read a character from the receive buffer
   returns 0 if the buffer is empty       */
static uint8_t uart_sbi2_rx_buffer_read(void)
{
  static uint8_t uart_sbi2_rx_buffer_rp = 0u;
  const uint8_t buffer_wp = uart_sbi2_rx_buffer_wp;
  uint8_t sbi2_byte;

  if(buffer_wp == uart_sbi2_rx_buffer_rp)
  {
    sbi2_byte = 0U; // buffer is empty
  }
  else
  {
    sbi2_byte = uart_sbi2_rx_buffer[uart_sbi2_rx_buffer_rp];
    uart_sbi2_rx_buffer_rp++;
    if(UART_SBI2_RX_BUFFER_SIZE <= uart_sbi2_rx_buffer_rp)  // warp around
    {
      uart_sbi2_rx_buffer_rp = 0;
    }
  }
  return sbi2_byte;
}

__STATIC_FORCEINLINE void uart_sbi2_tx(void)
{
  static uint8_t uart_sbi2_tx_buffer_rp = 0U;

  if(uart_sbi2_tx_buffer_rp == uart_sbi2_tx_buffer_wp)
  {
    uart_sbi2_txe_disable(); // Nothing to send - shouldn't get here
  }
  else
  {
    uart_sbi2_send_data(uart_sbi2_tx_buffer[uart_sbi2_tx_buffer_rp]);
    uart_sbi2_tx_buffer_rp++;
    if(UART_SBI2_TX_BUFFER_SIZE <= uart_sbi2_tx_buffer_rp)  // overflow
    {
      uart_sbi2_tx_buffer_rp = 0;
    }
    if(uart_sbi2_tx_buffer_rp == uart_sbi2_tx_buffer_wp) // check if this the last byte to be sent
    {
      uart_sbi2_txe_disable();             // USART data register empty (= this) interrupt disable
    }
  }
}

/* place a character in the transmit buffer */
static void uart_sbi2_tx_buffer_write(uint8_t sbi2_byte)
{
  uint8_t buffer_wp = uart_sbi2_tx_buffer_wp;
  uart_sbi2_tx_buffer[buffer_wp] = sbi2_byte;
  buffer_wp++;
  if(UART_SBI2_TX_BUFFER_SIZE <= buffer_wp)
  {
    buffer_wp = 0; // wrap around
  }
  uart_sbi2_tx_buffer_wp = buffer_wp;
}

static void uart_sbi2_tx_buffer_transmit(void)
{
  uart_sbi2_tx();
  uart_sbi2_txe_enable();
}


__STATIC_FORCEINLINE void uart_sbi2_rx(uint8_t rxd)
{
  uint8_t buffer_wp = uart_sbi2_rx_buffer_wp;

  if('$' == rxd)
  {
    // timestamp SBI receive start of frame
    uart_sbi2_rx_timestamp = get_timestamp();
  }

  uart_sbi2_rx_buffer[buffer_wp] = rxd;
  buffer_wp++;
  if (buffer_wp >= UART_SBI2_RX_BUFFER_SIZE) // warp around
  {
    buffer_wp = 0;            // if exceeded end then wrap to beginning
  }
  uart_sbi2_rx_buffer_wp = buffer_wp;
}

static uint32_t uart_sbi2_get_rx_timestamp(void)
{
  return uart_sbi2_rx_timestamp;
}

/**
  * @brief  UART interrupt request handler
  * @retval None
  *
  */
void SBI2_IRQ_HANDLER(void)
{
  if((SBI2_UART->CR1 & USART_CR1_TXEIE) && LL_USART_IsActiveFlag_TXE(SBI2_UART))
  {
    uart_sbi2_tx();
  }

  if(LL_USART_IsActiveFlag_RXNE(SBI2_UART))
  {
    uart_sbi2_rx((uint8_t)SBI2_UART->RDR);
  }

  /* If overrun condition occurs, clear the ORE flag and recover communication */
  if(LL_USART_IsActiveFlag_ORE(SBI2_UART))
  {
    uint32_t dummy = SBI2_UART->RDR;   // Dummy read
    (void)dummy;
  }
}
