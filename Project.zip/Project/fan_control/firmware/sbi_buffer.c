/**************************************************************************//**
  \file   sbi_buffer.c
  \brief  sbi protocol buffer functions
  \author Arthur de Beun
  \date   2015 November 30 (created)

 Description :

******************************************************************************/

#include <string.h> //TODO(JC): replace string functions
#include <stdio.h>

#include "ena_datatype.h"
#include "ena_error_codes.h"

/* Hardware and board configuration */
#include "hardware.h"

#include "variants.h"

#define DEFINE_VARS
#include "sbi_buffer.h"
#undef DEFINE_VARS

extern const uint8_t sbi_bpsu_addr;

/* local function prototypes */
static void transmit_data_byte(uint8_t byte, uint8_t *p_chksum, const t_hw_sbi *const hw_sbi_access);
static void transmit_frame_end(uint8_t chksum, const t_hw_sbi *const hw_sbi_access);

//TODO(JC): move this out to a common helper
bool hex_to_nibble(uint8_t* pub_nibble, uint8_t ub_hex)
{
  if((ub_hex >= '0') && (ub_hex <= '9'))
  {
    *pub_nibble += (uint8_t)(ub_hex - '0');
  }
  else if((ub_hex >= 'A') && (ub_hex <= 'F'))
  {
    *pub_nibble += (uint8_t)(ub_hex - 'A' + 10);
  }
  else if((ub_hex >= 'a') && (ub_hex <= 'f'))
  {
    *pub_nibble += (uint8_t)(ub_hex - 'a' + 10);
  }
  else
  {
    return true;                                // not a valid hex character
  }
  return false;                                 // okay
}

//TODO(JC):create nibble to hex

//TODO(JC): move this out to a common helper
/* 1's complement addition */
uint8_t ones_comp_add(uint8_t operant1, uint8_t operant2)
{
  uint16_t result;

  result = operant1 + operant2;
  if (result >= 256)
  {
    result -= 255;
  }
  return (uint8_t)(result & 0x00FFU);
}

static void transmit_data_byte(uint8_t byte, uint8_t *p_chksum, const t_hw_sbi *const hw_sbi_access)
{
  uint8_t aub_string[3];                    // space for VV plus null

  sprintf((char*)aub_string, "%02X", byte);
  hw_sbi_access->tx_write(aub_string[0]);
  *p_chksum = ones_comp_add(*p_chksum, aub_string[0]);
  hw_sbi_access->tx_write(aub_string[1]);
  *p_chksum = ones_comp_add(*p_chksum, aub_string[1]);
}

static void transmit_frame_end(uint8_t ub_chksum, const t_hw_sbi *const hw_sbi_access)
{
  uint8_t temp = 0;                   // dummy checksum

  hw_sbi_access->tx_write('*');         // checksum delimiter
  transmit_data_byte(~ub_chksum, &temp, hw_sbi_access);
  hw_sbi_access->tx_transmit();
}

void transmit_frame(bool request, uint8_t device_addr, bool alarm_active, uint8_t length, uint16_t message_parm,
                    const uint8_t payload[MAX_PAYLOAD_SIZE],  const t_hw_sbi *const hw_sbi_access)
{
  uint8_t chksum = 0;
  const uint8_t pn_1 = (uint8_t)(message_parm >> 8);
  const uint8_t pn_2 = (uint8_t)(message_parm & 0x00FF);

  if(request)
  {
    hw_sbi_access->tx_write('$');
  }
  else // response
  {
    hw_sbi_access->tx_write(':');
  }

  uint8_t addr_alarm = device_addr | (uint8_t)((uint8_t)alarm_active << 7); // top bit of address feild contains alarm status
  transmit_data_byte(addr_alarm, &chksum, hw_sbi_access);
  hw_sbi_access->tx_write(',');
  hw_sbi_access->tx_write(pn_1);
  chksum = ones_comp_add(chksum, pn_1);
  hw_sbi_access->tx_write(pn_2);
  chksum = ones_comp_add(chksum, pn_2);

  if(0 != length)
  {
    hw_sbi_access->tx_write(',');
    for(uint8_t i = 0; i < length; i++)
    {
      transmit_data_byte(payload[i], &chksum, hw_sbi_access);
    }
  }
  transmit_frame_end(chksum, hw_sbi_access);
}

t_error_code receive_frame(t_sbi_rx_frame* frame, uint8_t payload[MAX_PAYLOAD_SIZE], uint8_t device_addr, const t_hw_sbi *const hw_sbi_access)
{
  uint8_t ret_code = ERR_IN_PROGRESS;
  const uint8_t ub_rxd = hw_sbi_access->rx_read();
  if(frame->state == MPSM_PROCESSING)
  {                                // reset the state machine
    ret_code = ERR_WAIT_SOF;
    frame->state = MPSM_SEARCH_SOF;
  }
  if(0 != ub_rxd)
  {
    /* sentence parsing state machine */
    if(('$' == ub_rxd) || (':' == ub_rxd))     // reset the state machine whenever SOF chars received
    {
      frame->state = MPSM_SEARCH_SOF;
    }

    switch(frame->state)
    {
      case MPSM_SEARCH_SOF:
        frame->checksum = 0;            // reset checksum
        frame->received_checksum = 0;
        frame->message_addr = 0;        // device address
        frame->message_parm = 0;        // parameter name
        frame->length = 0;
        frame->timestamp = hw_sbi_access->rx_timestamp();
        frame->port = hw_sbi_access->port;
        if('$' == ub_rxd)               // advance state machine once request SOF is found
        {
          frame->state = MPSM_GET_ADDR; // next state
          frame->request = true;
        }
        else if(':' == ub_rxd)          // advance state machine once response SOF is found
        {
          frame->state = MPSM_GET_ADDR; // next state
          frame->request = false;
        }
        else
        {
          ret_code = ERR_NO_START;
        }
        break;

      case MPSM_GET_ADDR:
        if(',' == ub_rxd)               // have reached parameter name
        {
          frame->alarm = 0x80 == (frame->message_addr & 0x80);  // top bit of the address contains the alarm flag
          frame->message_addr = frame->message_addr & 0x7F;     // remove the alarm flag bit
          // This device does not support broadcast address.
          if ((device_addr == frame->message_addr) ||
                   (sbi_bpsu_addr == frame->message_addr))
          {
            frame->unicast = true;        // this device specifically addressed
            frame->state = MPSM_GET_PARM; // next state
          }
          else
          {                                 // message not for this device
            ret_code = ERR_ADDR;
            frame->state = MPSM_SEARCH_SOF; // next state
          }
        }
        else
        {
          frame->checksum = ones_comp_add(frame->checksum, ub_rxd);
          frame->message_addr = (uint8_t)(frame->message_addr << 4);
          if(hex_to_nibble(&frame->message_addr, ub_rxd))
          {
            ret_code = ERR_WRONG_CHR;
            frame->state = MPSM_SEARCH_SOF; // next state
          }
        }
        break;

      case MPSM_GET_PARM:
        if(',' == ub_rxd)               // have a parameter write message
        {
          frame->message_type = MESSAGE_WRITE;
          frame->state = MPSM_GET_DATA1; // next state
        }
        else if('*' == ub_rxd)             // have a parameter read message
        {
          frame->message_type = MESSAGE_READ;
          frame->state = MPSM_GET_CHK1;  // next state
        }
        else
        {
          frame->message_parm = (uint16_t)(frame->message_parm << 8) | (uint16_t)ub_rxd;
          frame->checksum = ones_comp_add(frame->checksum, ub_rxd);
        }
        break;

      case MPSM_GET_DATA1:              // 1st (top) nibble
        if('*' == ub_rxd)               // have reached checksum
        {
          frame->state = MPSM_GET_CHK1; // next state
        }
        else
        {
          if(frame->length >= MAX_PAYLOAD_SIZE)
          {
            ret_code = ERR_PAYLOAD_OVERFLOW;
            frame->state = MPSM_SEARCH_SOF; // next state
            break;                    // message too long
          }
          payload[frame->length] = 0; // initialise before 1st nibble
          if(hex_to_nibble(&payload[frame->length], ub_rxd))
          {
            ret_code = ERR_WRONG_CHR;
            frame->state = MPSM_SEARCH_SOF; // next state
            break;                    // message not correct
          }
          frame->checksum = ones_comp_add(frame->checksum, ub_rxd);
          frame->state = MPSM_GET_DATA2; // next state
        }
        break;

      case MPSM_GET_DATA2:            // 2nd (bottom) nibble
        payload[frame->length] <<= 4; // shift before 2nd nibble
        if(hex_to_nibble(&payload[frame->length], ub_rxd))
        {                                  // message not correct
          ret_code = ERR_WRONG_CHR;
          frame->state = MPSM_SEARCH_SOF;  // next state
        }
        else
        {
          frame->length++;
          frame->checksum = ones_comp_add(frame->checksum, ub_rxd);
          frame->state = MPSM_GET_DATA1; // next state
        }
        break;

      case MPSM_GET_CHK1:
        frame->received_checksum = 0;
        if(hex_to_nibble(&frame->received_checksum, ub_rxd))
        {
          ret_code = ERR_WRONG_CHR;
          frame->state = MPSM_SEARCH_SOF; // next state
          break;                        // message not correct
        }
        frame->received_checksum = (uint8_t)(frame->received_checksum << 4);
        frame->state = MPSM_GET_CHK2;
        break;

      case MPSM_GET_CHK2:
        if(hex_to_nibble(&frame->received_checksum, ub_rxd))
        {
          ret_code = ERR_WRONG_CHR;
          frame->state = MPSM_SEARCH_SOF; // next state
          break;                        // message not correct
        }
        frame->received_checksum = ~(frame->received_checksum);
        if(frame->received_checksum == frame->checksum)
        {
          ret_code = ERR_SUCCESS;
          frame->state = MPSM_PROCESSING; // got a complete and uncorrupted message
        }
        else
        {
          ret_code = ERR_CHECKSUM;
          frame->state = MPSM_SEARCH_SOF; // checksum wrong
        }
        break;

      case MPSM_PROCESSING:
      default:
        ret_code = ERR_OPERATION_UNSUPPORTED;
        frame->state = MPSM_SEARCH_SOF;
    }
  }
  else
  {
    ret_code = ERR_BUFFER_EMPTY;
  }
  return ret_code;
}
