/**************************************************************************//**
  \file   sbi_buffer.h
  \brief  sbi protocol buffer functions header file
  \author Arthur de Beun
  \date   2015 November 30 (created)

******************************************************************************/
#ifndef FILE_SBI_BUFFER_H                   /* sentinel */
#define FILE_SBI_BUFFER_H

#include "ena_datatype.h"
#include "ena_error_codes.h"

/* serial comms buffer sizes */
#define PROG_PAYLOAD_LEN (34)               /* 2 bytes of address + 32 bytes of flash data */
#define MAX_PAYLOAD_SIZE (PROG_PAYLOAD_LEN)

typedef struct hw_sbi_access_struct
{
  void (*const tx_write)(uint8_t sbi_byte);
  void (*const tx_transmit)(void);
  uint8_t (*const rx_read)(void);
  uint32_t (*const rx_timestamp)(void);
  const uint32_t port;
} t_hw_sbi;

/* Message parser state machine */
typedef enum
{
  MPSM_SEARCH_SOF,                          /* $ or: search for start of frame */
  MPSM_GET_ADDR,                            /* AA, get the device address */
  MPSM_GET_PARM,                            /* PP get the parameter name followed by ,(write) or *(read)*/
  MPSM_GET_DATA1,                           /* VV* get the parameter value */
  MPSM_GET_DATA2,                           /* vv get the parameter value */
  MPSM_GET_CHK1,                            /* get first checksum character */
  MPSM_GET_CHK2,                            /* get second checksum character */
  MPSM_PROCESSING
} t_mpsm;

typedef struct hw_sbi_rx_frame_struct
{
  bool request;              // request [true] or response [false]
  bool unicast;              // unicast (specifically addressed) [true] or broadcast/multicast [false]
  bool alarm;                // there is an active alarm
  uint8_t message_addr;
  uint16_t message_parm;     // parameter name
  tMSG message_type;         // read or write
  uint8_t length;            // length of payload and index to payload when receiving
  t_mpsm state;              // message parser state machine
  uint8_t checksum;          // checksum computed as message is parsed
  uint8_t received_checksum; // checksum in received message
  uint32_t timestamp;        // sbi message received timestamp
  uint32_t port;             // sbi port number
} t_sbi_rx_frame;

t_error_code receive_frame(t_sbi_rx_frame* frame, uint8_t payload[MAX_PAYLOAD_SIZE], uint8_t device_addr, const t_hw_sbi *const hw_sbi_access);

void transmit_frame(bool request, uint8_t device_addr, bool alarm_active, uint8_t length, uint16_t message_parm,
                    const uint8_t buffer[MAX_PAYLOAD_SIZE], const t_hw_sbi *const hw_sbi_access);

static inline void transmit_error_frame(uint8_t device_addr, bool alarm_active, uint16_t param_name, const t_hw_sbi *const hw_sbi_access)
{
  transmit_frame(false, device_addr, alarm_active, 0, param_name, NULL, hw_sbi_access);
}

__STATIC_FORCEINLINE uint8_t sbi_rx_buffer_read(const t_hw_sbi *const hw_sbi_access)
{
  return hw_sbi_access->rx_read();
}

bool hex_to_nibble(uint8_t* pub_nibble, uint8_t ub_hex);
uint8_t ones_comp_add(uint8_t ub_operant1, uint8_t ub_operant2);

#endif /* end sentinel */
