/**************************************************************************//**
  \file   main.h
  \brief  select either bootloader or main header file
  \author Arthur de Beun

******************************************************************************/
#ifndef FILE_MAIN_H                         /* sentinel */
#define FILE_MAIN_H

/* Peripheral interrupt priorities, priorities are configured with
   4 bits for pre-emption priority, 0 bits for sub-priority.
   Sorted by decreasing priority (lower number is higher priority) */
/* Note that the SysTick timer is set to the lowest priority of the processor (15, higher number
   means lower priority), enabled in xPortStartScheduler() */
#define INTERRUPT_PRIORITY_BOOTLOADER  (6) // Bootloader tick timer priority
#define INTERRUPT_PRIORITY_SBI         (7) // SBI usart
#define INTERRUPT_PRIORITY_TIMEOUT     (8) // bootloader timeout
#define INTERRUPT_PRIORITY_ADC         (12)// ADC
/* SysTick (FreeRTOS)                  (15) */ /* see FreeRTOSConfig.h */

#ifdef BOOTLOADER
#include "main_bootloader.h"
#endif

#ifdef MAIN
#include "main_main.h"
#endif

#endif
