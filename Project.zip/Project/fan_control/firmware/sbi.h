/**************************************************************************//**
  \file   sbi.h
  \brief  sbi protocol header file
  \author Arthur de Beun
  \date   2015 September 03 (created)

******************************************************************************/
#ifndef FILE_SBI_H                          /* sentinel */
#define FILE_SBI_H

#include "task.h"
#include "ena_datatype.h"

#define SBI_TASK_STACK_SIZE (configMINIMAL_STACK_SIZE + 20)

/* global function prototypes */
portTASK_FUNCTION_PROTO(SBI_Task, pvParameters );

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

TaskHandle_t sbi_task_create(void);
EXTERN TaskHandle_t SBI_Task_Handle;
EXTERN const uint8_t sbi_bpsu_addr INIT(88);
EXTERN volatile uint32_t comms_timeout;             // comms timeout [ms]
uint8_t update_rack_position(float32_t v_output, float32_t v_horizontal, float32_t v_vertical, uint16_t address_lock_time);

#undef EXTERN
#undef INIT

/* factory password values */
#define FACTORY_PW1 (0x9EAB)
#define FACTORY_PW2 (0x6B96)

#define PW_LOCKED           (0)
#define PW_FACTORY_STEP1    (3)
#define PW_FACTORY_UNLOCKED (4)

#define RACK_POS_VERT_STEP (5.6F)

#endif /* end sentinel */


