/**************************************************************************//**
  \file   main_bootloader.h
  \brief  main header file
  \author Arthur de Beun
  \date   2013 August 20 (created)

******************************************************************************/
#ifndef FILE_MAIN_BOOTLOADER_H                         /* sentinel */
#define FILE_MAIN_BOOTLOADER_H

/* peripheral priorities are in main.h */

void main(void);


#endif                                      /* sentinel */
