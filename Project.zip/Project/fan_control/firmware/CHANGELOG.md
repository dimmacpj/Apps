# Changelog

All notable changes to the Four Wire Fan Controller project will be documented in this file.

---

# Contents

[[_TOC_]]

---
## [2025-02-03]
### Changed
  - Removed code relating to temporary functionality. Turn fan(s) on at [40]degC and turn fan(s) off at [35]degC.
### Added
  - Fan control functionality with monitor via SBI, as stated in <Fan control firmware and software functionality v2.0>.
## [2025-01-28]
### Changed
  - Inverted SBI1&SBI2 TX pin level.
  - Commented out Dev board definition in hardware header file.
### Added
  - Turn fan(s) on at [40]degC and ramp fan up from 15% to 100% over 60 seconds.
  - Turn fan(s) off at [35]degC and ramp fan down from 100% to 15% over 60 seconds then turn fan off.
## [2025-01-20]
### Fixed
  - Request of SBI parameter that is less than the first parameter causes db_param_to_index to loop forever.
## [2025-01-17]
### Changed
  - Product ID set to 0x000100E9.
  - Bootloader ID set to 5.
  - Address 96 when R963 fitted, otherwise 97.
  - Broadcast addressing removed.
## [2025-01-14]
### Added
  - ADC conversion of NTC temperature sensors and aux supply voltage.
## [2025-01-07]
### Added
  - Port number to the SBI.
  - On, off control of the fan where the on of both SBI ports are ORed.
### Fixed
  - Timestamp timer enabled.
## [2024-12-19]
### Added
  - Dual SBI.
  - Fan pwm control outputs.
  - Fan tacho inputs.
  - Generate an alarm when the fan is on, but the rpm of the fan is below the minimum taco rpm threshold.
### Changed
  - Moved error codes to a separate header.
## [2024-12-16]
### Added
  - Setup hardware.h
### Fixed
  - db_check_range() of string type.
### Changed
  - Moved EEPROM hardware initialisation to eepromrw.c
## [2024-12-11]
### Added
  - Initial commit adding base project from 00-sample-power-converter
### Changed
  - Removed code relating to AC link access.
