/**************************************************************************//**
  \file   adc.c
  \brief  ADC hardware setup and sampling.
          ADC1 is used to sample NTC_PCB, NTC_1, NTC_2 and AUX.
******************************************************************************/
#include "ena_datatype.h"
#include "ena_driver_stm32g4.h"
#include "ena_maths.h"
#include "temperature.h"

#include "hardware.h"
#include "main.h"

#include "db.h"

#include "adc.h"

volatile float32_t ntc_pcb_temperature;
volatile float32_t ntc_1_temperature;
volatile float32_t ntc_2_temperature;
volatile float32_t aux_v;
volatile float32_t aux_v_gain = AUX_GAIN;

/**
 * Initialise the ADC GPIO and ADC .
*/
void adc_hardware_init(void)
{
  BB_RCC_AHB2ENR_ADC12EN = 1;

  LL_RCC_SetADCClockSource(LL_RCC_ADC12_CLKSOURCE_NONE);
  LL_ADC_SetCommonClock(ADC12_COMMON, LL_ADC_CLOCK_SYNC_PCLK_DIV4);

  LL_GPIO_SetPinMode(NTC_PCB_PORT, NTC_PCB_PIN, LL_GPIO_MODE_ANALOG);
  LL_GPIO_SetPinMode(NTC_1_PORT, NTC_1_PIN, LL_GPIO_MODE_ANALOG);
  LL_GPIO_SetPinMode(NTC_2_PORT, NTC_2_PIN, LL_GPIO_MODE_ANALOG);
  LL_GPIO_SetPinMode(AUX_PORT, AUX_PIN, LL_GPIO_MODE_ANALOG);
  LL_GPIO_SetPinPull(NTC_PCB_PORT, NTC_PCB_PIN, LL_GPIO_PULL_NO);
  LL_GPIO_SetPinPull(NTC_1_PORT, NTC_1_PIN, LL_GPIO_PULL_NO);
  LL_GPIO_SetPinPull(NTC_2_PORT, NTC_2_PIN, LL_GPIO_PULL_NO);
  LL_GPIO_SetPinPull(AUX_PORT, AUX_PIN, LL_GPIO_PULL_NO);

  ADC1->CR = ADC_CR_ADVREGEN; // disable deep power down, enable voltage regulator

  for(int32_t l_i = 0; l_i < 1700; l_i++) __NOP();  // need at least 20us delay (tADCVREG_STUP), this is about 40us

  /* calibration procedure */
  LL_ADC_StartCalibration(ADC1, LL_ADC_SINGLE_ENDED);

  while(1 == LL_ADC_IsCalibrationOnGoing(ADC1)){/* loop */}

  /* Reference Manual Caution 21.4.9 wait >= 4 ADC Clock cycles before enabling ADC.*/
  for(int32_t l_i = 0; l_i < (4 * 4); l_i++) {__NOP();}

  /* enable ADC */
  LL_ADC_ClearFlag_ADRDY(ADC1);
  LL_ADC_Enable(ADC1);

  ADC1->CFGR = LL_ADC_REG_DMA_TRANSFER_NONE |      // DMACFG and DMAEN
               LL_ADC_RESOLUTION_12B |             // RES[1:0]
               LL_ADC_REG_TRIG_SOFTWARE |          // EXTSEL[4:0], EXTEN[1:0]
               LL_ADC_REG_OVR_DATA_OVERWRITTEN |   // OVRMOD
               LL_ADC_REG_CONV_CONTINUOUS |        // CONT
               LL_ADC_DATA_ALIGN_RIGHT |           // ALIGN
               LL_ADC_INJ_TRIG_FROM_GRP_REGULAR |  // JAUTO
               LL_ADC_INJ_QUEUE_DISABLE |          // JQDIS (set by default)
               LL_ADC_INJ_SEQ_DISCONT_DISABLE;     // JDISCEN

  LL_ADC_REG_SetSequencerLength(ADC1, LL_ADC_REG_SEQ_SCAN_DISABLE); // this means 1 rank
  LL_ADC_REG_SetSequencerRanks(ADC1, LL_ADC_REG_RANK_1, AUX_ADC_CH);
  LL_ADC_SetChannelSamplingTime(ADC1, AUX_ADC_CH, LL_ADC_SAMPLINGTIME_640CYCLES_5);

  LL_ADC_INJ_SetSequencerLength(ADC1, LL_ADC_INJ_SEQ_SCAN_ENABLE_3RANKS);
  LL_ADC_INJ_SetSequencerRanks(ADC1, LL_ADC_INJ_RANK_1, NTC_PCB_ADC_CH);
  LL_ADC_SetChannelSamplingTime(ADC1, NTC_PCB_ADC_CH, LL_ADC_SAMPLINGTIME_640CYCLES_5);
  LL_ADC_INJ_SetSequencerRanks(ADC1, LL_ADC_INJ_RANK_2, NTC_1_ADC_CH);
  LL_ADC_SetChannelSamplingTime(ADC1, NTC_1_ADC_CH, LL_ADC_SAMPLINGTIME_640CYCLES_5);
  LL_ADC_INJ_SetSequencerRanks(ADC1, LL_ADC_INJ_RANK_3, NTC_2_ADC_CH);
  LL_ADC_SetChannelSamplingTime(ADC1, NTC_2_ADC_CH, LL_ADC_SAMPLINGTIME_640CYCLES_5);


  LL_ADC_INJ_SetTriggerSource(ADC1, LL_ADC_INJ_TRIG_SOFTWARE);

  LL_ADC_SetOverSamplingScope(ADC1, LL_ADC_OVS_GRP_INJ_REG_RESUMED);

  LL_ADC_ConfigOverSamplingRatioShift(ADC1, LL_ADC_OVS_RATIO_16, LL_ADC_OVS_SHIFT_NONE); // 16-bit result

  NVIC_SetPriority(ADC1_2_IRQn, INTERRUPT_PRIORITY_ADC);
  NVIC_EnableIRQ(ADC1_2_IRQn);
  ADC1->IER = LL_ADC_IT_JEOS;    // enable injected end of sequence interrupt

  /* check that ADC is ready to accept conversion requests */
  while(1 != LL_ADC_IsActiveFlag_ADRDY(ADC1)){/* loop */}

  /* start the conversions */
  LL_ADC_REG_StartConversion(ADC1);

}

/**
 * ADC interrupt that runs every 980us.
 * Block average filters the results over a 500ms period.
 * Converts the ADC results to temperatures and the aux voltage.
*/
void ADC1_2_IRQHandler(void)
{
  static uint32_t sample_cnt = 0;
  static uint32_t ntc_pcb_accumulator = 0;
  static uint32_t ntc_1_accumulator = 0;
  static uint32_t ntc_2_accumulator = 0;
  static uint32_t aux_accumulator = 0;

  ADC1->ISR = LL_ADC_FLAG_JEOS;  // clear injected end of sequence interrupt flag

  ntc_pcb_accumulator += ADC1->JDR1;
  ntc_1_accumulator += ADC1->JDR2;
  ntc_2_accumulator += ADC1->JDR3;
  aux_accumulator += ADC1->DR;

  sample_cnt++;

  if(sample_cnt >= 512)  // Update at 1.993Hz, gives 25bit result
  {
    debug_pin_high();
    // convert to 12 bits
    ntc_pcb_accumulator = ntc_pcb_accumulator >> 13;
    ntc_1_accumulator = ntc_1_accumulator >> 13;
    ntc_2_accumulator = ntc_2_accumulator >> 13;
    aux_accumulator = aux_accumulator >> 13;

    l_debug_var_1 = (int32_t)ntc_pcb_accumulator;
    l_debug_var_2 = (int32_t)ntc_1_accumulator;
    l_debug_var_3 = (int32_t)ntc_2_accumulator;
    l_debug_var_4 = (int32_t)aux_accumulator;

    // convert to temperatures
    float32_t temp;
    ntc_lookup((uint16_t)ntc_pcb_accumulator, &temp);
    ntc_pcb_temperature = temp;
    ntc_lookup((uint16_t)ntc_1_accumulator, &temp);
    ntc_1_temperature = temp;
    ntc_lookup((uint16_t)ntc_2_accumulator, &temp);
    ntc_2_temperature = temp;

    // calibrate the aux
    aux_v = (float32_t)aux_accumulator * aux_v_gain;

    // reset accumulators
    ntc_pcb_accumulator = 0;
    ntc_1_accumulator = 0;
    ntc_2_accumulator = 0;
    aux_accumulator = 0;
    sample_cnt = 0;

    debug_pin_low();
  }
}
