/**************************************************************************//**
  \file   usart_debug.h
  \brief  usart for debug purposes
  \author Arthur de Beun
  \date   2014 March 24 (created)

******************************************************************************/
#ifndef FILE_USART_DEBUG_H                  /* sentinel */
#define FILE_USART_DEBUG_H

#include "ena_datatype.h"

void usart_debug_init(void);
int16_t __io_putchar(int16_t ch);

#endif                                      /* sentinel */
