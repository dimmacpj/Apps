/**************************************************************************//**
  \file   events.h
  \brief  events, alarms functions header file
  \author Arthur de Beun
  \date   2015 August 31 (created)




******************************************************************************/
#ifndef FILE_EVENTS_H                       /* sentinel */
#define FILE_EVENTS_H

#include "ena_datatype.h"

/* faults that prevent the system from running
   The variable alarms has a corresponding pointer ppb_alarm which points to the
   bit-band mapping of alarms. The individual flags are then accessed using the
   BB macro using the names below. This makes bit changes in alarms atomic.
   pbb_alarms is initialised early in main(). Its value can unfortunately not be
   computed at compile-time "error: initializer element is not constant".
*/
#define FLT_POWER_ON                    (0) // set on micro power up / reset
#define FLT_FAN1_FAIL                   (1) // fan 1 fail
#define FLT_FAN2_FAIL                   (2) // fan 2 fail
#define FLT_3                           (3) //
#define FLT_4                           (4) //
#define FLT_5                           (5) //
#define FLT_6                           (6) //
#define FLT_COMMS_TIMEOUT               (7) //    timeout in absence of monitor comms
/* -- */
#define FLT_EEPROM_FAIL                 (8) // write failure during init
#define FLT_FIRMWARE                    (9) // problem with product ID and/or board version/variant
#define FLT_FLASH_PROGRAMMING          (10) //
#define FLT_V_AUX_LOW                  (11) // 12V aux voltage
/* -- */
#define FLT_12                         (12) //
#define FLT_13                         (13) //
#define FLT_14                         (14) //
#define FLT_15                         (15) //
/* -- */
#define FLT_16                         (16) //
#define FLT_17                         (17) //
#define FLT_18                         (18) //
#define FLT_19                         (19) //
/* end of fault flags, start of warning flags */
/* -- */
#define WRN_20                         (20) //
#define WRN_21                         (21) //
#define WRN_22                         (22) //
#define WRN_23                         (23) //
/* -- */
#define WRN_24                         (24) //
#define WRN_25                         (25) //
#define WRN_FAN_FAIL                   (26) //
#define WRN_T_FLT                      (27) //
/* -- */
#define WRN_28                         (28) //
#define WRN_29                         (29) //
#define WRN_EEPROM_WRITE_FAIL          (30) // EEPROM write failure from comms
#define WRN_EEPROM_INIT                (31) // one or more EEPROM values were corrupt and init to default

#define FLT_FLAGS (0x000FFFFF)              /* faults that cause a change to the fault state */
                                            /* faults that cause the restart delay to increase */

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif
/* faults and warnings */
EXTERN volatile uint32_t alarms;           // alarm (fault/warning) status bits live
EXTERN volatile uint32_t *pbb_alarms;       // pointer to bit-band alarm status bits live
EXTERN volatile uint32_t alarms_mono;      // overall alarm status bits stretched with monostable
EXTERN volatile uint32_t alarms_latched;   // overall fault status bits latched until cleared by external command

#undef EXTERN
#undef INIT


void update_alarm_mono(volatile uint32_t* p_alarms_mono, uint32_t alarm_field, bool clear);   // update fault and warning status bit monostables
void update_info_mono(volatile uint32_t* p_alarms_mono, uint32_t info_field, bool clear);     // update info status bit monostables
int16_t inc_tmr_test(bool test, uint32_t* p_timer, uint32_t timeout);
void event_init_bb_ptr(void);            // initialise bit-banding pointers

#endif                                      /* end sentinel */
