/**************************************************************************//**
  \file   startup_stm32g474xx.c
  \brief  stm32g474 startup.
  \author Arthur de Beun
  \date   2015 August 28 (created)

          This file contains initial startup code:
          - initialise data and bss sections
          - eventually jumps to main()

          Vector table and default interrupt handler

******************************************************************************/
#if !defined MAIN && !defined BOOTLOADER
#error Neither MAIN nor BOOTLOADER defined
#endif

void main(void);

#include <stdint.h>
#include "ena_datatype.h"
#include "stm32g4xx_it.h"                   /* NMI_Handler(), HardFault_Handler(), MemManage_Handler(),
                                               BusFault_Handler(), UsageFault_Handler(), DebugMon_Handler() */

#include "hardware.h"

/* Interrupt handlers provided by FreeRTOS/portable/GCC/ARM_CM4F/port.c. */

/* start address for the initialization values of the .data section, defined in linker script */
extern uint32_t _sidata;
/* start address for the .data section, defined in linker script */
extern uint32_t _sdata;
/* end address for the .data section, defined in linker script */
extern uint32_t _edata;
#ifdef MAIN
/* start address for the initialization values of the .ccmram section, defined in linker script */
extern uint32_t _siccmram;
/* start address for the .ccmram section, defined in linker script */
extern uint32_t _sccmram;
/* end address for the .ccmram section, defined in linker script */
extern uint32_t _eccmram;
#endif /* MAIN */
/* start address for the .bss section, defined in linker script */
extern uint32_t _sbss;
/* end address for the .bss section, defined in linker script */
extern uint32_t _ebss;
/* start address for stack, defined in linker script */
extern uint32_t _estack;

/**
  * \brief  This is the code that gets called when the processor first starts
  *         execution following a reset event. Only the absolute minimum is
  *         done, after which main() is called.
  * \param  None
  * \retval None
  */
void Reset_Handler(void);
void Reset_Handler(void)
{
  uint32_t *source;

  // ST Errata note 2.2.7 SRAM write error
  uint32_t dummy;
  dummy = *(volatile uint32_t*)SRAM1_BASE;
  dummy = *(volatile uint32_t*)(SRAM1_BASE + 0x008000UL); // +32KB
  dummy = *(volatile uint32_t*)(SRAM1_BASE + 0x010000UL); // +64KB
  dummy = *(volatile uint32_t*)SRAM2_BASE;
  dummy = *(volatile uint32_t*)CCMSRAM_BASE;
  (void)dummy;

  // Copying value of initialised variables from Flash to RAM (data section)
  source = &_sidata;
  for (uint32_t *destination = &_sdata; destination < &_edata;)
  {
    *(destination++) = *(source++);
  }

#ifdef MAIN
  // Initialising non-overlap region of CCM RAM from Flash
  source = &_siccmram;
  for (uint32_t *destination = &_sccmram; destination < &_eccmram;)
  {
    *(destination++) = *(source++);
  }
#endif /* MAIN */

  // set uninitialised variables to zero (bss section)
  for (uint32_t *destination = &_sbss; destination < &_ebss;)
  {
    *(destination++) = 0;
  }

  // start main program
  main();
}

/**
  * \brief  This is the code that gets called when the processor receives an
  *         unexpected interrupt.  This simply enters an infinite loop,
  *         preserving the system state for examination by a debugger.
  *
  * \param  None
  * \retval None
  */
void Default_Handler(void);
void Default_Handler(void)
{
  while(1);
}

/******************************************************************************
 Weak aliases for unimplemented interrupt handlers
******************************************************************************/
void ADC1_2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void ADC3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void ADC4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void ADC5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void COMP1_2_3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void COMP4_5_6_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void COMP7_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void CORDIC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void CRS_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel6_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel7_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA1_Channel8_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel6_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel7_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMA2_Channel8_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void DMAMUX_OVR_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI0_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI9_5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void EXTI15_10_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN1_IT0_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN1_IT1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN2_IT0_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN2_IT1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN3_IT0_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FDCAN3_IT1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FLASH_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FMAC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FMC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void FPU_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_FLT_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_Master_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIMA_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIMB_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIMC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIMD_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIME_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void HRTIM1_TIMF_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C1_EV_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C1_ER_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C2_EV_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C2_ER_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C3_EV_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C3_ER_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C4_EV_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void I2C4_ER_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void LPTIM1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void LPUART1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void PVD_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void QUADSPI_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void RCC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void RNG_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void RTC_Alarm_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void RTC_WKUP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void SAI1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void SPI1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void SPI2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void SPI3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void SPI4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TAMPER_STAMP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM1_BRK_TIM15_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM1_CC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM1_TRG_COM_TIM17_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM1_UP_TIM16_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM20_BRK_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM20_UP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM20_TRG_COM_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM20_CC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM6_DAC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM7_DAC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM8_BRK_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM8_UP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM8_TRG_COM_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void TIM8_CC_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void UART4_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void UART5_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void UCPD_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USART1_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USART2_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USART3_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USB_HP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USB_LP_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void USBWakeUp_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));
void WWDG_IRQHandler(void) __attribute__ ((weak, alias ("Default_Handler")));

/******************************************************************************
  Vector table
******************************************************************************/
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"  // due to the stack being part of the vector table and not a function, turn the pedantic warning off.
__attribute__ ((section(".isr_vector"))) void (* const table_interrupt_vector[])(void) =
{
  (void *) & _estack,                       /*      0x0000 0000, stack */
  Reset_Handler,                            /*      0x0000 0004, Reset */
  NMI_Handler,                              /*      0x0000 0008, NMI (in stm32g4xx_it.h) */
  HardFault_Handler,                        /*      0x0000 000C, Hard fault, error during exception processing (in stm32g4xx_it.h) */
  MemManage_Handler,                        /*      0x0000 0010, MPU fault (in stm32g4xx_it.h) */
  BusFault_Handler,                         /*      0x0000 0014, Prefetch fault or memory access error (in stm32g4xx_it.h) */
  UsageFault_Handler,                       /*      0x0000 0018, Undefined fault or illegal state (in stm32g4xx_it.h) */
  0,                                        /*      0x0000 001C, reserved */
  0,                                        /*      0x0000 0020, reserved */
  0,                                        /*      0x0000 0024, reserved */
  0,                                        /*      0x0000 0028, reserved */
  SVC_Handler,                              /*      0x0000 002C, SWI instruction, software interrupt (in stm32g4xx_it.h and FreeRTOS) */
  DebugMon_Handler,                         /*      0x0000 0030, Debug monitor (in stm32g4xx_it.h) */
  0,                                        /*      0x0000 0034, reserved */
  PendSV_Handler,                           /*      0x0000 0038, Pendable request for system service (in stm32g4xx_it.h and FreeRTOS) */
  SysTick_Handler,                          /*      0x0000 003C, System tick timer (in stm32g4xx_it.h and FreeRTOS) */
  WWDG_IRQHandler,                          /*   0, 0x0000 0040, Window watchdog interrupt */
  PVD_IRQHandler,                           /*   1, 0x0000 0044, Power voltage detector through EXTI line detection interrupt */
  TAMPER_STAMP_IRQHandler,                  /*   2, 0x0000 0048, Tamper and timestamp through EXTI19 line */
  RTC_WKUP_IRQHandler,                      /*   3, 0x0000 004C, RTC */
  FLASH_IRQHandler,                         /*   4, 0x0000 0050, Flash global interrupt */
  RCC_IRQHandler,                           /*   5, 0x0000 0054, RCC global interrupt */
  EXTI0_IRQHandler,                         /*   6, 0x0000 0058, EXTI line 0 interrupt */
  EXTI1_IRQHandler,                         /*   7, 0x0000 005C, EXTI line 1 interrupt */
  EXTI2_IRQHandler,                         /*   8, 0x0000 0060, EXTI line 2 interrupt */
  EXTI3_IRQHandler,                         /*   9, 0x0000 0064, EXTI line 3 interrupt */
  EXTI4_IRQHandler,                         /*  10, 0x0000 0068, EXTI line 4 interrupt */
  DMA1_Channel1_IRQHandler,                 /*  11, 0x0000 006C, DMA1 channel 1 interrupt */
  DMA1_Channel2_IRQHandler,                 /*  12, 0x0000 0070, DMA1 channel 2 interrupt */
  DMA1_Channel3_IRQHandler,                 /*  13, 0x0000 0074, DMA1 channel 3 interrupt */
  DMA1_Channel4_IRQHandler,                 /*  14, 0x0000 0078, DMA1 channel 4 interrupt */
  DMA1_Channel5_IRQHandler,                 /*  15, 0x0000 007C, DMA1 channel 5 interrupt */
  DMA1_Channel6_IRQHandler,                 /*  16, 0x0000 0080, DMA1 channel 6 interrupt */
  DMA1_Channel7_IRQHandler,                 /*  17, 0x0000 0084, DMA1 channel 7 interrupt */
  ADC1_2_IRQHandler,                        /*  18, 0x0000 0088, ADC1 and ADC2 interrupt */
  USB_HP_IRQHandler,                        /*  19, 0x0000 008C, USB high priority interrupts */
  USB_LP_IRQHandler,                        /*  20, 0x0000 0090, USB low priority interrupts */
  FDCAN1_IT0_IRQHandler,                    /*  21, 0x0000 0094, FDCAN1 interrupt 0 */
  FDCAN1_IT1_IRQHandler,                    /*  22, 0x0000 0098, FDCAN1 interrupt 1 */
  EXTI9_5_IRQHandler,                       /*  23, 0x0000 009C, EXTI line[9:5] interrupts */
  TIM1_BRK_TIM15_IRQHandler,                /*  24, 0x0000 00A0, Timer 1 Break / Timer 15 global interrupt */
  TIM1_UP_TIM16_IRQHandler,                 /*  25, 0x0000 00A4, Timer 1 Update / Timer 16 global interrupt */
  TIM1_TRG_COM_TIM17_IRQHandler,            /*  26, 0x0000 00A8, Timer 1 Trigger and Commutation / Timer 17 global interrupt */
  TIM1_CC_IRQHandler,                       /*  27, 0x0000 00AC, Timer 1 capture compare interrupt */
  TIM2_IRQHandler,                          /*  28, 0x0000 00B0, Timer 2 global interrupt */
  TIM3_IRQHandler,                          /*  29, 0x0000 00B4, Timer 3 global interrupt */
  TIM4_IRQHandler,                          /*  30, 0x0000 00B8, Timer 4 global interrupt */
  I2C1_EV_IRQHandler,                       /*  31, 0x0000 00BC, I2C1_EV global interrupt/EXTI line 23 interrupt */
  I2C1_ER_IRQHandler,                       /*  32, 0x0000 00C0, I2C1 error interrupt */
  I2C2_EV_IRQHandler,                       /*  33, 0x0000 00C4, I2C1_EV global interrupt/EXTI line 23 interrupt */
  I2C2_ER_IRQHandler,                       /*  34, 0x0000 00C8, I2C1 error interrupt */
  SPI1_IRQHandler,                          /*  35, 0x0000 00CC, SPI1 global interrupt */
  SPI2_IRQHandler,                          /*  36, 0x0000 00D0, SPI2 global interrupt */
  USART1_IRQHandler,                        /*  37, 0x0000 00D4, USART1 global interrupt/EXTI25 (USART1 wakeup event) */
  USART2_IRQHandler,                        /*  38, 0x0000 00D8, USART2 global interrupt/EXTI26 (USART2 wakeup event) */
  USART3_IRQHandler,                        /*  39, 0x0000 00DC, USART3 global interrupt/EXTI28 (USART3 wakeup event) */
  EXTI15_10_IRQHandler,                     /*  40, 0x0000 00E0, EXTI line[15:10] interrupts */
  RTC_Alarm_IRQHandler,                     /*  41, 0x0000 00E4, RTC alarm interrupt */
  USBWakeUp_IRQHandler,                     /*  42, 0x0000 00E8, USB wakeup from suspend/EXTI line 18 interrupts */
  TIM8_BRK_IRQHandler,                      /*  43, 0x0000 00EC, Timer 8 break interrupt/transition error/index error */
  TIM8_UP_IRQHandler,                       /*  44, 0x0000 00F0, Timer 8 update interrupt */
  TIM8_TRG_COM_IRQHandler,                  /*  45, 0x0000 00F4, Timer 8 trigger and commutation/direction change/index */
  TIM8_CC_IRQHandler,                       /*  46, 0x0000 00F8, Timer 8 capture compare interrupt */
  ADC3_IRQHandler,                          /*  47, 0x0000 00FC, ADC3 global interrupt */
  FMC_IRQHandler,                           /*  48, 0x0000 0100, FMC global interrupt */
  LPTIM1_IRQHandler,                        /*  49, 0x0000 0104, LPTIM1 global interrupt */
  TIM5_IRQHandler,                          /*  50, 0x0000 0108, Timer 5 global interrupt */
  SPI3_IRQHandler,                          /*  51, 0x0000 010C, SPI3 global interrupt */
  UART4_IRQHandler,                         /*  52, 0x0000 0110, UART4 global interrupt/EXTI line 34 interrupt */
  UART5_IRQHandler,                         /*  53, 0x0000 0114, UART5 global interrupt/EXTI line 35 interrupt */
  TIM6_DAC_IRQHandler,                      /*  54, 0x0000 0118, Timer 6 global interrupt / DAC1/3 underrun interrupt */
  TIM7_DAC_IRQHandler,                      /*  55, 0x0000 011C, Timer 7 global interrupt / DAC2/4 underrun interrupt */
#ifdef MAIN /* save space in bootloader by omitting unused vector table entries */
  DMA2_Channel1_IRQHandler,                 /*  56, 0x0000 0120, DMA2 channel 1 interrupt */
  DMA2_Channel2_IRQHandler,                 /*  57, 0x0000 0124, DMA2 channel 2 interrupt */
  DMA2_Channel3_IRQHandler,                 /*  58, 0x0000 0128, DMA2 channel 3 interrupt */
  DMA2_Channel4_IRQHandler,                 /*  59, 0x0000 012C, DMA2 channel 4 interrupt */
  DMA2_Channel5_IRQHandler,                 /*  60, 0x0000 0130, DMA2 channel 5 interrupt */
  ADC4_IRQHandler,                          /*  61, 0x0000 0134, ADC4 global interrupt */
  ADC5_IRQHandler,                          /*  62, 0x0000 0138, ADC5 global interrupt */
  UCPD_IRQHandler,                          /*  63, 0x0000 013C, USBPD global interrupt/EXTI line 43 interrupt */
  COMP1_2_3_IRQHandler,                     /*  64, 0x0000 0140, Comparator 1, 2, 3/EXTI lines 21, 22, 29 interrupts */
  COMP4_5_6_IRQHandler,                     /*  65, 0x0000 0144, Comparator 4, 5, 6/EXTI lines 30, 31, 32 interrupts */
  COMP7_IRQHandler,                         /*  66, 0x0000 0148, Comparator 7/EXTI line 33 interrupts */
  HRTIM1_Master_IRQHandler,                 /*  67, 0x0000 014C, HRTIM1 master timer interrupt */
  HRTIM1_TIMA_IRQHandler,                   /*  68, 0x0000 0150, HRTIM1 timer A interrupt */
  HRTIM1_TIMB_IRQHandler,                   /*  69, 0x0000 0154, HRTIM1 timer B interrupt */
  HRTIM1_TIMC_IRQHandler,                   /*  70, 0x0000 0158, HRTIM1 timer C interrupt */
  HRTIM1_TIMD_IRQHandler,                   /*  71, 0x0000 015C, HRTIM1 timer D interrupt */
  HRTIM1_TIME_IRQHandler,                   /*  72, 0x0000 0160, HRTIM1 timer E interrupt */
  HRTIM1_FLT_IRQHandler,                    /*  73, 0x0000 0164, HRTIM1 fault interrupt */
  HRTIM1_TIMF_IRQHandler,                   /*  74, 0x0000 0168, HRTIM1 timer F interrupt */
  CRS_IRQHandler,                           /*  75, 0x0000 016C, Clock Recovery System interrupt */
  SAI1_IRQHandler,                          /*  76, 0x0000 0170, Serial Audio Interface interrupt */
  TIM20_BRK_IRQHandler,                     /*  77, 0x0000 0174, Timer 20 break interrupt/transition error/index error */
  TIM20_UP_IRQHandler,                      /*  78, 0x0000 0178, Timer 20 update interrupt */
  TIM20_TRG_COM_IRQHandler,                 /*  79, 0x0000 017C, Timer 20 trigger and commutation interrupt */
  TIM20_CC_IRQHandler,                      /*  80, 0x0000 0180, Timer 20 capture compare interrupt */
  FPU_IRQHandler,                           /*  81, 0x0000 0184, Floating point unit interrupt */
  I2C4_EV_IRQHandler,                       /*  82, 0x0000 0188, I2C4 event interrupt/EXTI line 42 interrupt */
  I2C4_ER_IRQHandler,                       /*  83, 0x0000 018C, I2C4 error interrupt */
  SPI4_IRQHandler,                          /*  84, 0x0000 0190, SPI4 global interrupt */
  0,                                        /*  85, 0x0000 0194, reserved */
  FDCAN2_IT0_IRQHandler,                    /*  86, 0x0000 0198, FDCAN2 interrupt 0 */
  FDCAN2_IT1_IRQHandler,                    /*  87, 0x0000 019C, FDCAN2 interrupt 1 */
  FDCAN3_IT0_IRQHandler,                    /*  88, 0x0000 01A0, FDCAN3 interrupt 0 */
  FDCAN3_IT1_IRQHandler,                    /*  89, 0x0000 01A4, FDCAN3 interrupt 1 */
  RNG_IRQHandler,                           /*  90, 0x0000 01A8, RNG global interrupt */
  LPUART1_IRQHandler,                       /*  91, 0x0000 01AC, LPUART1 global interrupt */
  I2C3_EV_IRQHandler,                       /*  92, 0x0000 01B0, I2C3 event/EXTI line 27 interrupts */
  I2C3_ER_IRQHandler,                       /*  93, 0x0000 01B4, I2C3 error interrupt */
  DMAMUX_OVR_IRQHandler,                    /*  94, 0x0000 01B8, DMAMUX overrun interrupt */
  QUADSPI_IRQHandler,                       /*  95, 0x0000 01BC, QUADSPI global interrupt */
  DMA1_Channel8_IRQHandler,                 /*  96, 0x0000 01C0, DMA1 channel 8 interrupt */
  DMA2_Channel6_IRQHandler,                 /*  97, 0x0000 01C4, DMA2 channel 6 interrupt */
  DMA2_Channel7_IRQHandler,                 /*  98, 0x0000 01C8, DMA2 channel 7 interrupt */
  DMA2_Channel8_IRQHandler,                 /*  99, 0x0000 01CC, DMA2 channel 8 interrupt */
  CORDIC_IRQHandler,                        /* 100, 0x0000 01D0, Cordic interrupt */
  FMAC_IRQHandler,                          /* 102, 0x0000 01D4, FMAC interrupt */
#endif
};
#pragma GCC diagnostic pop
