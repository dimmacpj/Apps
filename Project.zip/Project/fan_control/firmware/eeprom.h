/**************************************************************************//**
  \file   eeprom.h
  \brief  eeprom interface header file
  \author Arthur de Beun
  \date   2013 September 27 (created)

******************************************************************************/
#ifndef FILE_EEPROM_H /* sentinel */
#define FILE_EEPROM_H

#include "FreeRTOS.h"
#include "queue.h"

#include "ena_datatype.h"
#include "ena_error_codes.h"

#define EEPROM_TASK_STACK_SIZE (configMINIMAL_STACK_SIZE + 20)

/* include test code to create I2C EEPROM lockup and test recovery */
#define DEBUG_I2C_LOCKUP (0)

/* global function prototypes */
portTASK_FUNCTION_PROTO(Eeprom_Task, pvParameters );
t_error_code eeprom_to_default(tMSG read_write, uint32_t timestamp, uint32_t port);
TaskHandle_t eeprom_task_create(void);

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

EXTERN TaskHandle_t Eeprom_Task_Handle;
EXTERN QueueHandle_t eequeue;

#undef EXTERN
#undef INIT

#endif /* end sentinel */
