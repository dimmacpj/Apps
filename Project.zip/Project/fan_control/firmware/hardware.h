/**************************************************************************//**
  \file   hardware.h
  \brief  hardware configuration header file
******************************************************************************/
#ifndef FILE_HARDWARE_H                     /* sentinel */
#define FILE_HARDWARE_H

#include "stm32g4xx.h"                      // from CMSIS
#include "stm32g4xx_ll_adc.h"
#include "stm32g4xx_ll_bus.h"
#include "stm32g4xx_ll_comp.h"
#include "stm32g4xx_ll_cordic.h"
#include "stm32g4xx_ll_crc.h"
#include "stm32g4xx_ll_dac.h"
#include "stm32g4xx_ll_dma.h"
#include "stm32g4xx_ll_gpio.h"
#include "stm32g4xx_ll_hrtim.h"
#include "stm32g4xx_ll_i2c.h"
#include "stm32g4xx_ll_opamp.h"
#include "stm32g4xx_ll_pwr.h"
#include "stm32g4xx_ll_rcc.h"
#include "stm32g4xx_ll_tim.h"
#include "stm32g4xx_ll_usart.h"

#include "ena_datatype.h"
#include "periph_bb.h"

//#define DEV_BOARD (1)  // Nucleo

/* Pin assignment:

    1 VBAT
    2 PC13
    3 PC14
    4 PC15
    5 PF0 - OSC_IN
    6 PF1 - OSC_OUT
    7 NRST
    8 PC0
    9 PC1            NTC_PCB           analogue in
   10 PC2            NTC_1             analogue in
   11 PC3            NTC_2             analogue in
   12 PA0
   13 PA1
   14 PA2
   15 VSS
   16 VDD
   17 PA3
   18 PA4            DAC_TP1           analogue out (test point)
   19 PA5            DAC_TP2           analogue out (test point)
   20 PA6
   21 PA7
   22 PC4
   23 PC5            Address Select    digital in, pull up
   24 PB0
   25 PB1
   26 PB2
   27 VSSA
   28 VREF+
   29 VDDA
   30 PB10           SBI1 tx           digital out
   31 VSS
   32 VDD
   33 PB11           SBI1 rx           digital in
   34 PB12           AUX V             analogue in
   35 PB13           PWM Fan 2         digital out
   36 PB14           Tacho Fan 2       digital in
   37 PB15
   38 PC6            Tacho Fan 1       digital in
   39 PC7            PWM Fan 1         digital out
   40 PC8            I2C SCL EEPROM    digital out
   41 PC9            I2C SDA EEPROM    digital in/out
   42 PA8
   43 PA9
   44 PA10
   45 PA11
   46 PA12
   47 VSS
   48 VDD
   49 PA13           SWDAT             digital in, pullup
   50 PA14           SWCLK             digital in, pullup
   51 PA15
   52 PC10           debug UART TX     digital out
   53 PC11           debug UART RX     digital in, pullup
   54 PC12           Heartbeat LED     digital out
   55 PD2
   56 PB3            SWO               digital out
   57 PB4
   58 PB5
   59 PB6            SBI2 tx           digital out
   60 PB7            SBI2 rx           digital in
   61 PB8
   62 PB9
   63 VSS
   64 VDD

  Port pin usage:
      PA              PB                 PC                PD         PF             Notes:
   0  n.c.            n.c.               n.c.              (missing)  n.c.
   1  n.c.            n.c.               NTC_PCB           (missing)  n.c.
   2  n.c.            n.c.               NTC_1             n.c.       (missing)
   3  n.c.            (SWO)              NTC_2             (missing)  (missing)
   4  DAC TP1         (RST)              n.c.              (missing)  (missing)
   5  DAC TP2         n.c.               Address Select    (missing)  (missing)
   6  n.c.            SBI2 tx            Tacho Fan 1       (missing)  (missing)
   7  n.c.            SBI2 rx            PWM Fan 1         (missing)  (missing)
   8  n.c.            n.c.               EEPROM SCL        (missing)  (missing)
   9  n.c.            n.c.               EEPROM SDA        (missing)  (missing)
  10  n.c.            SBI1 tx            debug UART TX     (missing)  (missing)
  11  n.c.            SBI1 rx            debug UART RX     (missing)  (missing)
  12  n.c.            AUX V              Heartbeat LED     (missing)  (missing)
  13  ISP SWDAT       PWM Fan 2          n.c.              (missing)  (missing)
  14  ISP SWCLK       Tacho Fan 2        n.c.              (missing)  (missing)
  15  n.c. (JTDI)     n.c.               n.c.              (missing)  (missing)
*/

#define PIN_A_UNUSED (LL_GPIO_PIN_15 | LL_GPIO_PIN_12 | LL_GPIO_PIN_11 | LL_GPIO_PIN_10 \
                     | LL_GPIO_PIN_9 | LL_GPIO_PIN_8 | LL_GPIO_PIN_7 | LL_GPIO_PIN_6 \
                     | LL_GPIO_PIN_3 | LL_GPIO_PIN_2 | LL_GPIO_PIN_1 | LL_GPIO_PIN_0 )

#define PIN_B_UNUSED (LL_GPIO_PIN_15 | LL_GPIO_PIN_9 | LL_GPIO_PIN_8 | LL_GPIO_PIN_5 \
                     | LL_GPIO_PIN_2 | LL_GPIO_PIN_1 | LL_GPIO_PIN_0 )

#define PIN_C_UNUSED (LL_GPIO_PIN_15 | LL_GPIO_PIN_14 | LL_GPIO_PIN_13 | LL_GPIO_PIN_5 \
                     | LL_GPIO_PIN_4 | LL_GPIO_PIN_0 )

#define PIN_D_UNUSED (LL_GPIO_PIN_2)
#define PIN_F_UNUSED (LL_GPIO_PIN_0 | LL_GPIO_PIN_1)

/*
  Timer usage:
               bootloader      | Main
  TIM1                         | PWM Fan 2
  TIM2                         |
  TIM3                         | Tacho Fan 1
  TIM4                         |
  TIM5                         | timestamp
  TIM6 (basic) timeout         |
  TIM7 bootloader loop         |
  TIM8                         | PWM Fan 2
  TIM15                        | Tacho Fan 2
  TIM16                        |
  TIM17                        |
  TIM20                        |
  LPTIM1                       |
  HRTIM                        |

  Peripheral usage:
  SPI1                         |
  SPI2                         |
  SPI3                         |
  SPI4                         |
  USART1                       | SBI2 comms
  USART2                       |
  USART3   SBI1 comms
  UART4    debug
  UART5                        |
  LPUART1                      |
  I2C2                         |
  I2C3                         |  EEPROM
  I2C4
  CAN                          |
  COMP2                        |
  COMP4                        |
  COMP6                        |
  DAC1-1    debug (unused)
  DAC1-2    debug (unused)
  DAC2-1                       |
  DAC3-1                       |
  DAC3-2                       |
  DAC4-1                       |
  DAC4-2                       |
  OPAMP1                       |
  OPAMP2                       |
  OPAMP3                       |
  OPAMP4                       |
  OPAMP5                       |
  OPAMP6                       |

  DMA1-1                       |
  DMA1-2                       |
  DMA1-3                       |
  DMA1-4                       |
  DMA1-5                       |
  DMA1-6                       |
  DMA1-7                       |
  DMA1-8                       |
  DMA2-1                       |
  DMA2-2                       |
  DMA2-3                       |
  DMA2-4                       |
  DMA2-5                       |
  DMA2-6                       |
  DMA2-7                       |
  DMA2-8                       |

******************************************************************************/
#define BOOTLOADER_ID (0x0005)

/* bootloader size, defined in linker script (main_bootloader.ld) */
extern uint32_t _bootloader_size;
#define BOOTLOADER_SIZE ((uint32_t)((uint8_t*)(&_bootloader_size)))
#define STM_BOOTLOADER_CRC_ADDR (0x08000000 + BOOTLOADER_SIZE - 4u)
#define STM_MAIN_ROM_END (0x0801FFFF)       /* 128kB, including the CRC */

void hardware_init(void);

/************************************* IO  ***********************************/
#define ADDRESS_SELECT_PIN (LL_GPIO_PIN_5)
#define ADDRESS_SELECT_GPIO_PORT (GPIOC)
#define ADDRESS_SELECT_PULL (LL_GPIO_PULL_UP)
__STATIC_FORCEINLINE bool read_address_select_pin(void) {return ADDRESS_SELECT_PIN == (ADDRESS_SELECT_GPIO_PORT->ODR & ADDRESS_SELECT_PIN);}

#define DEBUG_PIN (LL_GPIO_PIN_4)
#define DEBUG_PIN_GPIO_PORT (GPIOA)
__STATIC_FORCEINLINE void debug_pin_high(void) {DEBUG_PIN_GPIO_PORT->BSRR = DEBUG_PIN;}
__STATIC_FORCEINLINE void debug_pin_low(void) {DEBUG_PIN_GPIO_PORT->BRR = DEBUG_PIN;}

/************************************* LED ***********************************/
#if DEV_BOARD
#define LED_HEARTBEAT_PIN (LL_GPIO_PIN_5)
#define LED_HEARTBEAT_GPIO_PORT (GPIOA)
#else
#define LED_HEARTBEAT_PIN (LL_GPIO_PIN_12)
#define LED_HEARTBEAT_GPIO_PORT (GPIOC)
#endif
__STATIC_FORCEINLINE void LED_heartbeat_on(void) {LED_HEARTBEAT_GPIO_PORT->BSRR = LED_HEARTBEAT_PIN;}
__STATIC_FORCEINLINE void LED_heartbeat_off(void) {LED_HEARTBEAT_GPIO_PORT->BRR = LED_HEARTBEAT_PIN;}
/*********************************** EEPROM **********************************/
/**
  * @brief  Configures I2C port.
  * @retval None
  */
#define EEPROM_I2C             (I2C3)
#define EEPROM_I2C_SCL_PIN     (LL_GPIO_PIN_8)
#define EEPROM_I2C_SCL_PORT    (GPIOC)
#define EEPROM_I2C_SCL_AF      (LL_GPIO_AF_8)
#define EEPROM_I2C_SDA_PIN     (LL_GPIO_PIN_9)
#define EEPROM_I2C_SDA_PORT    (GPIOC)
#define EEPROM_I2C_SDA_AF      (LL_GPIO_AF_8)
#define EEPROM_I2C_CLK_EN      (BB_RCC_APB1ENR1_I2C3EN)
#define EEPROM_I2C_CLK_SOURCE  (LL_RCC_I2C3_CLKSOURCE_SYSCLK)

__STATIC_FORCEINLINE void eeprom_i2c_scl_high(void) {EEPROM_I2C_SCL_PORT->BSRR = EEPROM_I2C_SCL_PIN;}
__STATIC_FORCEINLINE void eeprom_i2c_scl_low(void) {EEPROM_I2C_SCL_PORT->BRR = EEPROM_I2C_SCL_PIN;}

/**
 * \brief Definitions for EEPROM, using CAT24C08 (On Semiconductor).
 *        Size is 1kByte. All the address inputs are low (only A2 matters).
 *        This results in an I2C address of 1 0 1 0 0 A9 A8 r/!w.
 */
#define E2END (0x03FF)                        /* last EEPROM address */
#define I2C_ADDR_EEPROM (0xA0)


/*********************************** ADC ************************************/
#define ADC_REF_V (3.3F)
#define AUX_HW_GAIN (0.15825F) // [V/V] R927 15k, R962 10k, R928 4k7.
#define AUX_GAIN (ADC_REF_V / (ADC_12BIT_RANGE * AUX_HW_GAIN))

#define NTC_PCB_PIN  (LL_GPIO_PIN_1)
#define NTC_PCB_PORT (GPIOC)
#define NTC_PCB_ADC_CH (LL_ADC_CHANNEL_7)
#define NTC_1_PIN  (LL_GPIO_PIN_2)
#define NTC_1_PORT (GPIOC)
#define NTC_1_ADC_CH (LL_ADC_CHANNEL_8)
#define NTC_2_PIN  (LL_GPIO_PIN_3)
#define NTC_2_PORT (GPIOC)
#define NTC_2_ADC_CH (LL_ADC_CHANNEL_9)

#define AUX_PIN  (LL_GPIO_PIN_12)
#define AUX_PORT (GPIOB)
#define AUX_ADC_CH (LL_ADC_CHANNEL_11)
#define AUX_ADC_GAIN ()


/**********************************FAN **************************************/
#define FAN1_TACHO_PIN  (LL_GPIO_PIN_6)
#define FAN1_TACHO_PORT (GPIOC)
#define FAN1_TACHO_AF   (LL_GPIO_AF_2)
#define FAN1_TACHO_PULL (LL_GPIO_PULL_NO)
#define FAN1_TACHO_TIMER (TIM3)
#define FAN1_TACHO_TIMER_CH (LL_TIM_CHANNEL_CH1)
#define FAN1_TACHO_TIMER_INPUT_SEL (LL_TIM_TS_TI1FP1)
#define FAN1_TACHO_TIMER_CLK_EN (BB_RCC_APB1ENR1_TIM3EN)

#define FAN1_PWM_PIN  (LL_GPIO_PIN_7)
#define FAN1_PWM_PORT (GPIOC)
#define FAN1_PWM_AF   (LL_GPIO_AF_4)
#define FAN1_PWM_TIMER (TIM8)
#define FAN1_PWM_TIMER_CH (LL_TIM_CHANNEL_CH2)
#define FAN1_PWM_TIMER_CH_OUTPUT (LL_TIM_CHANNEL_CH2)
#define FAN1_PWM_TIMER_CCR (FAN1_PWM_TIMER->CCR2)
#define FAN1_PWM_TIMER_CLK_EN (BB_RCC_APB2ENR_TIM8EN)

#define FAN2_TACHO_PIN  (LL_GPIO_PIN_14)
#define FAN2_TACHO_PORT (GPIOB)
#define FAN2_TACHO_AF   (LL_GPIO_AF_1)
#define FAN2_TACHO_PULL (LL_GPIO_PULL_NO)
#define FAN2_TACHO_TIMER (TIM15)
#define FAN2_TACHO_TIMER_CH (LL_TIM_CHANNEL_CH1)
#define FAN2_TACHO_TIMER_INPUT_SEL (LL_TIM_TS_TI1FP1)
#define FAN2_TACHO_TIMER_CLK_EN (BB_RCC_APB2ENR_TIM15EN)

#define FAN2_PWM_PIN  (LL_GPIO_PIN_13)
#define FAN2_PWM_PORT (GPIOB)
#define FAN2_PWM_AF   (LL_GPIO_AF_6)
#define FAN2_PWM_TIMER (TIM1)
#define FAN2_PWM_TIMER_CH (LL_TIM_CHANNEL_CH1)
#define FAN2_PWM_TIMER_CH_OUTPUT (LL_TIM_CHANNEL_CH1N)
#define FAN2_PWM_TIMER_CCR (FAN2_PWM_TIMER->CCR1)
#define FAN2_PWM_TIMER_CLK_EN (BB_RCC_APB2ENR_TIM1EN)

/********************************** SBI *************************************/

#if DEV_BOARD
#define SBI1_UART (USART2)
#define SBI1_TX_PIN (LL_GPIO_PIN_2)
#define SBI1_TX_PORT (GPIOA)
#define SBI1_TX_AF (LL_GPIO_AF_7)
#define SBI1_RX_PIN  (LL_GPIO_PIN_3)
#define SBI1_RX_PORT (GPIOA)
#define SBI1_RX_PULL (LL_GPIO_PULL_NO)
#define SBI1_RX_AF (LL_GPIO_AF_7)
#define SBI1_RCC_CLK_EN (BB_RCC_APB1ENR1_USART2EN)
#define SBI1_IRQ_N (USART2_IRQn)
#define SBI1_IRQ_HANDLER USART2_IRQHandler
#else
#define SBI1_UART (USART3)
#define SBI1_TX_PIN (LL_GPIO_PIN_10)
#define SBI1_TX_PORT (GPIOB)
#define SBI1_TX_AF (LL_GPIO_AF_7)
#define SBI1_RX_PIN  (LL_GPIO_PIN_11)
#define SBI1_RX_PORT (GPIOB)
#define SBI1_RX_PULL (LL_GPIO_PULL_NO)
#define SBI1_RX_AF (LL_GPIO_AF_7)
#define SBI1_RCC_CLK_EN (BB_RCC_APB1ENR1_USART3EN)
#define SBI1_IRQ_N (USART3_IRQn)
#define SBI1_IRQ_HANDLER USART3_IRQHandler
#endif
#define SBI2_UART (USART1)
#define SBI2_TX_PIN (LL_GPIO_PIN_6)
#define SBI2_TX_PORT (GPIOB)
#define SBI2_TX_AF (LL_GPIO_AF_7)
#define SBI2_RX_PIN  (LL_GPIO_PIN_7)
#define SBI2_RX_PORT (GPIOB)
#define SBI2_RX_PULL (LL_GPIO_PULL_NO)
#define SBI2_RX_AF (LL_GPIO_AF_7)
#define SBI2_RCC_CLK_EN (BB_RCC_APB2ENR_USART1EN)
#define SBI2_IRQ_N (USART1_IRQn)
#define SBI2_IRQ_HANDLER USART1_IRQHandler

/**************************** DEBUG UART *********************************/
#define DEBUG_TX_PIN    (LL_GPIO_PIN_10)
#define DEBUG_TX_PORT   (GPIOC)
#define DEBUG_TX_AF     (LL_GPIO_AF_5)

#if 0  // rx unused
#define DEBUG_RX_PIN    (LL_GPIO_PIN_11)
#define DEBUG_RX_PORT   (GPIOC)
#define DEBUG_RX_AF     (LL_GPIO_AF_5)
#define DEBUG_RX_PULL   (LL_GPIO_PULL_UP)
#endif

#define DEBUG_UART (UART4)
#define DEBUG_UART_RCC_CLK_EN (BB_RCC_APB1ENR1_UART4EN)


/*********************** DEBUG DAC (Unused) *********************************/
#define DEBUG1_DAC_PIN    (LL_GPIO_PIN_10)
#define DEBUG1_DAC_PORT   (GPIOC)
#define DEBUG1_DAC        (DAC1)

#define DEBUG2_DAC_PIN    (LL_GPIO_PIN_10)
#define DEBUG2_DAC_PORT   (GPIOC)
#define DEBUG2_DAC        (DAC1)

#endif                                      /* end sentinel */
