/**************************************************************************//**
  \file   variants.c
  \brief  contains variant specific values header file

  model dependent values and limits

******************************************************************************/
/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"

#include "ena_datatype.h"
#include "ena_error_codes.h"
#include "ena_maths.h"

/* Hardware and board configuration */
#include "hardware.h"

#define DEFINE_VARS
#include "variants.h"                       /* includes global variables */
#include "variant_mpg3rgfc_01.h"
/* include other variant header files here e.g.
   #include "variant_name_02.h"
   #include "variant_anothername_02.h"
*/
#undef DEFINE_VARS

#include "db_table.h"
#include "db.h"
#include "control.h"

const tV* const variants[1] =
{
  &vrnt_mpg3rgfc_01
  /* add pointers to each variant here */
};


t_error_code set_variant(void)
{
  const uint32_t bv_cpy = board_version;
  const uint32_t pid_cpy = product_id;
  /* find the variant that matches 
    TODO(JC): Handle invalid varient */
  for (uint32_t i = 0; i < (sizeof(variants)/sizeof(variants[0])); i++)
  {
    if(variants[i]->product_id == pid_cpy)
    {
      if(variants[i]->board_version == bv_cpy)
      {
        /* match found */
        vrnt = *variants[i]; // copy
        break;
      }
    }
  }
  return ERR_SUCCESS;
}

/* dB function for product ID */
t_error_code fdb_product_id(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error;

  switch(read_write)
  {
    case MESSAGE_READ:
      /* nothing more to do on read */
      error = ERR_SUCCESS;
      break;

    case MESSAGE_WRITE_INIT:
    case MESSAGE_WRITE:
      error = set_variant();
      break;

    default:
       error = ERR_FAIL;
      break;
  }
  return error;
}

/* dB function for board version */
t_error_code fdb_board_version(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code error;

  switch(read_write)
  {
    case MESSAGE_READ:
      /* nothing more to do on read */
      error = ERR_SUCCESS;
      break;

    case MESSAGE_WRITE_INIT:
    case MESSAGE_WRITE:
      error = set_variant();
      break;

    default:
      error = ERR_FAIL;
      break;
  }
  return error;
}
