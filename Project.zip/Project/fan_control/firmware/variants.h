/**************************************************************************//**
  \file   variants.h
  \brief  contains variant specific values header file
  \author Arthur de Beun
  \date   2014 August 22 (created)

  model dependent default values and limits

******************************************************************************/
#ifndef FILE_VARIANTS_H                     /* sentinel */
#define FILE_VARIANTS_H

#include "ena_datatype.h"
#include "ena_error_codes.h"

t_error_code fdb_product_id(tMSG read_write, uint32_t timestamp, uint32_t port);    // ??
t_error_code fdb_board_version(tMSG read_write, uint32_t timestamp, uint32_t port); // ?B

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(...) = __VA_ARGS__
#else                                       // declarations
#define EXTERN extern
#define INIT(...)
#endif

EXTERN volatile uint32_t product_id;             // ?? product ID

EXTERN volatile uint16_t board_version;          // board version */

#define LATEST_BOARD_VERSION 1

#define SBI_DEVICE_ADDR_LOW  (96)
#define SBI_DEVICE_ADDR_HIGH (97)
// all members of the struct must be 32 bit data type.
typedef struct
{
  uint32_t product_id;
  uint32_t board_version;
} tV;                                     /* */


EXTERN volatile tV vrnt;


#undef EXTERN
#undef INIT

#endif                                      /* end sentinel */
