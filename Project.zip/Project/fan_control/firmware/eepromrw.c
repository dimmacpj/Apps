/**************************************************************************//**
  \file   eepromrw.c
  \brief  eeprom read/write interface
  \author Arthur de Beun
  \date   2013 September 30 (created)

  EEPROM read and write routines
  Part number CAT24C08, 8 kBit, 1 kByte, On Semiconductor
  All the address inputs are low (only A2 matters). This results in an I2C
  address of 1 0 1 0 0 A9 A8 r/!w.

  CAT24C08 write cycle time is < 5ms.

******************************************************************************/
#include <stdio.h>

/* FreeRTOS */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "timers.h"

#include "ena_datatype.h"
#include "ena_driver_stm32g4.h"
#include "ena_maths.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "eeprom.h"
#define DEFINE_VARS
#include "eepromrw.h"
#undef DEFINE_VARS
#include "main.h"
#include "events.h"

#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

static TimerHandle_t eetimer;
static volatile bool ee_timeout;       // flag to indicate eeprom access took too long

static void eeprom_i2c_init(void);
static void eeprom_i2c_gpio_init(void);
static void eeprom_i2c_low_level_init(void);

void vEetimerCallback( TimerHandle_t pxTimer );

static TimerHandle_t eetimer_create(void);

void eeprom_init(void)
{
  eetimer = eetimer_create();
  eeprom_i2c_init();

#if DEBUG_I2C_LOCKUP
  /* Causes the clock to the I2C peripheral to be turned off in the middle of a read from EEPROM
     with the data line held low. manually resetting the STM32 will now trigger the SDA-stuck-low
     code. Uses the skip-zero byte at address 0 to read a zero data value. */
  uint8_t ub_zero = 0;
  xTimerReset(eetimer, 0);
  eeprom_wr(0, &ub_zero, 1);            // make sure we have a zero value to read
  eeprom_rd(0, &ub_zero, 1);            // this will cause the EEPROM to lock up
  xTimerStop(eetimer, 0);
#endif
}


uint8_t eeprom_rd(uint16_t ee_addr, uint8_t *p_data, uint8_t num_to_read)
{
  uint8_t crc_result = 0xFF;
  uint8_t addr_h;
  uint8_t addr_l;
#if DEBUG_I2C_LOCKUP
  int32_t l_i2c_lockup_counter = 0;
#endif
  xTimerReset(eetimer, 0);
  ee_timeout = false;

  addr_l = (uint8_t)(0x00FF & ee_addr);
  addr_h = (uint8_t)(0x000E & (ee_addr >> 7));

  /* Configure slave address with upper part of memory address, number of bytes (address), reload and generate start */
  LL_I2C_HandleTransfer(EEPROM_I2C,
                        I2C_ADDR_EEPROM + addr_h,  // SlaveAddr
                        LL_I2C_ADDRSLAVE_7BIT,        // SlaveAddrSize
                        1,                            // TransferSize [bytes]
                        LL_I2C_MODE_SOFTEND,          // EndMode
                        LL_I2C_GENERATE_START_WRITE); // Request

  PRINTF("EERD addr %02X", I2C_ADDR_EEPROM + addr_h);
  /* Wait until TXIS flag is set */
  while(!LL_I2C_IsActiveFlag_TXIS(EEPROM_I2C))
  {
    if(ee_timeout)
    {
      PRINTF(", timeout 1\n");
      return ERR_TIMEOUT;
    }
  }

  /* Send low byte of memory address */
  LL_I2C_TransmitData8(EEPROM_I2C, addr_l);
  PRINTF(", low addr %02X, data:", addr_l);
  /* Wait until TC flag is set */
  while(!LL_I2C_IsActiveFlag_TC(EEPROM_I2C))
  {
    if(ee_timeout)
    {
      PRINTF(", timeout 2\n");
      return ERR_TIMEOUT;
    }

  }

  /* set Slave Address, set read request, generate Start and set end mode */
  LL_I2C_HandleTransfer(EEPROM_I2C,
                        I2C_ADDR_EEPROM + addr_h, // SlaveAddr
                        LL_I2C_ADDRSLAVE_7BIT,       // SlaveAddrSize
                        num_to_read + 1,            // TransferSize [bytes]
                        LL_I2C_MODE_AUTOEND,         // EndMode
                        LL_I2C_GENERATE_START_READ); // Request

  for(uint8_t i = 0; i < num_to_read; i++)
  {
    /* Wait until RXNE flag is set */
    while(!LL_I2C_IsActiveFlag_RXNE(EEPROM_I2C))
    {
      if(ee_timeout)
      {
        PRINTF(", timeout 3\n");
        return ERR_TIMEOUT;
      }
#if DEBUG_I2C_LOCKUP
      if(l_i2c_lockup_counter++ > 15)
        LL_AHB1_GRP1_DisableClock(LL_APB1_GRP1_PERIPH_EEPROM_I2C); // disable APB1 peripheral clock for EEPROM_I2C
#endif
    }

    /* Read data from RXDR */
    *p_data = LL_I2C_ReceiveData8(EEPROM_I2C);
    PRINTF(" %02X", *p_data);

    crc_result = crc8(crc_result, *p_data);
    p_data++;
  }

  /* Wait until RXNE flag is set */
  while(!LL_I2C_IsActiveFlag_RXNE(EEPROM_I2C))
  {
    if(ee_timeout)
    {
      PRINTF(", timeout 4\n");
      return ERR_TIMEOUT;
    }
  }

  /* Read data from RXDR, this is the checksum */
  crc_result = crc8(crc_result, LL_I2C_ReceiveData8(EEPROM_I2C));

  /* Wait until STOPF flag is set */
  while(!LL_I2C_IsActiveFlag_STOP(EEPROM_I2C))
  {
    if(ee_timeout)
    {
      PRINTF(", timeout 5\n");
      return ERR_TIMEOUT;
    }
  }

  LL_I2C_ClearFlag_STOP(EEPROM_I2C);
  xTimerStop(eetimer, 0);
  if(0 == crc_result)
  {
    PRINTF(", crc ok\n");
    return ERR_SUCCESS;
  }
  else
  {
    PRINTF(", crc fail\n");
    return ERR_CHECKSUM;
  }
}

uint8_t eeprom_wr(uint16_t ee_addr, const uint8_t* p_data, uint8_t num_to_write)
{
  uint8_t addr_h;
  uint8_t addr_l;
  uint8_t page_bytes_left;
  uint8_t page_bytes_to_write;
  uint8_t crc_result = 0xFF;

  xTimerReset(eetimer, 0);
  ee_timeout = false;
  num_to_write++;                          // add one more byte for checksum
  PRINTF("EEWR");
  while(num_to_write > 0)
  {
    /* write data bytes either till the end of a page or number of bytes left to write */
    addr_l = (uint8_t)(0x00FF & ee_addr);
    addr_h = (uint8_t)(0x000E & (ee_addr >> 7));
    page_bytes_left = 16 - (addr_l & 0x0F);
    page_bytes_to_write = min(num_to_write, page_bytes_left);
    ee_addr += page_bytes_to_write;

    /* Configure slave address with upper part of memory address, number of bytes (the address), reload and generate start */
    PRINTF(" addr %02X", I2C_ADDR_EEPROM + addr_h);
    LL_I2C_HandleTransfer(EEPROM_I2C,
                          I2C_ADDR_EEPROM + addr_h,  // SlaveAddr
                          LL_I2C_ADDRSLAVE_7BIT,        // SlaveAddrSize
                          1,                            // TransferSize [bytes]
                          LL_I2C_MODE_RELOAD,           // EndMode
                          LL_I2C_GENERATE_START_WRITE); // Request
    /* Wait until TXIS flag is set */
    while(!LL_I2C_IsActiveFlag_TXIS(EEPROM_I2C))
    {
      if(ee_timeout)
      {
        PRINTF(", timeout 1\n");
        return ERR_TIMEOUT;
      }
    }

    /* Send low byte of memory address */
    LL_I2C_TransmitData8(EEPROM_I2C, addr_l);
    PRINTF(", low addr %02X, data:", addr_l);
    /* Wait until TCR flag is set */
    while(!LL_I2C_IsActiveFlag_TCR(EEPROM_I2C))
    {
      if(ee_timeout)
      {
        PRINTF(", timeout 2\n");
        return ERR_TIMEOUT;
      }
    }

    /* Send data */
    LL_I2C_HandleTransfer(EEPROM_I2C,
                          I2C_ADDR_EEPROM + addr_h,  // SlaveAddr
                          LL_I2C_ADDRSLAVE_7BIT,        // SlaveAddrSize
                          page_bytes_to_write,       // TransferSize [bytes]
                          LL_I2C_MODE_AUTOEND,          // EndMode
                          LL_I2C_GENERATE_NOSTARTSTOP); // Request
    for(uint8_t i = 0; i < page_bytes_to_write; i++)
    {
     /* Wait until TXIS flag is set */
      while(!LL_I2C_IsActiveFlag_TXIS(EEPROM_I2C))
      {
        if(ee_timeout)
        {
          PRINTF(", timeout 3\n");
          return ERR_TIMEOUT;
        }
      }
      /* Write data */
      if(1 == num_to_write)
      {                                     // checksum
        PRINTF(", crc: %02X", crc_result);
        LL_I2C_TransmitData8(EEPROM_I2C, crc_result);
      }
      else
      {
        crc_result = crc8(crc_result, *p_data);
        PRINTF(" %02X", *p_data);
        LL_I2C_TransmitData8(EEPROM_I2C, *p_data++);
      }
      num_to_write--;
    }

    /* Wait until STOPF flag is set */
    while(!LL_I2C_IsActiveFlag_STOP(EEPROM_I2C))
    {
      if(ee_timeout)
      {
        PRINTF(", timeout 4\n");
        return ERR_TIMEOUT;
      }
    }

    LL_I2C_ClearFlag_STOP(EEPROM_I2C);

    /* wait until write is complete (slave acknowledges its address) */
    LL_I2C_HandleTransfer(EEPROM_I2C,
                          I2C_ADDR_EEPROM + addr_h,  // SlaveAddr
                          LL_I2C_ADDRSLAVE_7BIT,        // SlaveAddrSize
                          0,                            // TransferSize [bytes]
                          LL_I2C_MODE_AUTOEND,          // EndMode
                          LL_I2C_GENERATE_NOSTARTSTOP); // Request
    do
    {
      volatile uint16_t delay = 1000;
      LL_I2C_ClearFlag_NACK(EEPROM_I2C);
      LL_I2C_ClearFlag_STOP(EEPROM_I2C);
      LL_I2C_GenerateStartCondition(EEPROM_I2C);

      while(delay--);

      if(ee_timeout)
      {
        PRINTF(", timeout 5\n");
        return ERR_TIMEOUT;
      }
    }
    while(LL_I2C_IsActiveFlag_NACK(EEPROM_I2C));

    LL_I2C_ClearFlag_STOP(EEPROM_I2C);
  } /* while(num_to_write) */
  xTimerStop(eetimer, 0);
  PRINTF(", ok\n");
  return ERR_SUCCESS;
}

/* I2C peripheral clocked at 170MHz system clock, I2C Speed 400kHz */
static void eeprom_i2c_init(void)
{
  int16_t w_temp = 0;

  /* check whether the I2C data line is high, if not, toggle the clock line until it is */
  eeprom_i2c_gpio_init();                      // configure pins for GPIO
  if(!LL_GPIO_IsInputPinSet(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN))
  {
    printf("I2C (EEPROM) SDA stuck low.\n");
    BB(pbb_alarms, FLT_EEPROM_FAIL) = 1;

    while(w_temp < 10)
    {                                       // continue until there are at least 10 consecutive ones
      eeprom_i2c_scl_low();
      vTaskDelay(1);
      eeprom_i2c_scl_high();
      vTaskDelay(1);
      if(LL_GPIO_IsInputPinSet(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN))
      {
        w_temp++;
      }
      else
      {
        w_temp = 0;
      }
    }
  }
  BB(pbb_alarms, FLT_EEPROM_FAIL) = 0;
  eeprom_i2c_low_level_init();                     // configure pins for I2C, enable clock
  LL_I2C_SetTiming(EEPROM_I2C, 0x60400D28);       // from STM32Cube: fastmode, 400kHz, 170MHz,
                                            // anlogue filter on, digital coef 0, rise time 100ns, fall time 10ns
  /* analog filter is on, digital filter off after reset */
  LL_I2C_Enable(EEPROM_I2C);
}

/* configure I2C pins as GPIO, for the purpose of resetting EEPROM internal state machine
   when, for some reason, the micro was reset while an EEPROM read was in progress */
static void eeprom_i2c_gpio_init(void)
{
  /* Note: GPIO clocks are already enabled in hardware_init */
  eeprom_i2c_scl_high();
  LL_GPIO_SetPinMode(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_MODE_OUTPUT);
  LL_GPIO_SetPinOutputType(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_OUTPUT_OPENDRAIN);
  LL_GPIO_SetPinSpeed(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_SPEED_FREQ_LOW); // 125ns rise time, EEPROM requires <300ns
  LL_GPIO_SetPinPull(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_PULL_UP);

  LL_GPIO_SetPinMode(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_MODE_INPUT); // data is input
  LL_GPIO_SetPinPull(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_PULL_UP);
}

/************************************ EEPROM *********************************/
/**
  * @brief  Configures I2C port, used for EEPROM.
  * @retval None
  */
void eeprom_i2c_low_level_init(void)
{
  /* Note: GPIO clocks are already enabled in hardware_init */
  ena_gpio_set_af_pin(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, EEPROM_I2C_SCL_AF);
  LL_GPIO_SetPinMode(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinOutputType(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_OUTPUT_OPENDRAIN);
  LL_GPIO_SetPinSpeed(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_SPEED_FREQ_LOW);
  LL_GPIO_SetPinPull(EEPROM_I2C_SCL_PORT, EEPROM_I2C_SCL_PIN, LL_GPIO_PULL_UP);

  ena_gpio_set_af_pin(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, EEPROM_I2C_SDA_AF);
  LL_GPIO_SetPinMode(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinOutputType(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_OUTPUT_OPENDRAIN);
  LL_GPIO_SetPinSpeed(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_SPEED_FREQ_LOW);
  LL_GPIO_SetPinPull(EEPROM_I2C_SDA_PORT, EEPROM_I2C_SDA_PIN, LL_GPIO_PULL_UP);

  LL_RCC_SetI2CClockSource(EEPROM_I2C_CLK_SOURCE); // I2C clock = 170MHz
  BB_RCC_APB1ENR1_I2C3EN = 1;
}

void vEetimerCallback(TimerHandle_t pxTimer )
{
  ( void ) pxTimer; // Stop compiler warning for unused parameter
  ee_timeout = true;
}

static TimerHandle_t eetimer_create(void)
{
  static StaticTimer_t eetimer_Buffer;

  return(xTimerCreateStatic("ETMR", 50 / portTICK_PERIOD_MS, pdFALSE, 0, vEetimerCallback, &eetimer_Buffer));
}
