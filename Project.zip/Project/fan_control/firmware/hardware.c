/**************************************************************************//**
  \file   hardware.c
  \brief  hardware configuration
  \author Arthur de Beun

  BOOTLOADER and MAIN are defined in the makefile

******************************************************************************/
#ifdef MAIN
/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"
#endif

#include "ena_datatype.h"
#include "ena_driver_stm32g4.h"

#include "hardware.h"
#include "events.h"
#include "main.h"
#include "usart_debug.h"
#include "fan.h"
#include "timestamp.h"

#ifdef MAIN
static void unused_pins_init(void);
#endif

/**
  * @brief  Configures the microcontroller and places IO in initial state.
  * @retval None
  */

#ifdef BOOTLOADER
void hardware_init(void)
{
  /* turn on generic peripheral clocks */
  RCC->AHB1ENR  = 0x00000100                  // reset value
                | LL_AHB1_GRP1_PERIPH_DMA1
                | LL_AHB1_GRP1_PERIPH_DMA2
                | LL_AHB1_GRP1_PERIPH_DMAMUX1
                | LL_AHB1_GRP1_PERIPH_CRC;

  RCC->AHB2ENR  = LL_AHB2_GRP1_PERIPH_GPIOA | LL_AHB2_GRP1_PERIPH_GPIOB | LL_AHB2_GRP1_PERIPH_GPIOC
                | LL_AHB2_GRP1_PERIPH_GPIOD | LL_AHB2_GRP1_PERIPH_GPIOF;

  RCC->APB1ENR1 = 0x00000400                // reset value
                | LL_APB1_GRP1_PERIPH_PWR
                | LL_APB1_GRP1_PERIPH_TIM6
                | LL_APB1_GRP1_PERIPH_TIM7;

  RCC->APB2ENR  = LL_APB2_GRP1_PERIPH_SYSCFG;

  LL_PWR_DisableUCPDDeadBattery();

  /* heartbeat LED */
  LL_GPIO_SetPinMode(LED_HEARTBEAT_GPIO_PORT, LED_HEARTBEAT_PIN, LL_GPIO_MODE_OUTPUT);
  LL_GPIO_SetPinOutputType(LED_HEARTBEAT_GPIO_PORT, LED_HEARTBEAT_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LED_heartbeat_off();

  usart_debug_init();                    // initialise the debug USART, available on J10
}
#endif /* BOOTLOADER */

#ifdef MAIN
void hardware_init(void)
{
  /* turn on generic peripheral clocks */
  RCC->AHB1ENR  = 0x00000100                // reset value
                | LL_AHB1_GRP1_PERIPH_DMA1
                | LL_AHB1_GRP1_PERIPH_DMA2
                | LL_AHB1_GRP1_PERIPH_DMAMUX1
                | LL_AHB1_GRP1_PERIPH_CRC;

  RCC->AHB2ENR  = LL_AHB2_GRP1_PERIPH_GPIOA | LL_AHB2_GRP1_PERIPH_GPIOB | LL_AHB2_GRP1_PERIPH_GPIOC
                | LL_AHB2_GRP1_PERIPH_GPIOD | LL_AHB2_GRP1_PERIPH_GPIOF;

  RCC->APB1ENR1 = 0x00000400                // reset value
                | LL_APB1_GRP1_PERIPH_PWR;

  RCC->APB2ENR  = LL_APB2_GRP1_PERIPH_SYSCFG; // also for analogue comparators and opamps

  LL_PWR_DisableUCPDDeadBattery();

  /* heartbeat LED */
  LL_GPIO_SetPinMode(LED_HEARTBEAT_GPIO_PORT, LED_HEARTBEAT_PIN, LL_GPIO_MODE_OUTPUT);
  LL_GPIO_SetPinOutputType(LED_HEARTBEAT_GPIO_PORT, LED_HEARTBEAT_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LED_heartbeat_off();

  /* debug pin */
  LL_GPIO_SetPinMode(DEBUG_PIN_GPIO_PORT, DEBUG_PIN, LL_GPIO_MODE_OUTPUT);
  LL_GPIO_SetPinOutputType(DEBUG_PIN_GPIO_PORT, DEBUG_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  debug_pin_low();

  /* sbi address select pin*/
  LL_GPIO_SetPinPull(ADDRESS_SELECT_GPIO_PORT, ADDRESS_SELECT_PIN, ADDRESS_SELECT_PULL);
  LL_GPIO_SetPinMode(ADDRESS_SELECT_GPIO_PORT, ADDRESS_SELECT_PIN, LL_GPIO_MODE_INPUT);

  timestamp_hardware_init();

  usart_debug_init();                    // initialise the debug USART, available on J10

  fan_hardware_init();

  unused_pins_init();
}


/******************************** Unused Pins ********************************/
// set unused pins to input with pull-down on

static void unused_pins_init(void)
{
  static const uint16_t unused_pins[5] = {PIN_A_UNUSED, PIN_B_UNUSED,PIN_C_UNUSED, PIN_D_UNUSED, PIN_F_UNUSED};
  static GPIO_TypeDef * const gpio_ports[5] = {GPIOA, GPIOB, GPIOC, GPIOD, GPIOF};
  for(uint32_t port = 0; port < 5; port++)
  {
    uint32_t mask = 1;
    for(uint32_t pin = 0; pin < 16; pin++)
    {
      if(mask == (unused_pins[port] & mask))
      {
        LL_GPIO_SetPinMode(gpio_ports[port], mask, LL_GPIO_MODE_INPUT);
        LL_GPIO_SetPinPull(gpio_ports[port], mask, LL_GPIO_PULL_DOWN);
      }
      mask <<= 1;
    }
  }
}
#endif /* MAIN */

