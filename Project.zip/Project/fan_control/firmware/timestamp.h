/**************************************************************************//**
  \file   timestamp.h
  \brief  1us timestamp using 32bit timer 5.
          wraps around about every 71mins 35sec
******************************************************************************/
#ifndef FILE_TIMESTAMP_H                     /* sentinel */
#define FILE_TIMESTAMP_H

#include "ena_datatype.h"

#include "hardware.h"

/**
 * Get the 32bit timestamp with 1us resolution.
 *
 * @retval 32bit timestamp [us].
*/
__STATIC_FORCEINLINE uint32_t get_timestamp(void){return TIM5->CNT;}

void timestamp_hardware_init(void);

#endif                                      /* end sentinel */
