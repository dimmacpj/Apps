/**************************************************************************//**
  \file   eeprom.c
  \brief  eeprom interface
  \author Arthur de Beun
  \date   2013 September 27 (created)

  EEPROM task

******************************************************************************/

/* FreeRTOS */
#include "FreeRTOS.h"
#include "queue.h"
#include "timers.h"

#include <stdio.h>

#include "ena_datatype.h"
#include "ena_mem.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "variants.h"

#include "control.h"
#include "db_table.h"
#include "db_table_size.h"
#include "db.h"
#define DEFINE_VARS
#include "eeprom.h"                         /* includes global variables */
#undef DEFINE_VARS
#include "eepromrw.h"
#include "events.h"
#include "main.h"
#include "sbi.h"

#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

static union                                // similar to uDB_init, but this can hold longest string
{
  uint8_t aub_buffer[LONGEST_STRING];
  int8_t b;
  int16_t w;
  int32_t l;
  float32_t f;
  uint8_t* paub;                            // string
} u_temp_1, u_temp_2;                       // buffers for temporary storage

/* local function prototypes */
void eeprom_init_variant(void);
void init_vars(const bool ee_default);
uint8_t eeprom_write_default(const uint16_t table_index);
uint8_t eeprom_init_var(const uint16_t table_index);
static QueueHandle_t eeprom_queue_create(void);

portTASK_FUNCTION( Eeprom_Task, pvParameters )
{
  uint16_t table_index;

  ( void ) pvParameters; // Stop compiler warning for unused parameter

  printf("Eeprom_Task start.\n");

  eequeue = eeprom_queue_create(); // queue will contain DBArray index of value to store

  /* initialise the EEPROM */
  eeprom_init();

  eeprom_init_variant();

  /* initialise variables from EEPROM */
  init_vars(0);

#if DEBUG
  if(BB(pbb_alarms, FLT_EEPROM_FAIL))
    PRINTF("Init vars failed.\n");
  else
    PRINTF("Init vars complete.\n");
#endif

  vTaskResume(Control_Task_Handle);
  vTaskResume(SBI_Task_Handle);

  while (1)
  {
    if(pdTRUE == xQueueReceive(eequeue, &table_index, portMAX_DELAY))
    {
      uint16_t ee_addr = 0;
      uint8_t ee_size = 0;
      if(table_index < DB_TABLE_SIZE)  // check table_index is within range
      {
        ee_addr = DBArray[table_index].eeprom_addr;
        ee_size = db_type_size(table_index);
      }

      if((0 != ee_addr) && (0 != ee_size))
      {
        /* read the existing value in EEPROM and check if different from new value*/
        uint8_t result = eeprom_rd(ee_addr, u_temp_1.aub_buffer, ee_size); // read from 1st table
        ena_memcpy(u_temp_2.aub_buffer, DBArray[table_index].ram_addr, ee_size);

        /* update values in EEPROM only when changed */
        if(ena_memcmp(u_temp_2.aub_buffer, u_temp_1.aub_buffer, ee_size))
        {
          result |= eeprom_wr(ee_addr, u_temp_2.aub_buffer, ee_size);
          result |= eeprom_wr(ee_addr + SECOND_TABLE_OFFSET, u_temp_2.aub_buffer, ee_size);
          if(ERR_SUCCESS == result)
          {
            BB(pbb_alarms, WRN_EEPROM_WRITE_FAIL) = 0;
          }
          else
          {
            BB(pbb_alarms, WRN_EEPROM_WRITE_FAIL) = 1;
          }
        }
      }
    }
  }
}

/* initialise the variant variables from EEPROM */
void eeprom_init_variant(void)
{
  eeprom_init_var(db_param_to_index(PARNAME('?', 'B'))); // Board Version
  eeprom_init_var(db_param_to_index(PARNAME('?', '?'))); // product ID
}


/* initialise variables from EEPROM, the variant must be set up before calling*/
void init_vars(const bool ee_default)
{
  PRINTF("Init vars\n");
  for(uint16_t table_index = 0; table_index < DB_TABLE_SIZE; table_index++)
  {
    if(!DBArray[table_index].ram_addr)  //last table entry is null
    {
      break;
    }
    uint16_t ee_addr = DBArray[table_index].eeprom_addr;
    uint16_t param_name = DBArray[table_index].param_name;

    /* initialise variables that have an EEPROM address and are not the variant */
    if((0 != ee_addr) && (param_name != PARNAME('?', '?')) && (param_name != PARNAME('?', 'B')))
    {
      if(ee_default)
      {
        eeprom_write_default(table_index);
      }
      else
      {
        eeprom_init_var(table_index);
      }
    }
  }
}

/* read the value from EEPROM */
uint8_t eeprom_init_var(const uint16_t table_index)
{
  uint8_t result;
  uint8_t error = 0;
  uDB_init u_temp;

  const uint16_t ee_addr = DBArray[table_index].eeprom_addr; // get the parameter EEPROM address
  const uint8_t ee_size = db_type_size(table_index);
  if((0 != ee_addr) && (0 != ee_size))                    // check if parameter has EEPROM address
  {
    PRINTF("Index %d, %c%c ", table_index, DBArray[table_index].param_name >> 8, DBArray[table_index].param_name & 0x00FF);

    PRINTF("EE addr %04X, EE size %d\n", ee_addr, ee_size);

    result = eeprom_rd(ee_addr, u_temp_1.aub_buffer, ee_size); // read value from 1st table
    u_temp.l = u_temp_1.l;              // change type for range check
    if((result != ERR_SUCCESS) || (!db_check_range(table_index, u_temp)))
    {                                   // the 1st value read was not valid
      PRINTF("1st invalid ======, ");
      result = eeprom_rd(ee_addr + SECOND_TABLE_OFFSET, u_temp_2.aub_buffer, ee_size); // read value from 2nd table
      u_temp.l = u_temp_2.l;            // change type for range check
      if((result != ERR_SUCCESS) || (!db_check_range(table_index, u_temp)))
      {                                 // the 2nd value read was not valid either, write default values to both
        PRINTF("2nd invalid ======\n");
        /* read the default value from flash and write to both EEPROM tables */
        error = eeprom_write_default(table_index);
        if(error != ERR_SUCCESS)
        {
          /* unable to write to EEPROM */
          BB(pbb_alarms, FLT_EEPROM_FAIL) = 1;
          PRINTF("EE write failure \n");
        }
      }
      else
      {                                 // the 2nd value was valid, update 1st table
        PRINTF("2nd valid, update 1st\n");
        error |= eeprom_wr(ee_addr, u_temp_2.aub_buffer, ee_size);

        /* assign EEPROM value to variable */
        ena_memcpy(DBArray[table_index].ram_addr, u_temp_2.aub_buffer, ee_size);

        /* execute "some function" if it exists */
        if(NULL != DBArray[table_index].some_function)
        {
          PRINTF("execute some f\n");
          DBArray[table_index].some_function(MESSAGE_WRITE_INIT, 0, 0);
        }
      }
    }
    else
    {                                   // the 1st value was valid, check the 2nd one
      PRINTF("1st valid, ");
      error = eeprom_rd(ee_addr + SECOND_TABLE_OFFSET, u_temp_2.aub_buffer, ee_size); // read value from 2nd table
      if((error != ERR_SUCCESS)
         || ena_memcmp(u_temp_1.aub_buffer, u_temp_2.aub_buffer, ee_size))
      {
        PRINTF("2nd invalid ======\n");
        error |= eeprom_wr(ee_addr + SECOND_TABLE_OFFSET, u_temp_1.aub_buffer, ee_size); // update 2nd table from 1st
      }
      else
      {
        PRINTF("2nd valid\n");
      }
      /* assign EEPROM value to variable */
      ena_memcpy(DBArray[table_index].ram_addr, u_temp_1.aub_buffer, ee_size);

      /* execute "some function" if it exists */
      if(NULL != DBArray[table_index].some_function)
      {
        PRINTF("execute some f\n");
        DBArray[table_index].some_function(MESSAGE_WRITE_INIT, 0, 0);
      }
    }
  } /* if(ee_addr && ee_size) */
  return error;
}

/* read the default value from flash and write to both EEPROM tables */
uint8_t eeprom_write_default(const uint16_t table_index)
{
  const uint8_t* p_default_value;
  uint8_t error;
  const uint16_t ee_addr = DBArray[table_index].eeprom_addr; // get the parameter EEPROM address
  const uint8_t ee_size = db_type_size(table_index);

  BB(pbb_alarms, WRN_EEPROM_INIT) = 1; // Warning is active until next uc reset.
  printf("EEPROM Default, Index %d, %c%c \n", table_index, DBArray[table_index].param_name >> 8, DBArray[table_index].param_name & 0x00FF);
  /* get the default for the parameter */
  if((ATTR_PTR_DEFAULT == (DBArray[table_index].db_type.attrib & ATTR_PTR_DEFAULT))
     || (DB_S == DBArray[table_index].db_type.type))
  {
    p_default_value = DBArray[table_index].default_value.paub;
  }
  else
  {
    p_default_value = DBArray[table_index].default_value.aub_buffer;
  }

  /* write to both EEPROM tables */
  error = eeprom_wr(ee_addr, p_default_value, ee_size);
  error |= eeprom_wr(ee_addr + SECOND_TABLE_OFFSET, p_default_value, ee_size);

  /* update the variable*/
  ena_memcpy(DBArray[table_index].ram_addr, p_default_value, ee_size);

  /* execute "some function" if it exists */
  if(NULL != DBArray[table_index].some_function )
  {
    PRINTF("execute some f\n");
    DBArray[table_index].some_function(MESSAGE_WRITE_INIT, 0, 0);
  }
  return error;
}

/* DBarray function for resetting all EEPROM values to default.
   TODO(JC): This will access the EEPROM from the SBI task in an unsafe manner.
*/
t_error_code eeprom_to_default(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code ret_val = ERR_FAIL;
  switch(read_write)
  {
    case MESSAGE_WRITE:
      if(1 == u_ui_temp.w)
      {
        init_vars(true);
      }
      ret_val = ERR_SUCCESS;
      break;

    case MESSAGE_READ:
      u_ui_temp.w = 0;                      // return zero on read, rather then some random value
      ret_val = ERR_SUCCESS;
      break;

    case MESSAGE_WRITE_INIT:
    default:
      break;
  }
  return ret_val;
}

#define EEPROM_TASK_STACK_SIZE (configMINIMAL_STACK_SIZE + 20)

TaskHandle_t eeprom_task_create(void)
{
  static StaticTask_t eeprom_task_buffer;
  static StackType_t eeprom_task_stack[EEPROM_TASK_STACK_SIZE];

  return(xTaskCreateStatic(Eeprom_Task, "EPRM", EEPROM_TASK_STACK_SIZE, NULL, EEPROM_TASK_PRIORITY, eeprom_task_stack, &eeprom_task_buffer));
}

#define EEQUEUE_LENGTH (10)
#define EEQUEUE_SIZE (sizeof(uint16_t))

static QueueHandle_t eeprom_queue_create(void)
{
  static StaticQueue_t eequeue_buffer;
  static uint8_t eequeue_storage_buffer[EEQUEUE_LENGTH * EEQUEUE_SIZE];

  return(xQueueCreateStatic(EEQUEUE_LENGTH, EEQUEUE_SIZE, eequeue_storage_buffer, &eequeue_buffer));
}
