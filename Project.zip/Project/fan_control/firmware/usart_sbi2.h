/**************************************************************************//**
  \file   usart_sbi2.h
  \brief  uart for sbi comms to monitor
******************************************************************************/
#ifndef FILE_USART_SBI2_H                    /* sentinel */
#define FILE_USART_SBI2_H

#include "stm32g4xx.h"                      // from CMSIS
#include "ena_datatype.h"
#include "periph_bb.h"

#include "hardware.h"
#include "sbi_buffer.h"

void uart_sbi2_init(void);

extern const t_hw_sbi *const  p_uart_sbi2_access;


#endif                                      /* sentinel */
