/**************************************************************************//**
  \file   db_table.c
  \brief  database table
  \author Arthur de Beun
  \date   2013 September 17 (created)


  External access to global variables and non-volatile storage.

  A structure (in db_table.h) is used to generate EEPROM address automatically.
  Address 0 is not used, because a value of 0 indicates no EEPROM storage is
  associated with that variable.

  Each value in EEPROM is stored twice, the read/write/error checking strategy
  is as follows:
   1) A value is initially written to the first entry. If this verifies correctly
      then the value is also written to the second entry.
   2) A value is initially read from the first entry, if the checksum is correct
      it is considered a good value.
   3) If the checksum from the first entry is incorrect, the value is read from the
      second entry. If it is valid, this value is used and also written to the first
      entry. If this value is also invalid, the default value is used and the
      default value is written to both entries.
   4) On startup, both entries are compared. If the checksum for a value is incorrect
      it is corrected from the other table, provided it's valid.
   5) If the values are different, but their checksums are correct, then the value
      in the first entry is considered more recent and the second entry is updated.
   6) There is no additional code for first time initialisation. An erased EEPROM is
      all 0xFF, the checksums will be incorrect and the default values will be
      written.


   The parameter names in DBArray must be sorted in ASCII order, otherwise the
   binary search will fail.
   The parameter name must not contain SBI reserved characters '\0', '$', ':', ',', '*'.
   Handy ASCII table for reference:

         0 1 2 3 4 5 6 7 8 9 A B C D E F
     2x    ! " # $ % & ' ( ) * + , - . /
     3x  0 1 2 3 4 5 6 7 8 9 : ; < = > ?
     4x  @ A B C D E F G H I J K L M N O
     5x  P Q R S T U V W X Y Z [ \ ] ^ _
     6x  ` a b c d e f g h i j k l m n o
     7x  p q r s t u v w x y z { | } ~

  There is a script, db_table_check.py, that will check the order.

******************************************************************************/
/* FreeRTOS */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#include <string.h>

#include "ena_datatype.h"
#include "ena_maths.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "variants.h"
#include "main.h"

#include "adc.h"
#include "control.h"
#include "db_func.h"
#include "eeprom.h"
#include "events.h"
#define DEFINE_VARS
#include "db_table.h"
#undef DEFINE_VARS
#include "db.h"
#include "sbi.h"


const uint8_t notepad_default[sizeof(notepad)] = {"notepad-notepad\0"};
const uint8_t serial_number_default[sizeof(serial_number)] = {"0000000000\0"};

/* The ONLY purpose of the next 4 structs below is to assign EEPROM addresses.
   The structs are packed and can therefore not be used to define actual variables. */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpacked"
#pragma GCC diagnostic ignored "-Wattributes"
typedef struct __attribute__((__packed__)) EEb_struct
{
  int8_t b_value;
  uint8_t ub_checksum;
} t_EEb;

typedef struct __attribute__((__packed__)) EEw_struct
{
  int16_t w_value;
  uint8_t ub_checksum;
} t_EEw;

typedef struct __attribute__((__packed__)) EEl_struct
{
  int32_t l_value;
  uint8_t ub_checksum;
} t_EEl;

typedef struct __attribute__((__packed__)) EEf_struct
{
  float32_t f_value;
  uint8_t ub_checksum;
} t_EEf;

/* structure to generate EEPROM addresses */
typedef struct __attribute__((__packed__)) EE_ADDRESS_struct
{
  t_EEb ub_skip_zero;                    /* cannot start at 0, since 0 means no EEPROM storage, also used for SDA stuck test code */
  t_EEl product_id;                      /* ?? */
  t_EEw board_version;                   /* ?B */
  uint8_t aub_spare_space[9];            /* spare space at beginning of EEPROM  */
  uint8_t serial_number[sizeof(serial_number)+1]; /* SN serial number */
  t_EEl comms_timeout;                   /* CV, comms timeout */
  uint8_t notepad[sizeof(notepad)+1];    /* NP, notepad */
  t_EEw fan_pulses_per_rev;              /* FP, fan tacho pulses per revolution */
  t_EEw fan_min_rpm;                     /* Fm, RPM value below which the fan fail alarm is set */
  t_EEf aux_v_gain;                      /* KX, input auxilary supply voltage gain */
} t_EE_ADDR;

_Static_assert(sizeof(t_EE_ADDR) < (E2END / 2), "EEPROM is full");
_Static_assert((7 == offsetof(t_EE_ADDR, board_version)), "board_version offset is expected to be 7");

#pragma GCC diagnostic pop
/* This list MUST be sorted by parameter name or the binary search will fail.
   The parameter name can be anything. ASCII characters were selected because
   they can be typed on a keyboard, but any word value can be used. */

const tDB_entry DBArray[] =
{
  /* ! */
  /* " */
  /* # */
  /* $ */
  /* % */
  {                                     /* DBArray parameter characteristics, size of table */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('%', '#'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_table_size            /* pointer to function to execute when variable accessed */
  },

    /* %% reserved for next AC parameter with EEPROM storage that needs initialising */

  {                                     /* SBI port number */
    &u_ui_temp.ul,                      /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('%', 'P'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_sbi_port_number                 /* pointer to function to execute when variable accessed */
  },

  {                                     /* SBI time stamp */
    &u_ui_temp.ul,                      /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('%', 'T'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_timestamp                       /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, attributes */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('%', 'a'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_attrib                /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, default value */
    &u_ui_temp.l,                       /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('%', 'd'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_default                /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, eeprom? */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('%', 'e'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_eeprom                 /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, index */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},         /* type/size of parameter */
    PARNAME('%', 'i'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = DB_TABLE_SIZE - 1},           /* max value, from db_table_size.h, generated by db_table_check.py */
    {.l = 0},                           /* scaling */
    fdb_parameter_index                  /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, max value */
    &u_ui_temp.l,                       /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('%', 'm'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_max                    /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, min value */
    &u_ui_temp.l,                       /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('%', 'n'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_min                    /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, name */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('%', 'p'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_name                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* DBArray parameter characteristics, type */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('%', 't'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    fdb_parameter_type                  /* pointer to function to execute when variable accessed */
  },

  /* & */
  /* ' */
  /* ( */
  /* ) */
  /* * */
  /* + */
  /* , */
  /* - */
  /* . */
  /* / */
  /* numbers */
  /* : */
  /* ; */
  /* < */
  /* = */
  {                                     /* reset all EEPROM parameters except the variant to default */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},         /* type/size of parameter */
    PARNAME('=', 'd'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 1},                           /* max value */
    {.l = 0},                           /* scaling */
    eeprom_to_default                   /* pointer to function to execute when variable accessed */
  },

  /* > */
  /* ? */
  /* Product ID / Variant--------------------------------------------------- */
  {                                     /* software-configured product ID / variant */
    &product_id,                        /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('?', '?'),                  /* parameter name */
    offsetof(t_EE_ADDR, product_id),    /* EEPROM address */
    {.l = 0x000100E9},                  /* default value Product Name */
    {.l = 0x000100E9},                  /* min value */
    {.l = 0x000100E9},                  /* max value */
    {.l = 0},                           /* scaling */
    fdb_product_id                      /* pointer to function to execute when variable accessed */
  },

  {                                     /* software-configured board version / variant */
    &board_version,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},         /* type/size of parameter */
    PARNAME('?', 'B'),                  /* parameter name */
    offsetof(t_EE_ADDR, board_version),  /* EEPROM address */
    {.l = LATEST_BOARD_VERSION},        /* default value */
    {.l = 1},                           /* min value */
    {.l = LATEST_BOARD_VERSION},        /* max value */
    {.l = 0},                           /* scaling */
    fdb_board_version                    /* pointer to function to execute when variable accessed */
  },

  /* @ */

  /* upper case letters */
  {                                     /* overall alarms (faults and warnings), live. but stretched by monostable */
    &alarms_mono,                       /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('A', '#'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* overall alarms (faults and warnings), latched */
    &alarms_latched,                    /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('A', '%'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* fans off, on */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},         /* type/size of parameter */
    PARNAME('C', 'M'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = FANS_OFF},                    /* min value */
    {.l = FANS_ON},                     /* max value */
    {.l = 0},                           /* scaling */
    fdb_fans_on_off                     /* pointer to function to execute when variable accessed */
  },

  {                                     /* comms timeout [ms] time */
    &comms_timeout,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('C', 'V'),                  /* parameter name */
    offsetof(t_EE_ADDR, comms_timeout), /* EEPROM address */
    {.l = 480000},                      /* default value (8 minutes) */
    {.l = 0},                           /* min value (zero means no timeout) */
    {.l = 28800000},                    /* max value (8 hours) */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* fan 1 tacho [rpm] */
    &fan1_rpm,                          /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('F', '1'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* fan 2 tacho [rpm] */
    &fan2_rpm,                          /* pointer to RAM variable */
    {ATTR_RD, DB_16},         /* type/size of parameter */
    PARNAME('F', '2'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0.},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* fan tachometer pulses per revolution */
    &fan_pulses_per_rev,                /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},          /* type/size of parameter */
    PARNAME('F', 'P'),                  /* parameter name */
    offsetof(t_EE_ADDR, fan_pulses_per_rev),  /* EEPROM address */
    {.l = 2},                           /* default value */
    {.l = 1},                           /* min value */
    {.l = 128},                         /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* fan speed 0.0 (off) to 1.0 (full speed). */
    &fan_speed_demand,                  /* pointer to RAM variable */
    {ATTR_RD, DB_F},                    /* type/size of parameter */
    PARNAME('F', 'S'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = 0.0},                         /* min value */
    {.f = 1.0},                         /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* RPM value below which the fan fail alarm is set */
    &fan_min_rpm,                       /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_16},         /* type/size of parameter */
    PARNAME('F', 'm'),                  /* parameter name */
    offsetof(t_EE_ADDR, fan_min_rpm),   /* EEPROM address */
    {.l = 800},                         /* default value */
    {.l = 100},                         /* min value */
    {.l = 30000},                       /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* input auxilary supply voltage gain */
    &aux_v_gain,                        /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('K', 'X'),                  /* parameter name */
    offsetof(t_EE_ADDR, aux_v_gain),    /* EEPROM address */
    {.f = AUX_GAIN},                    /* default value */
    {.f = AUX_GAIN * 0.9F},             /* min value */
    {.f = AUX_GAIN * 1.1F},             /* max value */
    {.f = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* uncommitted EEPROM locations that are available for storing something */
    &notepad,                           /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_S},          /* type/size of parameter */
    PARNAME('N', 'P'),                  /* parameter name */
    offsetof(t_EE_ADDR, notepad),       /* EEPROM address */
    {.paub = notepad_default},          /* default value (pointer to default string in flash) */
    {.l = 0},                           /* min value (minimum length of string) */
    {.l = sizeof(notepad)},             /* max value (maximum length of string) */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* software checksum */
    &u_ui_temp.ul,                      /* pointer to ROM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('S', 'C'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    read_sw_checksum                    /* pointer to function to execute when variable accessed */
  },

  {                                     /* serial number */
    &serial_number,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_S},          /* type/size of parameter */
    PARNAME('S', 'N'),                  /* parameter name */
    offsetof(t_EE_ADDR, serial_number), /* EEPROM address */
    {.paub = serial_number_default},    /* default value */
    {.l = 0},                           /* min value */
    {.l = sizeof(serial_number)},       /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* software build time [unix time GMT] */
    &u_ui_temp.ul,                      /* pointer to ROM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('S', 'T'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    read_sw_build_time                  /* pointer to function to execute when variable accessed */
  },

  {                                     /* software version (high word) and build number (low word) */
    &u_ui_temp.ul,                      /* pointer to ROM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('S', 'V'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    read_sw_version                     /* pointer to function to execute when variable accessed */
  },

  {                                     /* bootloader checksum */
    &u_ui_temp.l,                       /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('S', 'c'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    read_bootloader_checksum            /* pointer to function to execute when variable accessed */
  },

  {                                     /* onboard pcb temperature */
    &ntc_pcb_temperature,               /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('T', '0'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = 0.0},                         /* min value */
    {.f = 0.0},                         /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* external ntc 1 temperature */
    &ntc_1_temperature,                 /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('T', '1'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = 0.0},                         /* min value */
    {.f = 0.0},                         /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* external ntc 2 temperature */
    &ntc_2_temperature,                 /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('T', '2'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = 0.0},                         /* min value */
    {.f = 0.0},                         /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* input auxilary supply voltage */
    &aux_v,                             /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('V', 'X'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = 0.0},                         /* min value */
    {.f = 0.0},                         /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  /* [ */
  /* \ */
  /* ] */
  /* ^ */
  /* _ */
  /* ` */
  /* lower case letters */
  /* { */
  /* | */

  {                                     /* debug variable 32-bit */
    &l_debug_var_1,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('|', '5'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = INT32_MIN},                   /* min value */
    {.l = INT32_MAX},                   /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable 32-bit */
    &l_debug_var_2,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('|', '6'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = INT32_MIN},                   /* min value */
    {.l = INT32_MAX},                   /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable 32-bit */
    &l_debug_var_3,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('|', '7'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = INT32_MIN},                   /* min value */
    {.l = INT32_MAX},                   /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable 32-bit */
    &l_debug_var_4,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_32},         /* type/size of parameter */
    PARNAME('|', '8'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = INT32_MIN},                   /* min value */
    {.l = INT32_MAX},                   /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable float */
    &f_debug_var_1,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('|', 'j'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = -1.0e9},                      /* min value */
    {.f = 1.0e9},                       /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable float */
    &f_debug_var_2,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('|', 'k'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = -1.0e9},                      /* min value */
    {.f = 1.0e9},                       /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable float */
    &f_debug_var_3,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('|', 'l'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = -1.0e9},                      /* min value */
    {.f = 1.0e9},                       /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* debug variable float */
    &f_debug_var_4,                     /* pointer to RAM variable */
    {ATTR_RD | ATTR_WR, DB_F},          /* type/size of parameter */
    PARNAME('|', 'm'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.f = 0.0},                         /* default value */
    {.f = -1.0e9},                      /* min value */
    {.f = 1.0e9},                       /* max value */
    {.f = 0.0},                         /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  {                                     /* copy of reset flags */
    &reset_flags_cpy,                   /* pointer to RAM variable */
    {ATTR_RD, DB_32},                   /* type/size of parameter */
    PARNAME('|', 'r'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  },

  /* } */
  /* ~ */
  {                                     /* enter bootloader command */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_WR, DB_16},                   /* type/size of parameter */
    PARNAME('~', 'C'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0x90b1},                      /* default value */
    {.l = 0x90b1},                      /* min value */
    {.l = 0x90b1},                      /* max value */
    {.l = 0},                           /* scaling */
    start_bootloader                 /* pointer to function to execute when variable accessed */
  },

  {                                     /* bootloader ID */
    &u_ui_temp.w,                       /* pointer to RAM variable */
    {ATTR_RD, DB_16},                   /* type/size of parameter */
    PARNAME('~', 'I'),                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    read_bootloader_id                  /* pointer to function to execute when variable accessed */
  },

  {                                     /* end of table */
    0,                                  /* pointer to RAM variable (0 means end of table) */
    {0, DB_16},                         /* type/size of parameter */
    0,                                  /* parameter name */
    0,                                  /* EEPROM address */
    {.l = 0},                           /* default value */
    {.l = 0},                           /* min value */
    {.l = 0},                           /* max value */
    {.l = 0},                           /* scaling */
    0                                   /* pointer to function to execute when variable accessed */
  }
};
