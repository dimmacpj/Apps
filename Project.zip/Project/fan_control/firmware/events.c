/**************************************************************************//**
  \file   events.c
  \brief  events, alarms functions
  \author Arthur de Beun
  \date   2014 June 24 (created)




******************************************************************************/
#include "ena_datatype.h"

#include "hardware.h"

#define DEFINE_VARS
#include "events.h"                         /* includes global variables */
#undef DEFINE_VARS

#define MONO_TIME (5000)                    /* alarm monostable time-out in ms */

static void update_mono(volatile uint32_t* p_alarms_mono, uint16_t timer_mono[32], uint32_t alarm_field, bool clear);

/**
  * @brief  Update fault and warning status bit monostables
  * @param  None
  * @retval None
  *
  * The fault and warning flags are stretched by non-retriggerable monostables for
  * the purpose of display so it becomes possible to capture flags via comms that
  * are only active briefly.
  * This function is called from the slow control loop at 1ms rate. The monostable time
  * is set by MONO_TIME.
  *
  * clear set to true clears any non-active alarms.
  *
  */
static void update_mono(volatile uint32_t* p_alarms_mono, uint16_t timer_mono[32], uint32_t alarm_field, bool clear)
{
  uint32_t mask = 1;                       // bit mask
  uint32_t alarm_local = 0;

  for(uint8_t i = 0; i < 32; i++)          // for each fault and warning flag
  {
    /* alarm flags monostables */
    if((alarm_field & mask) == mask)
    {                                       // an alarm is (still) active
      if(0 == timer_mono[i])
      {
        timer_mono[i] = 1;            // start the timer when the alarm first appears
      }
    }
    else
    {                                       // alarm is inactive
      if((timer_mono[i] >= MONO_TIME) || clear)
      {
        timer_mono[i] = 0;            // stop the timer
      }
    }
    if(timer_mono[i] > 0)             // if the timer is already running
    {                                 // keep incrementing until maximum time
      if(timer_mono[i] < MONO_TIME)
      {
        timer_mono[i]++;
      }
      alarm_local |= mask;            // set the monostable version of the fault flag
    }

    mask <<= 1;
  }
  *p_alarms_mono = alarm_local;          // copy alarms into global

}

void update_alarm_mono(volatile uint32_t* p_alarms_mono, uint32_t alarm_field, bool clear)
{
  static uint16_t alarm_tmr[32];        // fault status bits monostable timers
  update_mono(p_alarms_mono, alarm_tmr, alarm_field, clear);
}

void update_info_mono(volatile uint32_t* p_alarms_mono, uint32_t info_field, bool clear)
{
  static uint16_t info_tmr[32];        // fault status bits monostable timers
  update_mono(p_alarms_mono, info_tmr, info_field, clear);
}


/**
  * @brief  Increment abnormal condition timer and test against limit
  * @param  test
            timer
            timeout in ms
  * @retval 0 for limit not reached, 1 for limit reached
  *
  */
int16_t inc_tmr_test(bool test, uint32_t* p_timer, uint32_t timeout)
{
  int16_t ret_val = 0;
  if(test)
  {                                         // count towards limit when true
    (*p_timer)++;
    if(*p_timer >= timeout)
    {
      *p_timer = timeout;
      ret_val = 1;
    }
  }
  else
  {                                         // count towards 0 when false
    if(*p_timer > 0)
    {
      (*p_timer)--;
    }
  }
  return ret_val;
}

/* Initialise pointers to the bit-banding region. This has to be done before starting the tasks */
void event_init_bb_ptr(void)
{
  pbb_alarms = (volatile uint32_t*)(SRAM_BB_BASE | (((uint32_t)&alarms - SRAM_BASE) << 5));
}

