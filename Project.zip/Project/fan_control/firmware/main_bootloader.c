/******************************************************************************

 FileName    : main_bootloader.c
 Title       : STM32G4 bootloader
 Author      : Arthur de Beun
 Created     : 2015 August 24
 Company     : Enatel Ltd.
 System      : GNU Tools for ARM Embedded Processors
               https://launchpad.net/gcc-arm-embedded
               gcc-arm-none-eabi-4_7-2013q2-20130614
 History     :

 Description :

 The bootloader firmware download uses a protocol based on SBI. The address is
 fixed at 0x7F. The command parameter takes the form

   $7F,~C,VVVV*SS                            --- 14 bytes long

 and the firmware payload

   $7F,~D,FFFFVVVVVV..VV*SS                  --- 78 bytes long

 where FFFF is the 2-byte flash address / 32 (the STM32F334 has up to 64 kBytes of flash)
 and VVVvvv..VV are 32 bytes of flash data.

 The responses for success and fail is the same as for SBI, with the difference
 that the response to ~D is not the entire frame, but just the flash address. i.e.

   :7F,~D,FFFF*SS                            --- 14 bytes long

 Assuming an 16kB bootloader, and therefore a maximum of 112kB of main firmware
 and a 19k2 baud rate, a firmware download will take up to:

   112 * 1024 = 114688 divided by 32 = 3584 data frames.
   Each frame as 68 bytes TxD plus 14 bytes RxD = 82 bytes.
   Each 82 bytes at 19k2 will take 42.7ms.
   So 3584 frames will take about 153 seconds.

******************************************************************************/
#include <stdio.h>

#include "ena_datatype.h"
/* Hardware and board configuration */
#include "hardware.h"

#define DEFINE_VARS
#include "main.h"
#undef DEFINE_VARS
#include "sbi_buffer.h"
#include "usart_sbi1.h"


#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

/* boundaries and size of main code in STM flash */
#define STM_MAIN_ROM_START (0x08000000 + BOOTLOADER_SIZE)
#define STM_MAIN_ROM_SIZE  (STM_MAIN_ROM_END + 1 - STM_MAIN_ROM_START)
#define STM_ROM_SIZEinWORDS ((uint32_t)(STM_MAIN_ROM_SIZE/4u))
#define STM_FLASH_PAGE_SIZE ((uint32_t)(0x00001000)) /* 4kB (single bank organisation, DBANK=0) */
#define NUMBER_OF_STM_FLASH_PAGES ((STM_MAIN_ROM_SIZE + BOOTLOADER_SIZE) / STM_FLASH_PAGE_SIZE)

#define DC_DEVICE_ADDR (0x7F)

#define FLASH_SR_ERROR_MASK (0x0000C3FB)

static void boot_jump(uint32_t address);
static uint8_t check_uc_flash_crc(void);
static void bootloader(void);
static uint8_t bootloader_command(uint16_t command);
static uint8_t bootloader_data(void);

extern uint32_t bootload_var;              // shared variable with main code, defined in linker script
extern uint32_t reset_flags;               // shared variable with main code, defined in linker script

static bool flash_failed;                  // indicate whether on-board flash CRC has failed
static uint8_t payload_index;              // index into payload
static uint8_t payload[MAX_PAYLOAD_SIZE];
static uint8_t payload_nibble;             // count hex char nibbles
static t_mpsm message_statemachine = MPSM_SEARCH_SOF; // message parser state machine
static uint8_t checksum;                   // checksum computed as message is parsed
static uint8_t received_checksum;          // checksum in received message
static uint8_t message_addr;
static uint16_t message_parm;              // parameter name
static tMSG message_type;                  // read or write
static uint8_t sbi_device_addr;
static volatile bool tick;                 // 70kHz tick

static void boot_jump(uint32_t address)
{
  __asm volatile(
    "LDR SP, [%0] \n"                       // Load new stack pointer address
    "LDR PC, [%0, #4] \n"                   // Load new program counter address
    :
    :  "r" (address)
    :
  );
}

void main(void)
{
  SystemInit();                             // system_stm32g4xx.c
  SCB->AIRCR = 0x05FA0000U | 0x300U;        // 4 bits for pre-emption priority, 0 bits for subpriority
  hardware_init();                          // periph clocks, LEDs, debug uart, CRC

  printf("\nBootloader start ");

  printf(", RCC_CSR = %02X.\n", (uint8_t)(RCC->CSR >> 24));
  if(RCC->CSR & RCC_CSR_OBLRSTF)
  {
    printf("Option byte loader\n");
  }
  if(RCC->CSR & RCC_CSR_PINRSTF)
  {
    printf("NRST pin\n");                   // reset from NRST pin
  }
  if(RCC->CSR & RCC_CSR_BORRSTF)
  {
    printf("BOR\n");                        // reset from power-up/power-down detector
  }
  if(RCC->CSR & RCC_CSR_SFTRSTF)
  {
    printf("Software\n");
  }
  if(RCC->CSR & RCC_CSR_IWDGRSTF)
  {
    printf("Independent WD\n");
  }
  else if(RCC->CSR & RCC_CSR_WWDGRSTF)
  {
    printf("System window WD\n");
  }
  else
  {
    reset_flags = 0;                      // set to zero when reset source was not a watchdog
  }
  if(RCC->CSR & RCC_CSR_LPWRRSTF)
  {
    printf("Low-power management\n");
  }

  /* check whether this reset was caused by the start bootloader command from main code */
  if(0x90b16F4EU == bootload_var)
  {
    bootload_var = 0;
    bootloader();
  }

  /* CRC module clock is alread enabled in hardware_init() */
  /* Calculate on-board flash CRC */
  flash_failed = check_uc_flash_crc();

  if(flash_failed != 0)
  {
    bootloader();
  }

  printf("Bootloader end.\n");

  /* disable all interrupts */
  NVIC->ICER[0] = 0xFFFFFFFFU;
  NVIC->ICER[1] = 0xFFFFFFFFU;
  NVIC->ICER[2] = 0xFFFFFFFFU;

  /* continue to rectifier code */
  boot_jump(0x08000000U + BOOTLOADER_SIZE);
}

static void bootloader(void)
{
  uint8_t error = ERR_FAIL;

  printf("Entering bootload mode, ID = 0x%04X.\n", BOOTLOADER_ID);
  const t_hw_sbi *const p_hw_sbi_access = p_uart_sbi1_access;

  sbi_device_addr = DC_DEVICE_ADDR;
  /* SBI uart */
  uart_sbi1_init();
  /* clocks to timers TIM6 and TIM7 are enabled in hardware_init() */
  /* use TIM6 as a timeout timer, which will exit bootload mode via a reset */
  TIM6->PSC = (uint16_t)65535U;             // 170MHz / 65536 = 2.594kHz
  // TIM6->ARR = 65535 on reset             // 65536 at 2.594kHz = 25.26 seconds
  TIM6->EGR = TIM_EGR_UG;                   // force update of registers
  TIM6->CNT = 0;
  TIM6->SR = 0;                             // clear any pending interrupts
  TIM6->DIER = LL_TIM_DIER_UIE;             // enable update interrupt
  NVIC_SetPriority(TIM6_DAC_IRQn, INTERRUPT_PRIORITY_TIMEOUT);
  NVIC_EnableIRQ(TIM6_DAC_IRQn);

  if(!flash_failed)                      // start timer only when entered from main code
  {
    TIM6->CR1 = TIM_CR1_CEN;                // enable timer
  }

  /* use TIM7 as a 70.159kHz timer, which will run the main bootloader loop */
  TIM7->PSC = 0;                            // 170MHz / 1 = 170MHz
  TIM7->ARR = 2418U;                        // 170MHz / (x + 1) = 70.28kHz
  TIM7->EGR = TIM_EGR_UG;                   // force update of registers
  TIM7->SR = 0;                             // clear any pending interrupts
  TIM7->DIER = LL_TIM_DIER_UIE;             // enable update interrupt
  NVIC_SetPriority(TIM7_DAC_IRQn, INTERRUPT_PRIORITY_BOOTLOADER);
  NVIC_EnableIRQ(TIM7_DAC_IRQn);
  TIM7->CR1 = TIM_CR1_CEN;                  // enable timer
  while(1)
  {
    while(!tick){ /* wait for 70kHz timer */ }
    tick = false;
    if(message_statemachine == MPSM_PROCESSING)
    {
      PRINTF("bootloader.c: MPSM_PROCESSING %c%c", message_parm >> 8, message_parm & 0x00FFU);

      if(((message_parm >> 8) != '~') ||
         (((message_parm & 0x00FFU) != 'C' ) && ((message_parm & 0x00FFU) != 'D' ) &&
          ((message_parm & 0x00FFU) != 'I' )))
      {
        /* parameter not found */
        transmit_error_frame(sbi_device_addr, false, message_parm, p_hw_sbi_access); // only respond if we're specifically addressed
        message_statemachine = MPSM_SEARCH_SOF;
        PRINTF(" - not found\n");
        continue;
      }

      PRINTF("\n");

      switch (message_type)
      {
        case MESSAGE_READ:
          switch(message_parm & 0x00FFU)
          {
            case 'I':                       // bootloader ID
              payload[0] = BOOTLOADER_ID >> 8; // high byte
              payload[1] = BOOTLOADER_ID & 0x00FF; // low byte
              transmit_frame(false, sbi_device_addr, false, 2, message_parm, payload, p_hw_sbi_access);
              break;

            default:
              transmit_error_frame(sbi_device_addr, false, message_parm, p_hw_sbi_access);
              break;
          }
          break;

        case MESSAGE_WRITE:
          error = ERR_FAIL;
          switch(message_parm & 0x00FFU)
          {
            case 'C':
              error = bootloader_command(((uint16_t)payload[0] * 256) + payload[1]);
              break;

            case 'D':
              error = bootloader_data();
              break;

            default:
              break;
          }
          if(ERR_SUCCESS == error)
          {
            transmit_frame(false, sbi_device_addr, false, 2, message_parm, payload, p_hw_sbi_access); // echo the received buffer back
                                            // (for the ~D command only the address is echoed)
          }
          else
          {
            transmit_error_frame(sbi_device_addr, false, message_parm, p_hw_sbi_access);
          }
          break;

        case MESSAGE_WRITE_INIT:
        default:
          transmit_error_frame(sbi_device_addr, false, message_parm, p_hw_sbi_access);
          break;
      } /* switch(t_message_type) */
      message_statemachine = MPSM_SEARCH_SOF;
    }
    else /* haven't got a complete frame yet */
    {
      while(true)
      {
        const uint8_t ub_rxd = sbi_rx_buffer_read(p_hw_sbi_access);
        if(0 == ub_rxd)  // No data
        {
          break;
        }
        /* sentence parsing state machine */
        if('$' == ub_rxd)                   // reset the state machine whenever $ appears
        {
          message_statemachine = MPSM_SEARCH_SOF;
        }

        switch(message_statemachine)
        {
          case MPSM_SEARCH_SOF:
            checksum = 0;                // reset checksum
            message_addr = 0;            // device address
            message_parm = 0;            // parameter name
            payload_index = 0;
            payload_nibble = 0;
            if('$' == ub_rxd)               // advance state machine once SOF is found
            {
              message_statemachine = MPSM_GET_ADDR; // next state
            }
            break;

          case MPSM_GET_ADDR:
            if(',' == ub_rxd)               // have reached parameter name
            {
              message_statemachine = MPSM_GET_PARM; // next state
            }
            else
            {
              checksum = ones_comp_add(checksum, ub_rxd);
              message_addr = (uint8_t)(message_addr << 4);
              if(hex_to_nibble(&message_addr, ub_rxd))
              {
                message_statemachine = MPSM_SEARCH_SOF; // next state
                break;                      // message not correct
              }
            }
            break;

          case MPSM_GET_PARM:
            if(',' == ub_rxd)               // have a parameter write message
            {
              message_type = MESSAGE_WRITE;
              message_statemachine = MPSM_GET_DATA1; // next state
            }
            else
            {
              if('*' == ub_rxd)             // have a parameter read message
              {
                message_type = MESSAGE_READ;
                message_statemachine = MPSM_GET_CHK1;  // next state
              }
              else
              {
                message_parm = (uint16_t)(message_parm << 8) | (uint16_t)ub_rxd;
                checksum = ones_comp_add(checksum, ub_rxd);
              }
            }
            break;

          case MPSM_GET_DATA1:
          case MPSM_GET_DATA2:
            if('*' == ub_rxd)               // have reached checksum
            {
              message_statemachine = MPSM_GET_CHK1; // next state
            }
            else
            {
              if(payload_index >= MAX_PAYLOAD_SIZE)
              {
                message_statemachine = MPSM_SEARCH_SOF; // next state
                break;                    // message too long
              }
              if(payload_nibble)
              {
                payload[payload_index] <<= 4; // shift before 2nd nibble
              }
              else
              {
                payload[payload_index] = 0; // initialise before 1st nibble
              }

              if(hex_to_nibble((uint8_t*)&payload[payload_index], ub_rxd))
              {
                message_statemachine = MPSM_SEARCH_SOF; // next state
                break;                    // message not correct
              }
              payload_nibble = !payload_nibble;
              if(!payload_nibble)
              {
                payload_index++;
              }

              checksum = ones_comp_add(checksum, ub_rxd);
            }
            break;

          case MPSM_GET_CHK1:
            received_checksum = 0;
            if(hex_to_nibble(&received_checksum, ub_rxd))
            {
              message_statemachine = MPSM_SEARCH_SOF; // next state
              break;                        // message not correct
            }
            received_checksum = (received_checksum << 4);
            message_statemachine = MPSM_GET_CHK2;
            break;

          case MPSM_GET_CHK2:
            if(hex_to_nibble(&received_checksum, ub_rxd))
            {
              message_statemachine = MPSM_SEARCH_SOF; // next state
              break;                        // message not correct
            }
            received_checksum = ~received_checksum;
            if((received_checksum == checksum) && (message_addr == sbi_device_addr))
            {
              message_statemachine = MPSM_PROCESSING; // got a complete and uncorrupted message
            }
            else
            {
              message_statemachine = MPSM_SEARCH_SOF; // not for me
            }

            break;

          case MPSM_PROCESSING:
            break;

          default:
            message_statemachine = MPSM_SEARCH_SOF;
        } /* switch (t_message_statemachine) */
      } /* while(ub_UART_SBI_rx_buffer_n) */
    } /* else (t_message_statemachine) */
  } /* while(1) */
} /* fv_bootloader */

#define FLASH_ER_PRG_TIMEOUT ((uint32_t)17000)
#define FLASH_ERASE_TIMEOUT ((uint32_t)1700000)
static uint8_t bootloader_command(uint16_t command)
{
  uint32_t tmr;

  printf("\ncommand: %d\n", command);
  switch(command)
  {
    case 1:                                 // erase flash
      printf("Erasing uC flash\n");
      // turn off time-out, there will be no main code to return to
      TIM6->CR1 = 0;                        // TIM_Cmd(TIM6, DISABLE);
      if(FLASH->CR & FLASH_CR_LOCK)         // (the PERIPH_BB macro uses more code space)
      {
        FLASH->KEYR = 0x45670123;
        FLASH->KEYR = 0xCDEF89AB;
      }
      /* erase uC main program flash area (everything except bootloader), this takes
         some 600ms, during which the high-speed link is not operating properly */
      for(uint32_t i = BOOTLOADER_SIZE / STM_FLASH_PAGE_SIZE; i < NUMBER_OF_STM_FLASH_PAGES; i++)
      {
        FLASH->SR = FLASH_SR_ERROR_MASK;                 // clear any errors
        /* erase page */
        tmr = FLASH_ER_PRG_TIMEOUT;
        do{tmr--;}while((FLASH->SR & FLASH_SR_BSY) && tmr);
        if(tmr)
        {
          printf(".");
          PERIPH_BB(FLASH->CR, BB_FLASH_CR_PER) = 1; // page erase
          FLASH->CR &= ~FLASH_CR_PNB_Msk;   // clear page number
          FLASH->CR |= i << FLASH_CR_PNB_Pos; // page number
          PERIPH_BB(FLASH->CR, BB_FLASH_CR_STRT) = 1; // start page erase
          tmr = FLASH_ERASE_TIMEOUT;
          do{tmr--;}while((FLASH->SR & FLASH_SR_BSY) && tmr);
          PERIPH_BB(FLASH->CR, BB_FLASH_CR_PER) = 0;
        }
        if((!tmr) || (FLASH->SR & FLASH_SR_ERROR_MASK))
        {
          printf("\nPage %u Fail, FLASH_SR 0x%08X.\n",  (unsigned int)i, (unsigned int)FLASH->SR);
          return ERR_FAIL;
        }
      }
      printf(" done.\n");
      break;

    case 2:                                 // done, lock flash and reboot
      printf("\nProgramming Complete\n");
      PERIPH_BB(FLASH->CR, BB_FLASH_CR_LOCK) = 1; // FLASH Lock
      if(check_uc_flash_crc())          // this takes 7ms
      {
        return ERR_FAIL;
      }
      else
      {
        /* prepare timer for reboot in 10ms */
        TIM6->ARR = 26;                     // Set Autoreload
        TIM6->CNT = 0;                      // Set Counter
        TIM6->SR = 0;                       // clear any pending interrupts
        TIM6->CR1 = TIM_CR1_CEN;            // Enable counter
      }
      break;

    case 0x90B1:                            // enter boot mode
      break;

    default:
      printf("Unknown\n");
      return ERR_FAIL;
  } /* switch(command */
  return ERR_SUCCESS;
}

static uint8_t bootloader_data(void)
{
  uint32_t addr;

  addr = payload[0] * 256 + payload[1];
  addr *= 32;                             // address was sent divided by 32
  if(addr < BOOTLOADER_SIZE)
  {
    return ERR_SUCCESS;                      // silently discard bootloader addresses
  }
  printf(".");
  for(uint8_t i = 0; i < 32; i += 8)
  {
    /* program double word */
    uint32_t tmr = FLASH_ER_PRG_TIMEOUT;
    do{tmr--;}while((FLASH->SR & FLASH_SR_BSY) && tmr);
    if(tmr)
    {
      FLASH->SR = FLASH_SR_ERROR_MASK;               // clear all error flags
      PERIPH_BB(FLASH->CR, BB_FLASH_CR_PG) = 1;
      *(__IO uint32_t*)addr = (uint32_t)payload[5 + i] * 16777216 +
                                           payload[4 + i] * 65536 +
                                           payload[3 + i] * 256 + payload[2 + i];
      addr += 4;
      *(__IO uint32_t*)addr = (uint32_t)payload[9 + i] * 16777216 +
                                           payload[8 + i] * 65536 +
                                           payload[7 + i] * 256 + payload[6 + i];
      addr += 4;
      tmr = FLASH_ER_PRG_TIMEOUT;
      do{tmr--;}while((FLASH->SR & FLASH_SR_BSY) && tmr);
    }
    PERIPH_BB(FLASH->CR, BB_FLASH_CR_PG) = 0;
    if((!tmr) || (FLASH->SR & FLASH_SR_ERROR_MASK))
    {
      addr -= 8;
      printf(" - Failed, addr 0x%08X, FLASH_SR 0x%04X.\n", (unsigned int)addr, (unsigned int)FLASH->SR);
      return ERR_FAIL;
    }
  }
  return ERR_SUCCESS;
}

/* function to check uC flash CRC */
static uint8_t check_uc_flash_crc(void)
{

  uint32_t crc_result;                          // result of CRC calculation

  printf("Checking uC flash CRC: ");

  /* Reset CRC generator, using the STM32 default settings */
  CRC->POL = 0x04C11DB7U;
  CRC->INIT = 0xFFFFFFFFU;
  CRC->CR = CRC_CR_RESET;
  for(uint32_t i = 0; i < STM_ROM_SIZEinWORDS; i++)
  {
    CRC->DR = ((uint32_t *)STM_MAIN_ROM_START)[i];
  }
  crc_result = CRC->DR;

  if(0 == crc_result)
  {
    printf("Ok.\n");
    return 0;
  }
  else
  {
    printf("Fail, CRC = %08X.\n", (unsigned int)crc_result);
    return 1;
  }
}

/*-----------------------------------------------------------*/
void TIM6_DAC_IRQHandler(void);
void TIM6_DAC_IRQHandler(void)
{
  printf("Bootload mode timeout!\n");
  NVIC_SystemReset();
}

/* timer tick */
void TIM7_DAC_IRQHandler(void);
void TIM7_DAC_IRQHandler(void)
{

  static uint16_t heartbeat_tmr = 0;

  TIM7->SR = 0;                             // Clear interrupt pending bit

  if(heartbeat_tmr > 7000)
  {
    heartbeat_tmr = 0;
    LED_heartbeat_on();
  }
  else if(heartbeat_tmr > 3500)
  {
    LED_heartbeat_off();
  }
  else
  {
     /* No action required */
  }
  tick = true;
}

