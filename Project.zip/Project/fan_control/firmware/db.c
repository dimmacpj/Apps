/**************************************************************************//**
  \file   db.c
  \brief  database access functions
  \author Joseph Cooper
  \date   2023 June 09 (created)

  Functions to work with the DBArray in db_table.c

******************************************************************************/
#include "ena_datatype.h"
#include "ena_error_codes.h"

#include "db_table_size.h"
#include "db_table.h"
#include "sbi_buffer.h"
#include "db.h"

static uint16_t param_index;             // index for the % commands

/* find the index of a parameter name, using binary search */
uint16_t db_param_to_index(uint16_t addr)
{
  uint16_t max = DB_TABLE_SIZE; // last index, ignoring end of table entry
  uint16_t min = 0;
  uint16_t mid;
  uint16_t value;

  do
  {
    mid = (min + max)/2;
    if(mid >= DB_TABLE_SIZE)
    {
       return 0xFFFFU;                  // failed to find parameter name
    }
    value = DBArray[mid].param_name;
    if(addr == value)
    {
      return mid;
    }
    else
    {
      if(addr > value)
      {
        min = mid + 1;                  // mid point is too low
      }
      else
      {
        max = mid - 1;                  // mid point is too high
      }
    }
  } while(min <= max);
  return 0xFFFFU;                            // failed to find parameter name
}

uint8_t db_type_size(uint16_t table_index)
{
  uint8_t size = 0;
  switch(DBArray[table_index].db_type.type)
  {
    case DB_8:
      size = 1;
      break;

    case DB_16:
      size = 2;
      break;

    case DB_32:
    case DB_F:
      size = 4;
      break;

    case DB_S:
      /* maximum_value.l is the maximum string length */
      if ((DBArray[table_index].maximum_value.l > 0 )
          && (DBArray[table_index].maximum_value.l <= LONGEST_STRING))
      {
        _Static_assert(LONGEST_STRING <= UINT8_MAX, "Unsafe cast to uint8_t");
        size = (uint8_t)DBArray[table_index].maximum_value.l;
      }
      break;

    case DB_B:
      size = PROG_PAYLOAD_LEN;
      break;

    default:
      break;
  }
  return size;
}

bool db_check_range(uint16_t table_index, uDB_init u_DB)
{
  uDB_init minimum_value;
  uDB_init maximum_value;

  bool out_of_range = true;

  switch(DBArray[table_index].db_type.type)
  {
    case DB_8:
      if(ATTR_PTR_MIN == (DBArray[table_index].db_type.attrib & ATTR_PTR_MIN))
      {
        minimum_value.b = (int8_t)*DBArray[table_index].minimum_value.pkl;
      }
      else
      {
        minimum_value.b = (int8_t)DBArray[table_index].minimum_value.l;
      }

      if(ATTR_PTR_MAX == (DBArray[table_index].db_type.attrib & ATTR_PTR_MAX))
      {
        maximum_value.b = (int8_t)*DBArray[table_index].maximum_value.pkl;
      }
      else
      {
        maximum_value.b = (int8_t)DBArray[table_index].maximum_value.l;
      }

      if((u_DB.b < minimum_value.b) || (u_DB.b > maximum_value.b))
      {
        out_of_range = false;
      }
      break;

    case DB_16:
      if(ATTR_PTR_MIN == (DBArray[table_index].db_type.attrib & ATTR_PTR_MIN))
      {
        minimum_value.w = (int16_t)*DBArray[table_index].minimum_value.pkl;
      }
      else
      {
        minimum_value.w = (int16_t)DBArray[table_index].minimum_value.l;
      }

      if(ATTR_PTR_MAX == (DBArray[table_index].db_type.attrib & ATTR_PTR_MAX))
      {
        maximum_value.w = (int16_t)*DBArray[table_index].maximum_value.pkl;
      }
      else
      {
        maximum_value.w = (int16_t)DBArray[table_index].maximum_value.l;
      }

      if((u_DB.w < minimum_value.w) || (u_DB.w > maximum_value.w))
      {
        out_of_range = false;
      }
      break;

    case DB_32:
      if(ATTR_PTR_MIN == (DBArray[table_index].db_type.attrib & ATTR_PTR_MIN))
      {
        minimum_value.l = *DBArray[table_index].minimum_value.pkl;
      }
      else
      {
        minimum_value.l = DBArray[table_index].minimum_value.l;
      }

      if(ATTR_PTR_MAX == (DBArray[table_index].db_type.attrib & ATTR_PTR_MAX))
      {
        maximum_value.l = *DBArray[table_index].maximum_value.pkl;
      }
      else
      {
        maximum_value.l = DBArray[table_index].maximum_value.l;
      }

      if((u_DB.l < minimum_value.l) || (u_DB.l > maximum_value.l))
      {
        out_of_range = false;
      }
      break;

    case DB_F:
      if(ATTR_PTR_MIN == (DBArray[table_index].db_type.attrib & ATTR_PTR_MIN))
      {
        minimum_value.f = *DBArray[table_index].minimum_value.pkf;
      }
      else
      {
        minimum_value.f = DBArray[table_index].minimum_value.f;
      }

      if(ATTR_PTR_MAX == (DBArray[table_index].db_type.attrib & ATTR_PTR_MAX))
      {
        maximum_value.f = *DBArray[table_index].maximum_value.pkf;
      }
      else
      {
        maximum_value.f = DBArray[table_index].maximum_value.f;
      }

      if((u_DB.f < minimum_value.f) || (u_DB.f > maximum_value.f))
      {
        out_of_range = false;
      }
      break;

    /* don't handle these here, return okay by default for the purpose of eeprom init range checking */
    case DB_S:
    case DB_B:
    default:
      out_of_range = true;
      break;
  } /* switch(DBArray[table_index].db_type.type) */
  return out_of_range;
}


/* DBArray function for parameter %# */
t_error_code fdb_parameter_table_size(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
     u_ui_temp.w = DB_TABLE_SIZE;
     error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %P */
t_error_code fdb_sbi_port_number(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
     u_ui_temp.ul = port;
     error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %T */
t_error_code fdb_timestamp(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) port;                       // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
     u_ui_temp.ul = timestamp;
     error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %a */
t_error_code fdb_parameter_attrib(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
     u_ui_temp.w = DBArray[param_index].db_type.attrib;
     error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %d */
t_error_code fdb_parameter_default(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    if(0 == (DBArray[param_index].db_type.attrib & ATTR_PTR_DEFAULT))
    {
      u_ui_temp.l = DBArray[param_index].default_value.l;
    }
    else
    {
      u_ui_temp.l = *DBArray[param_index].default_value.pkl;
    }
    error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %e */
t_error_code fdb_parameter_eeprom(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.w = (0 != DBArray[param_index].eeprom_addr);
    error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %i */
t_error_code fdb_parameter_index(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  switch(read_write)
  {
    case MESSAGE_READ:
      u_ui_temp.uw = param_index;
      error = ERR_SUCCESS;
      break;

    case MESSAGE_WRITE:
      param_index = u_ui_temp.uw;
      error = ERR_SUCCESS;
      break;

    case MESSAGE_WRITE_INIT:
    default:
      error = ERR_FAIL;
      break;
  }

  return error;
}

/* DBArray function for parameter %m */
t_error_code fdb_parameter_max(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    if(0 == (DBArray[param_index].db_type.attrib & ATTR_PTR_MAX))
    {
      u_ui_temp.l = DBArray[param_index].maximum_value.l;
    }
    else
    {
      u_ui_temp.l = *DBArray[param_index].maximum_value.pkl;
    }
    error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %n */
t_error_code fdb_parameter_min(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    if(0 == (DBArray[param_index].db_type.attrib & ATTR_PTR_MIN))
    {
      u_ui_temp.l = DBArray[param_index].minimum_value.l;
    }
    else
    {
      u_ui_temp.l = *DBArray[param_index].minimum_value.pkl;
    }
    error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %p */
t_error_code fdb_parameter_name(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.uw = DBArray[param_index].param_name;
    error = ERR_SUCCESS;
  }
  return error;
}

/* DBArray function for parameter %t */
t_error_code fdb_parameter_type(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.uw = (uint16_t)DBArray[param_index].db_type.type;
    error = ERR_SUCCESS;
  }
  return error;
}
