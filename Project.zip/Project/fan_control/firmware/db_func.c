/**************************************************************************//**
  \file   db_func.c
  \brief  DB table functions
  \author Arthur de Beun
  \date   2013 September 17 (created)

******************************************************************************/
/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

#include <string.h>

#include "ena_datatype.h"
#include "ena_error_codes.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "variants.h"

#include "control.h"
#include "db_func.h"
#include "db_table.h"
#include "eeprom.h"
#include "events.h"
#include "main.h"
#include "sbi.h"

/* Local function prototypes */
void boot_timer_callback(TimerHandle_t pxTimer);

extern uint32_t bootload_var;            // shared variable with bootloader code, defined in linker script

t_error_code fdb_fans_on_off(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  static bool fan_cmd_on[2] = {false, false};
  bool ret_val;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.w = fans_on;
    ret_val = ERR_SUCCESS;
  }
  else if(MESSAGE_WRITE == read_write)
  {
    if(1 == port)
    {
      fan_cmd_on[0] = FANS_ON == u_ui_temp.w;
      ret_val = ERR_SUCCESS;
    }
    else if(2 == port)
    {
      fan_cmd_on[1] = FANS_ON == u_ui_temp.w;
      ret_val = ERR_SUCCESS;
    }
    else
    {
      ret_val = ERR_FAIL;
    }
    fans_on = fan_cmd_on[0] || fan_cmd_on[1];
  }
  else
  {
    ret_val = ERR_FAIL;
  }
  return ret_val;
}

/* Flash memory read only functions */

/* software checksum */
t_error_code read_sw_checksum(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code ret_val = ERR_FAIL;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = sw_checksum;
    ret_val = ERR_SUCCESS;
  }
  return ret_val;
}

/* software build time [unix time GMT] */
t_error_code read_sw_build_time(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code ret_val = ERR_FAIL;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = sw_time;
    ret_val = ERR_SUCCESS;
  }
  return ret_val;
}

/* software version (high word) and build number (low word) */
t_error_code read_sw_version(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code ret_val = ERR_FAIL;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = sw_version;
    ret_val = ERR_SUCCESS;
  }
  return ret_val;
}

t_error_code read_bootloader_checksum(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code ret_val = ERR_FAIL;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = *((uint32_t*)STM_BOOTLOADER_CRC_ADDR);
    ret_val = ERR_SUCCESS;
  }
  return ret_val;
}

t_error_code read_bootloader_id(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter
  t_error_code ret_val = ERR_FAIL;

  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.w = BOOTLOADER_ID;
    ret_val = ERR_SUCCESS;
  }
  return ret_val;
}

/* Stack high water marks */
t_error_code Eeprom_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = uxTaskGetStackHighWaterMark(Eeprom_Task_Handle);
     error = ERR_SUCCESS;
  }
  return error;
}

t_error_code SBI_TaskStackHighWaterMark(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = uxTaskGetStackHighWaterMark(SBI_Task_Handle);
    error = ERR_SUCCESS;
  }
  return error;
}

t_error_code FreeRTOS_tick_count(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  t_error_code error = ERR_FAIL;
  if(MESSAGE_READ == read_write)
  {
    u_ui_temp.ul = xTaskGetTickCount();
    error = ERR_SUCCESS;
  }
  return error;
}

/* timer callback to reset uC after SBI has had a chance to reply */
void boot_timer_callback(TimerHandle_t pxTimer)
{
  ( void ) pxTimer; // Stop compiler warning for unused parameter
  bootload_var = 0x90b16F4EU;
  NVIC_SystemReset();
}

t_error_code start_bootloader(tMSG read_write, uint32_t timestamp, uint32_t port)
{
  ( void ) timestamp;                       // Stop compiler warning for unused parameter
  ( void ) port;                            // Stop compiler warning for unused parameter

  static TimerHandle_t db_func_timer = NULL;
  static StaticTimer_t db_func_timer_buffer;
  t_error_code error = ERR_FAIL;

  if(NULL == db_func_timer)
  {
    db_func_timer = xTimerCreateStatic("Boot", 10, pdFALSE, NULL, boot_timer_callback, &db_func_timer_buffer);
  }

  if(MESSAGE_WRITE == read_write)
  {
    /* delay the reset until after the SBI task has replied to the message */
    if(pdPASS == xTimerStart(db_func_timer, 0 ))
    {
      BB(pbb_alarms, FLT_FIRMWARE) = 1;       // enter fault state to prevent starting
      error = ERR_SUCCESS;
    }
  }
  return error;
}

