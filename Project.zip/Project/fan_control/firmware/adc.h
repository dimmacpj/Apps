/**************************************************************************//**
  \file   adc.h
  \brief  adc hardware setup
******************************************************************************/
#ifndef FILE_ADC_H                     /* sentinel */
#define FILE_ADC_H

#include "ena_datatype.h"

void adc_hardware_init(void);

extern volatile float32_t ntc_pcb_temperature;
extern volatile float32_t ntc_1_temperature;
extern volatile float32_t ntc_2_temperature;
extern volatile float32_t aux_v;
extern volatile float32_t aux_v_gain;

#endif                                 /* end sentinel */
