/**************************************************************************//**
  \file   timestamp.c
  \brief  1us timestamp using 32bit timer 5.
          wraps around about every 71mins 35sec.
******************************************************************************/
#include "ena_datatype.h"
#include "periph_bb.h"

#include "hardware.h"

#include "timestamp.h"

/**
 * Initialise timer hardware peripheral for 1us timestamp.
 * Get the 32bit timestamp by reading from timer 5 count.
*/
void timestamp_hardware_init(void)
{
  BB_RCC_APB1ENR1_TIM5EN = 1;                          // Enable peripheral clock

  uint32_t delay_timer = BB_RCC_APB1ENR1_TIM5EN;       // delay to ensure timer clk initialised
  (void)(delay_timer);

  LL_TIM_SetCounterMode(TIM5, LL_TIM_COUNTERMODE_UP);
  LL_TIM_SetPrescaler(TIM5, 169);                      // 170MHz / (169 + 1) = 1MHz.
  LL_TIM_DisableARRPreload(TIM5);
  LL_TIM_SetAutoReload(TIM5, 0xFFFFFFFFU);
  LL_TIM_CC_DisablePreload(TIM5);                      // Disable CC preload so CCR1 is update on write not update event.
  LL_TIM_CC_EnableChannel(TIM5, LL_TIM_CHANNEL_CH1);
  TIM5->CNT = 0U;                                      // Clear the counter;
  TIM5->CCR1 = 0U;                                     // Write to CCR1. When undefined CC1F bit in TIM5_SR seems to get set
                                                       // at some time before first write to CCR1.
  LL_TIM_EnableCounter(TIM5);
  LL_TIM_GenerateEvent_UPDATE(TIM5);                   // Generate update event.
}
