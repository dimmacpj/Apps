/**************************************************************************//**
  \file   fan.c
  \brief  fan hardware setup
******************************************************************************/
#include "ena_datatype.h"
#include "ena_driver_stm32g4.h"

#include "hardware.h"

#include "fan.h"

#define FAN_PWM_PRESCALER (7)       // 170MHz / 7 + 1 = 21.25MHz
#define FAN_PWM_PERIOD (1024)       // 21.25MHz / 1024 = 20.752KHz
#define PULSES_1S_TO_MINUTE (60)    // Factor to convert from pulses per second to pulses per minute

static void fan1_pwm_hardware_init(void);
static void fan2_pwm_hardware_init(void);
static void fan1_tacho_hardware_init(void);
static void fan2_tacho_hardware_init(void);
static uint32_t get_fan_tacho(const uint16_t pulses_per_rev, TIM_TypeDef *const tim_x);

/**
 * Set both fans speed.
 *
 * @param fan_speed 0.0 (off) to 1.0 (full speed).
*/
void set_fan_speed(const float32_t fan_speed)
{
  float32_t fan_speed_pwm_scaled = fan_speed * FAN_PWM_PERIOD;
  uint32_t fan_pwm = (uint32_t)fan_speed_pwm_scaled;
  FAN1_PWM_TIMER_CCR = fan_pwm;
  FAN2_PWM_TIMER_CCR = fan_pwm;
}

/**
 * Get the fan 1 tacho.
 * Must be called at 1s period.
 *
 * @param pulses_per_rev tacho pulses per revolution.
 * @retval fan speed from the tacho in RPM
*/
uint32_t get_fan1_tacho(const uint16_t pulses_per_rev)
{
  return get_fan_tacho(pulses_per_rev, FAN1_TACHO_TIMER);
}

/**
 * Get the fan 2 tacho.
 * Must be called at 1s period.
 *
 * @param pulses_per_rev tacho pulses per revolution.
 * @retval fan speed from the tacho in RPM
*/
uint32_t get_fan2_tacho(const uint16_t pulses_per_rev)
{
  return get_fan_tacho(pulses_per_rev, FAN2_TACHO_TIMER);
}

/**
 * Initialise all GPIO and Timers used to control and monitor the fans.
*/
void fan_hardware_init(void)
{
  fan1_pwm_hardware_init();
  fan2_pwm_hardware_init();
  fan1_tacho_hardware_init();
  fan2_tacho_hardware_init();
}

/**
 * Get the fan tacho.
 * Must be called at 1s period.
 *
 * @param pulses_per_rev tacho pulses per revolution.
 * @param tim_x pointer to the timer peripheral.
 * @retval fan speed from the tacho in RPM.
*/
static uint32_t get_fan_tacho(const uint16_t pulses_per_rev, TIM_TypeDef *const tim_x)
{
  uint32_t rpm = 0;
  uint32_t cnt = tim_x->CNT; // read timer counter
  tim_x->CNT = 0; // clear timer counter
  cnt *= PULSES_1S_TO_MINUTE; // convert to pulses per minute
  if(pulses_per_rev >= 1)
  {  // Protect against division by 0
    rpm = cnt / pulses_per_rev; // convert to pulses rev per minute
  }
  return rpm;
}

/**
 * Initialise GPIO and Timer for fan 1 pwm.
*/
static void fan1_pwm_hardware_init(void)
{
  FAN1_PWM_TIMER_CLK_EN = 1;

  LL_GPIO_SetPinMode(FAN1_PWM_PORT, FAN1_PWM_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(FAN1_PWM_PORT, FAN1_PWM_PIN, LL_GPIO_PULL_NO);
  LL_GPIO_SetPinOutputType(FAN1_PWM_PORT, FAN1_PWM_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinSpeed(FAN1_PWM_PORT, FAN1_PWM_PIN, LL_GPIO_SPEED_FREQ_LOW);
  ena_gpio_set_af_pin(FAN1_PWM_PORT, FAN1_PWM_PIN, FAN1_PWM_AF);

  LL_TIM_SetPrescaler(FAN1_PWM_TIMER, FAN_PWM_PRESCALER);
  LL_TIM_SetAutoReload(FAN1_PWM_TIMER, FAN_PWM_PERIOD - 1);
  FAN1_PWM_TIMER_CCR = 0;
  LL_TIM_OC_SetMode(FAN1_PWM_TIMER, FAN1_PWM_TIMER_CH, LL_TIM_OCMODE_PWM2);
  LL_TIM_OC_ConfigOutput(FAN1_PWM_TIMER, FAN1_PWM_TIMER_CH, LL_TIM_OCPOLARITY_HIGH | LL_TIM_OCIDLESTATE_LOW);
  LL_TIM_OC_EnablePreload(FAN1_PWM_TIMER, FAN1_PWM_TIMER_CH);
  LL_TIM_CC_EnableChannel(FAN1_PWM_TIMER, FAN1_PWM_TIMER_CH_OUTPUT);
  LL_TIM_EnableAllOutputs(FAN1_PWM_TIMER);
  LL_TIM_EnableCounter(FAN1_PWM_TIMER);

}

/**
 * Initialise GPIO and Timer for fan 2 pwm.
*/
static void fan2_pwm_hardware_init(void)
{
  FAN2_PWM_TIMER_CLK_EN = 1;

  LL_GPIO_SetPinMode(FAN2_PWM_PORT, FAN2_PWM_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(FAN2_PWM_PORT, FAN2_PWM_PIN, LL_GPIO_PULL_NO);
  LL_GPIO_SetPinOutputType(FAN2_PWM_PORT, FAN2_PWM_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinSpeed(FAN2_PWM_PORT, FAN2_PWM_PIN, LL_GPIO_SPEED_FREQ_LOW);
  ena_gpio_set_af_pin(FAN2_PWM_PORT, FAN2_PWM_PIN, FAN2_PWM_AF);

  LL_TIM_SetPrescaler(FAN2_PWM_TIMER, FAN_PWM_PRESCALER);
  LL_TIM_SetAutoReload(FAN2_PWM_TIMER, FAN_PWM_PERIOD - 1);
  FAN2_PWM_TIMER_CCR = 0;
  LL_TIM_OC_SetMode(FAN2_PWM_TIMER, FAN2_PWM_TIMER_CH, LL_TIM_OCMODE_PWM2);
  LL_TIM_OC_ConfigOutput(FAN2_PWM_TIMER, FAN2_PWM_TIMER_CH, LL_TIM_OCPOLARITY_HIGH | LL_TIM_OCIDLESTATE_LOW);
  LL_TIM_OC_EnablePreload(FAN2_PWM_TIMER, FAN2_PWM_TIMER_CH);
  LL_TIM_CC_EnableChannel(FAN2_PWM_TIMER, FAN2_PWM_TIMER_CH_OUTPUT);
  LL_TIM_EnableAllOutputs(FAN2_PWM_TIMER);
  LL_TIM_EnableCounter(FAN2_PWM_TIMER);
}

/**
 * Initialise GPIO and Timer for fan 1 tacho input.
*/
static void fan1_tacho_hardware_init(void)
{
  FAN1_TACHO_TIMER_CLK_EN = 1;

  LL_GPIO_SetPinMode(FAN1_TACHO_PORT, FAN1_TACHO_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(FAN1_TACHO_PORT, FAN1_TACHO_PIN, FAN1_TACHO_PULL);
  ena_gpio_set_af_pin(FAN1_TACHO_PORT, FAN1_TACHO_PIN, FAN1_TACHO_AF);

  FAN1_TACHO_TIMER->TISEL = 0; // selects the tim_tix = tim_CHx
  LL_TIM_SetClockDivision(FAN1_TACHO_TIMER, LL_TIM_CLOCKDIVISION_DIV4); // tDTS = 4 / 170MHz
  LL_TIM_IC_Config(FAN1_TACHO_TIMER, FAN1_TACHO_TIMER_CH, LL_TIM_ACTIVEINPUT_DIRECTTI |
                                              LL_TIM_ICPSC_DIV1 |
                                              LL_TIM_IC_FILTER_FDIV32_N8 |  // 32 * tDTS * 8 = about 6.8us
                                              LL_TIM_IC_POLARITY_FALLING);
  LL_TIM_IC_SetPolarity(FAN1_TACHO_TIMER, FAN1_TACHO_TIMER_CH, LL_TIM_IC_POLARITY_FALLING);
  LL_TIM_SetClockSource(FAN1_TACHO_TIMER, LL_TIM_CLOCKSOURCE_EXT_MODE1);
  LL_TIM_SetTriggerInput(FAN1_TACHO_TIMER, FAN1_TACHO_TIMER_INPUT_SEL);
  LL_TIM_EnableCounter(FAN1_TACHO_TIMER);
}

/**
 * Initialise GPIO and Timer for fan 2 tacho input.
*/
static void fan2_tacho_hardware_init(void)
{
  FAN2_TACHO_TIMER_CLK_EN = 1;

  LL_GPIO_SetPinMode(FAN2_TACHO_PORT, FAN2_TACHO_PIN, LL_GPIO_MODE_ALTERNATE);
  LL_GPIO_SetPinPull(FAN2_TACHO_PORT, FAN2_TACHO_PIN, FAN2_TACHO_PULL);
  ena_gpio_set_af_pin(FAN2_TACHO_PORT, FAN2_TACHO_PIN, FAN2_TACHO_AF);

  FAN2_TACHO_TIMER->TISEL = 0; // selects the tim_tix = tim_CHx
  LL_TIM_SetClockDivision(FAN2_TACHO_TIMER, LL_TIM_CLOCKDIVISION_DIV4); // tDTS = 4 / 170MHz
  LL_TIM_IC_Config(FAN2_TACHO_TIMER, FAN2_TACHO_TIMER_CH, LL_TIM_ACTIVEINPUT_DIRECTTI |
                                              LL_TIM_ICPSC_DIV1 |
                                              LL_TIM_IC_FILTER_FDIV32_N8 |  // 32 * tDTS * 8 = about 6.8us
                                              LL_TIM_IC_POLARITY_FALLING);
  LL_TIM_IC_SetPolarity(FAN2_TACHO_TIMER, FAN2_TACHO_TIMER_CH, LL_TIM_IC_POLARITY_FALLING);
  LL_TIM_SetClockSource(FAN2_TACHO_TIMER, LL_TIM_CLOCKSOURCE_EXT_MODE1);
  LL_TIM_SetTriggerInput(FAN2_TACHO_TIMER, FAN2_TACHO_TIMER_INPUT_SEL);
  LL_TIM_EnableCounter(FAN2_TACHO_TIMER);
}
