/**************************************************************************//**
  \file   ena_maths.h
  \brief  miscellaneous maths functions header file
  \author Arthur de Beun
  \date   2013 September 27 (created)

******************************************************************************/
#ifndef FILE_ENA_MATHS_H /* sentinel */
#define FILE_ENA_MATHS_H

#include "ena_datatype.h"

/* global function prototypes */
float32_t ff_PI_controller(const tPI_modes t_mode, const float32_t f_error, volatile tPIsat *tPIsat_params, const float32_t f_ll, const float32_t f_ul) __attribute__ ((section (".ccmram")));
int16_t fw_PI_controller (const int16_t w_error_pu, volatile tPIsat_i *tPIsat_params, const int16_t w_ll, const int16_t w_ul);


/* type defintions */
typedef struct                         /* stationary reference frame alpha beta*/
{
  float32_t alpha;                     /* real component */
  float32_t beta;                      /* imaginary component */
} t_alpha_beta;

typedef struct                         /* synchronous reference frame direct-quadrature */
{
  float32_t d;                         /* direct - real component */
  float32_t q;                         /* quadrature - imaginary component */
} t_dq;

typedef struct                         /* 3rd order integrator 1/z values */
{
  float32_t f_uk_1;
  float32_t f_uk_2;
} t3int;

typedef struct                         /* SOGI QSG */
{
  t_alpha_beta ab;
  struct                               /* integrator storage for SOGI QSG */
  {
    t3int integrator_1;                /* 3rd order integrator 1/z values */
    t3int integrator_2;
  } internal;
} t_sogi_qsg;




/* global variable definitions/declarations */

#define HALF_PI (1.570796327F)              /* pi divided by 2 */
#define HALF_PI_Q (0x3FFFFFFF)              /* pi divided by 2 (CORDIC q1.31) */
#define TWO_THIRDS_PI_Q (0x55555554)        /* 2/3 pi (CORDIC q1.31) */
#define PI (3.141592654F)                   /* pi */
#define ONE_AND_HALF_PI (4.712388981F)      /* 3 pi / 2 */
#define ONE_AND_HALF_PI_Q (0xC0000000)      /* 3 pi / 2 (CORDIC q1.31) */
#define TWO_PI (6.283185308F)               /* pi times 2 */
#define ONE_UPON_PI (1.0F/PI)               /* 1/pi */
#define ONE_UPON_TWO_PI (1.0F/TWO_PI)       /* 1/(2 * pi) */
#define SQRT_2 (1.414213562F)               /* sqrt(2) */
#define ONE_UPON_SQRT_2 (1.0F/SQRT_2)       /* 1/sqrt(2) */
#define PERCENT (1.0F/100.0F)               /* 1/100 */
#define U_8BIT_MAX (255)
#define S_8BIT_MAX (127)
#define S_8BIT_MIN (-128)
#define S_9BIT_MIN (-256)
#define S_9BIT_MAX (255)
#define U_12BIT_MAX (4095)
#define ADC_12BIT_RANGE  (4096)
#define ADC_13BIT_RANGE  (8192)
#define ADC_14BIT_RANGE (16384)
#define ADC_15BIT_RANGE (32768)
#define ADC_16BIT_RANGE (65536)

/* minimum of x,y - type is passed on */
#define min(x,y) (( (x) < (y) ) ? (x) : (y))

/* maximum of x,y - type is passed on */
#define max(x,y) (( (x) > (y) ) ? (x) : (y))

/* return x limited to between ll and ul */
#define sat(x, ll, ul) (( (x) >= (ul) ) ? (ul) : ( ( (x) <= (ll) ) ? (ll) : (x) ))
#define sat_l(x, ll, ul) (( (x) >= (int32_t)(ul) ) ? (int32_t)(ul) : ( ( (x) <= (int32_t)(ll) ) ? (int32_t)(ll) : (x) ))
#define sat_w(x, ll, ul) (( (x) >= (int16_t)(ul) ) ? (int16_t)(ul) : ( ( (x) <= (int16_t)(ll) ) ? (int16_t)(ll) : (x) ))

/* fixed point math definitions */
#define RENORMALISE (13)                    /* exponent to renormalise after pu calculation */
#define ONE_PU (1 << RENORMALISE)
#define FOUR_DPU_MINUS_1    (0x0FFFFFFFL)
#define EIGHT_DPU_MINUS_1   (0x1FFFFFFFL)

/* macros to convert from single to double and double to single precision. The
   standard integer/fractional format is assumed. A long value must be defined
   for x if a 32 bit value is expected - this is normally the case */
#define dtos(x) ((x) >> RENORMALISE)
#define stod(x) (((int32_t)(x)) << RENORMALISE)

/* signed 16x16 multiply, 32 bit result */
#define fl_mul(w_x, w_y)        ((int32_t)((int16_t)(w_x)) * (int32_t)((int16_t)(w_y)))

/* unsigned 16x16 multiply, 32 bit result */
#define ful_mul(uw_x, uw_y)     ((uint32_t)((uint16_t)(uw_x)) * (uint32_t)((uint16_t)(uw_y)))

/* signed 16x16 multiply and rescale, 16 bit result */
#define fw_muldtos(w_x, w_y)    (dtos((int32_t)((int16_t)(w_x)) * (int32_t)((int16_t)(w_y)) ))

/* usigned 16x16 multiply and rescale, 16 bit result */
#define fuw_muldtos(uw_x, uw_y) (dtos((uint32_t)((uint16_t)(uw_x)) * (uint32_t)((uint16_t)(uw_y)) ))


/* fixed point multiplication l_x by the float scale value f_y
  It is expected here that f_y is constant at compile time to avoid using floating point math at run time.
  Use this function if no other floating point operations are used in the current context to avoid the
  floating point context save and restore overhead*/
__STATIC_FORCEINLINE int32_t fl_mul_pu_l_f(int32_t l_x, const float32_t f_y)
{
  return dtos(l_x * (int16_t)(((float32_t)ONE_PU * f_y) + 0.5));
}

/******************************************************************************
 Function block

   Name       : first_order_filter
   Description:

   Ref: "Hands-on Digital Signal Processing" by Taylor & Mellott, page 408

   RC low pass filter transfer function is

             1                                 Ts       1
   H(s) = ------- , and the Z-transform H(Z) = -- ---------------
          1 + RsC                              RC      -Ts/RC  -1
                                                  1 - e       Z

                                     1
   let a0 = Ts/RC,    H(Z) = a0 ------------
                                     -a0  -1
                                1 - e    Z

                x
   approximate e  by using the first two terms of the exponential series: 1 + x
   this approximation is accurate to about
    5% over the interval -0.29 < x < 0.35
   10%                   -0.39 < x < 0.53
   20%                   -0.53 < x < 0.82

                    1           Y(Z)
   H(Z) = a0 ---------------- = ----
                           -1   U(Z)
             1 - (1 - a0) Z


              -1       -1
   Y(Z) (1 - Z   + a0 Z  ) = a0 U(Z)

                             -1         -1
   Y(Z) = a0 U(Z) - a0 Y(Z) Z   + Y(Z) Z

   inverse Z-transform:

   y(k) = a0 u(k) - a0 y(k-1) + y(k-1)

   this is what is implemented below

******************************************************************************/

static inline void first_order_filter(float32_t f_uk, volatile float32_t *pf_yk, const float32_t f_a0)
{
  float32_t f_yk_copy = *pf_yk;                 // copy needed as speeds code by reducing a load operation
  f_yk_copy += f_a0 * (f_uk - f_yk_copy);   /* y(k) = a0 (u(k) - y(k-1)) + y(k-1) */
  *pf_yk = f_yk_copy;
}


/******************************************************************************

  Resonant controller
                                            ,-----,
                             ,--------------| 2wc |<-------------,
                             |              '-----'              |
                         (4) |                                   |
                             |-            ,-------,             |
                 ,----,   +  v         (5) |   1   | (6)         |
     error(z)--->| Kr |---->(+)----------->| ----- |-------------o---> y(z)
                 '----' (1)  ^             | Z - 1 |             |
                             |-            '-------'             |
                         (3) |                                   |
                             |                       ,-------,   |
                             |   ,-------------,     |   Z   |   |
                             '---| (w0 * Ts)^2 |<----| ----- |<--'
                                 '-------------' (2) | Z - 1 |
                                                     '-------'

  To prevent an algebraic loop, the integrator in the forward path is implemented
  using the Forward Euler method and the integrator in the feedback path is
  implemented using the Backward Euler method.

  Forward Euler:

    1        1
    - = Ts -----          y(k) = y(k-1) + Ts * u(k-1)
    S      Z - 1

  Backward Euler:

    1        Z
    - = Ts -----          y(k) = y(k-1) + Ts * u(k)
    S      Z - 1

  w0 is the resonant frequency
  Kr is the resonant gain
  2wc sets the quality factor (smaller value -> narrower resonant peak and slower transient response)

  (Normally this would be implemented as a proportional-resonant controller, but
  since this one is intended to be used in parallel with a PI controller the
  proportional path is not implemented.)

  Refs:
  1 Digital Proportional-Resonant (PR) Control with Anti-Windup Applied to a Voltage-Source Inverter
    TK_Technology_-_Electrical_Electronics_Nuclear_engineering/ieee/
      Power_Electronics_and_Applications_Conference/2011/06020292.pdf

  2 Proportional-resonant controllers and filters for grid-connected voltage-source converters
    TK_Technology_-_Electrical_Electronics_Nuclear_engineering/iee/
      Electric_Power_Applications_Proceedings/2006/2006v153n05/
      Proportional-resonant_controllers_and_filters.pdf

******************************************************************************/
__STATIC_FORCEINLINE float32_t ff_R_controller(const float32_t f_error, const float32_t f_we,
                                     volatile tR *tR_params, const float32_t sample_period)
{
  float32_t f_temp;                             /* temporary variable */

  /* calculate the new output value: y1(k) = y1(k-1) + u1(k-1) */
  tR_params->f_y1 += tR_params->f_u1_1; /* (6) */

  /* calculate the resonator input gain term: error(k) * Kr */
  f_temp = tR_params->f_kr * f_error;   /* (1) */

  /* calculate integrator 2 output (feedback path) y2(k) = y2(k-1) + u2(k), where u2(k) = y1(k) */
  tR_params->f_y2 += tR_params->f_y1;   /* (2) */

  /* calculate integrator 1 input u1(k) and keep for next time */
  f_temp -= f_we * f_we * sample_period * sample_period * tR_params->f_y2; /* (1) - (3) */
  tR_params->f_u1_1 = f_temp - tR_params->f_k2wc * tR_params->f_y1; /* u1(k) = (5) = (1) - (3) - (4)  */

  return tR_params->f_y1;               /* (6) */
}

/******************************************************************************
   Third order integrator, refer to Fig. 9 of
   A New Single-Phase PLL Structure Based on Second Order Generalized Integrator
   Mihai Ciobotaru, Remus Teodorescu and Frede Blaabjerg
   Power Electronics Specialists Conference 2006
******************************************************************************/
__STATIC_FORCEINLINE float32_t third_order_integrator(float32_t f_uk, t3int *t3int_uk, const float32_t ts)
{
  float32_t f_uk_3;
  float32_t f_temp;

  /* calculate the input term */
  f_temp = f_uk * (ts/12.0F);
  f_temp += t3int_uk->f_uk_1;

  /* shift samples along */
  f_uk_3 = t3int_uk->f_uk_2;
  t3int_uk->f_uk_2 = t3int_uk->f_uk_1;
  t3int_uk->f_uk_1 = f_temp;

  /* calculate the output term */
  f_temp *= 23.0F;
  f_temp -= t3int_uk->f_uk_2 * 16.0F;
  f_temp += f_uk_3 * 5.0F;
  return f_temp;
}

/******************************************************************************
  Generate alpha-beta quadrature signals from input u using a second order generalised integrator (SOGI), ref
  A New Single-Phase PLL Structure Based on Second Order Generalized Integrator
  Mihai Ciobotaru, Remus Teodorescu and Frede Blaabjerg
  Power Electronics Specialists Conference 2006
  Also refer diagram SecondOrderGeneralisedIntegrator.odg
  k = 1
******************************************************************************/
__STATIC_FORCEINLINE void sogi_qsg(float32_t u, t_sogi_qsg *state, float32_t omega, const float32_t ts)
{
  float32_t temp;
  temp = u - state->ab.alpha;
  temp -= state->ab.beta;
  temp *= omega;
  state->ab.alpha = third_order_integrator(temp, &state->internal.integrator_1, ts);
  temp = state->ab.alpha * omega;
  state->ab.beta = third_order_integrator(temp, &state->internal.integrator_2, ts);
}

/* stationary to synchronous reference frame transformation of alpha beta (Park vector transform) */
__STATIC_FORCEINLINE t_dq park_transform_dq(t_alpha_beta alpha_beta, float32_t cos_ref, float32_t sin_ref)
{
  t_dq result;
  result.d = (cos_ref * alpha_beta.alpha) + (sin_ref * alpha_beta.beta);
  result.q = (cos_ref * alpha_beta.beta) - (sin_ref * alpha_beta.alpha);
  return result;
}

/* crc-8 calculation */
__STATIC_FORCEINLINE uint8_t crc8(uint8_t ub_operant1, uint8_t ub_operant2)
{
  extern const uint8_t aub_crc8[256];
  return aub_crc8[ub_operant1 ^ ub_operant2];
}

/* Convert unsigned int to signed int.
 * This is in its own function because it is implementation defined.
 * As per GCC implementation: "For conversion to a type of width N, the value is reduced modulo 2^N to be within range of the type; no signal is raised.""
*/
__STATIC_FORCEINLINE int32_t uint2int(uint32_t value)
{
  int32_t converted_value = (int32_t)value;
  return converted_value;
}

#endif /* end sentinel */
