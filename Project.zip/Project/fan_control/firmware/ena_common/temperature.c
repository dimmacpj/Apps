/**************************************************************************//**
  \file   temperature.c
  \brief  convert ADC value to degrees C
  \author Arthur de Beun
  \date   2014 April 02 (created)


******************************************************************************/
#include "ena_datatype.h"

#include "temperature.h"

/******************************************************************************
  Look-up table to convert ADC results to temperature. Expects a 12-bit ADC value.
  The first entry is for ADC result = 192. Each following entry is for an ADC result
  that is 128 greater. The last entry is for ADC result = 4032.
  The entries in the table are degC.

  Calculated with spreadsheet Thermistor_473ETK-0805-FL-1P_Takanawa.ods.

  Takanawa 473ETK-0805-FL-1P thermistor with a 15k pullup resistor to Vref

  Referring to the spreadsheet, the initial lookup table has zero error at the
  data points and a uni-polar error in between. By hand-optimising the lookup
  table values the error was centred approximately around zero. The table
  implemented below is from column "T lookup 2".

  The error is less than +/-0.5C in the range
    -14 < T < 135
  and less than to +/-1C outside that range (except for -29C, which is 1.3C).

******************************************************************************/
const float32_t ntc_lut[31] = {
  157.3714F, 134.0429F, 119.6048F, 108.9611F, 100.5426F,  93.5522F,  87.5146F,  82.1706F, //  192 - 1088
   77.3589F,  72.9485F,  68.8450F,  64.9849F,  61.3237F,  57.8107F,  54.4078F,  51.0897F, // 1216 - 2112
   47.8228F,  44.5824F,  41.3419F,  38.0773F,  34.7507F,  31.3392F,  27.8027F,  24.0652F, // 2250 - 3136
   20.0903F,  15.7362F,  10.8805F,   5.2542F,  -1.6735F, -11.1738F, -28.0250F};          // 3264 - 4032

const uint16_t ntc_adc_offset = 192U;  // table starting offset (12bit ADC)
const uint16_t ntc_adc_end = 4032U;    // table ending value (12bit ADC)
const uint16_t ntc_adc_scale = 128U;   // equivalent to >> 7

uint8_t ntc_lookup(uint16_t adc_val, float32_t* temperature)
{
  uint16_t temp;
  uint16_t index;
  float32_t fract;
  float32_t temperature_local = -100.0F;   // nonsense value, but rectifier continues to operate normally
  uint8_t ret_val = 0U;                     // indicate that temperature is incorrect

  if((adc_val >= ntc_adc_offset) && (adc_val <= ntc_adc_end))
  {                                           // in table range, convert to degC
    temp = adc_val - ntc_adc_offset;          // subtract start offset of table
    index = temp / ntc_adc_scale;             // index into table
    fract = ((float32_t)temp / ntc_adc_scale) - (float32_t)index; // fraction between index entries
    temperature_local = ntc_lut[index];
    if(fract > 0.0F)                          // this prevents stepping beyond end of table if ADC result = 4032
    {
      temperature_local += fract * (ntc_lut[index + 1U] - temperature_local); // get the next entry in the table and interpolate
    }
    ret_val = 1U;                                 // indicate that temperature is correct
  }
  *temperature = temperature_local;
  return ret_val;
}
