/**************************************************************************//**
  \file   ena_error_codes.h
  \copyright Enatel

  \brief  general error codes

******************************************************************************/

#ifndef FILE_ENA_ERROR_CODES_H /* sentinel */
#define FILE_ENA_ERROR_CODES_H

/* error codes */
typedef enum
{
  ERR_SUCCESS = 0,
  ERR_NOTIFY_SUCCESS = 1,    // Used to notify success error state via FreeRTOS task notify, as 0 is reserved for no notification
  ERR_IN_PROGRESS = 6,       // still in progress
  ERR_WAIT_SOF = 7,          // waiting to receive SOF
  ERR_BUFFER_EMPTY = 8,      // the buffer is empty, no new data
  ERR_TIMEOUT = 32,          // response took too long
  ERR_TOO_SHORT = 33,        // there were not enough message bytes
  ERR_NO_START = 34,         // couldn't find the start character
  ERR_WRONG_CHR = 35,        // expected a hex character but got something else
  ERR_WRONG_DEL = 36,        // expected the delimiter but got something else
  ERR_CHECKSUM = 37,         // checksum wrong
  ERR_VALUE = 38,            // returned parameter value != desired parameter value when setting variable
  ERR_PARAM = 39,            // returned parameter name != desired parameter name
  ERR_ADDR = 40,             // returned address != desired address
  ERR_OPERATION_FAIL = 42,   // operation failed returned :AA,PP*SS
  ERR_REQUEST = 46,          // message is a request was expecting response
  ERR_RESPONSE = 47,         // message is response was expecting request
  ERR_PARAM_NOT_FOUND = 48,  // parameter not found in dB table
  ERR_BROADCAST = 49,        // message was for a broadcast address
  ERR_OPERATION_UNSUPPORTED = 50, // unsupported operation
  ERR_PAYLOAD_LENGTH = 51,        // the payload length does not match the parameter length
  ERR_OUT_OF_RANGE = 52,          // the value is larger than the max or less than the min
  ERR_PAYLOAD_OVERFLOW = 53,      // Payload is longer than the payload buffer
  ERR_PARM_NO_READ = 54,          // variable is not readable
  ERR_PARM_NO_WRITE = 55,         // variable is not writable
  ERR_REQUEST_PARM = 56,          // paramater name does not match that requested
  ERR_BUFFER_FULL = 57,           // Buffer is full or has failed to empty
  ERR_LINK_READ_FAIL = 60,
  ERR_LINK_WRITE_FAIL = 61,
  ERR_LINK_QUEUE_FAIL = 62,
  ERR_LINK_NOT_INIT = 63,         // link initialisation not complete
  ERR_RTOS_QUEUE_FULL = 101,      // failed to add to RTOS queue
  ERR_REASON_UNKOWN = 254,   // code has not taken a path to set the error code
  ERR_FAIL = 255             // generic fail
} t_error_code;

#endif /* sentinel */
