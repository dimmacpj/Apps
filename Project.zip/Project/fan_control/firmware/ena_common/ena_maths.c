/**************************************************************************//**
  \file   ena_maths.c
  \brief  miscellaneous maths functions
  \author Arthur de Beun
  \date   2013 September 27 (created)

******************************************************************************/

#include "ena_datatype.h"

#include "ena_maths.h"

/******************************************************************************
 CCITT 8-bit CRC, polynomial: x^8 + x^2 + x + 1

 Verified using on-line CRC calculator:
   http://zorc.breitbandkatze.de/crc.html
 with settings: CRC polynomial      0x07
                initial value       0xFF, direct
                final XOR           0x00
                reverse data bytes  no
                reverse CRC result  no

 The string 'abc' has CRC 0x74, also see mathsTest.cpp.

 Also verified using the STM32 CRC peripheral, for configuration see link.c

*****************************************************************************/
const uint8_t aub_crc8[256] = {
/*        -0   -1   -2   -3   -4   -5   -6   -7   -8   -9   -A   -B   -C   -D   -E   -F */
/* 0- */ 0x00,0x07,0x0E,0x09,0x1C,0x1B,0x12,0x15,0x38,0x3F,0x36,0x31,0x24,0x23,0x2A,0x2D,  /*   0 ... 15 */
/* 1- */ 0x70,0x77,0x7E,0x79,0x6C,0x6B,0x62,0x65,0x48,0x4F,0x46,0x41,0x54,0x53,0x5A,0x5D,  /*  16 ... 31 */
/* 2- */ 0xE0,0xE7,0xEE,0xE9,0xFC,0xFB,0xF2,0xF5,0xD8,0xDF,0xD6,0xD1,0xC4,0xC3,0xCA,0xCD,  /*  32 ... 47 */
/* 3- */ 0x90,0x97,0x9E,0x99,0x8C,0x8B,0x82,0x85,0xA8,0xAF,0xA6,0xA1,0xB4,0xB3,0xBA,0xBD,  /*  48 ... 63 */
/* 4- */ 0xC7,0xC0,0xC9,0xCE,0xDB,0xDC,0xD5,0xD2,0xFF,0xF8,0xF1,0xF6,0xE3,0xE4,0xED,0xEA,  /*  64 ... 79 */
/* 5- */ 0xB7,0xB0,0xB9,0xBE,0xAB,0xAC,0xA5,0xA2,0x8F,0x88,0x81,0x86,0x93,0x94,0x9D,0x9A,  /*  80 ... 95 */
/* 6- */ 0x27,0x20,0x29,0x2E,0x3B,0x3C,0x35,0x32,0x1F,0x18,0x11,0x16,0x03,0x04,0x0D,0x0A,  /*  96 .. 111 */
/* 7- */ 0x57,0x50,0x59,0x5E,0x4B,0x4C,0x45,0x42,0x6F,0x68,0x61,0x66,0x73,0x74,0x7D,0x7A,  /* 112 .. 127 */
/* 8- */ 0x89,0x8E,0x87,0x80,0x95,0x92,0x9B,0x9C,0xB1,0xB6,0xBF,0xB8,0xAD,0xAA,0xA3,0xA4,  /* 128 .. 143 */
/* 9- */ 0xF9,0xFE,0xF7,0xF0,0xE5,0xE2,0xEB,0xEC,0xC1,0xC6,0xCF,0xC8,0xDD,0xDA,0xD3,0xD4,  /* 144 .. 159 */
/* A- */ 0x69,0x6E,0x67,0x60,0x75,0x72,0x7B,0x7C,0x51,0x56,0x5F,0x58,0x4D,0x4A,0x43,0x44,  /* 160 .. 175 */
/* B- */ 0x19,0x1E,0x17,0x10,0x05,0x02,0x0B,0x0C,0x21,0x26,0x2F,0x28,0x3D,0x3A,0x33,0x34,  /* 176 .. 191 */
/* C- */ 0x4E,0x49,0x40,0x47,0x52,0x55,0x5C,0x5B,0x76,0x71,0x78,0x7F,0x6A,0x6D,0x64,0x63,  /* 192 .. 207 */
/* D- */ 0x3E,0x39,0x30,0x37,0x22,0x25,0x2C,0x2B,0x06,0x01,0x08,0x0F,0x1A,0x1D,0x14,0x13,  /* 208 .. 223 */
/* E- */ 0xAE,0xA9,0xA0,0xA7,0xB2,0xB5,0xBC,0xBB,0x96,0x91,0x98,0x9F,0x8A,0x8D,0x84,0x83,  /* 224 .. 239 */
/* F- */ 0xDE,0xD9,0xD0,0xD7,0xC2,0xC5,0xCC,0xCB,0xE6,0xE1,0xE8,0xEF,0xFA,0xFD,0xF4,0xF3}; /* 240 .. 255 */

/******************************************************************************

    saturating PI controller, using BILINEAR TRANSFORM method

    THE CONTINUOUS-TIME CONTROL LAW
    ===============================

    the PI control law is derived as follows:

    Result(s) = e(s)*Kp*[1 + Wi/s] = the output

    error(s) = Setpoint(s) - Actual(s) = the error signal

    Setpoint(s) = the desired value of the controlled variable

    Actual(s) = the measured value of the controlled variable

    This can be re-written as:

    Result(s) = error(s)*Kp + error(s)*Kp*Wi/s


    DISCRETISING THE CONTROL LAW
    ============================

    The BILINEAR TRANSFORM method is used to generate the discrete-time
    equivalent controller. This defines the laplace operator as
    s = [2/Ts]*(1 - 1/z)/(1 + 1/z)
    where 1/z = a delay of one sample time, and Ts is the sample time.

    Thus:

    Result(z) = error(z)*Kp + error(z)*Kp*Wi*[Ts/2]*(1 + 1/z)/(1 - 1/z)

    define Ki = Wi*Ts/2

    giving:

    Result(z) = error(z)*Kp + error(z)*Kp*Ki*(1 + 1/z)/(1 - 1/z)


    The transfer function (1 + 1/z)/(1 - 1/z) is represented as follows:
    H(z) = Y(z)/X(z) = output(z)/input(z) = (1 + 1/z)/(1 - 1/z)

    so Y(z)*(1 - 1/z) = X(z)*(1 + 1/z)

    i.e. Y(z) = Y(z)*1/z + X(z) + X(z)*1/z

    i.e. Y(z) = [Y(z) + X(z)]*1/z + X(z)

    Thus the TRANSPOSED DIRECT FORM implementation of (1 + 1/z)/(1 - 1/z) is:

    X(z)--o---->(+)-----o---> Y(z)
          |      ^      |
          |      |      |
          |   ,-----,   |
          |   | 1/z |   |
          |   '-----'   |
          |      ^      |
          |      |      |
          '---->(+)<----'



    The block diagram of the complete PI controller is therefore:

                         ,----, (1)  ,----, (2)            (3)               (5)
           error(z)----->| Kp |--o-->| Ki |------o---->(+)-----o-------->(+)------> Result(z)
                         '----'  |   '----'      |      ^      |          ^
                                 |               |      |      |          |
                                 |               |   ,-----,   |          |
                                 |               |   | 1/z |   |          |
                                 |               |   '-----'   |          |
                                 |               |      ^(4)   |          |
                                 |               |      |      |          |
                                 |               '---->(+)<----'          |
                                 |                                        |
                                 '----------------------------------------'



    NOTE: the "Ki" term is actually wi*Ts/2

   Input data:
   Parameters:
   Returns   :

******************************************************************************/
float32_t ff_PI_controller(const tPI_modes t_mode, const float32_t f_error, volatile tPIsat *tPIsat_params,
                       const float32_t f_ll, const float32_t f_ul) /* saturating PI controller */
{
  float32_t f_temp;                             /* temporary variable */
  float32_t f_proportional;                     /* proportional term, error(k)*Kp */
  float32_t f_integral;                         /* integral term, error(k)*Kp*Ki* */

  switch(t_mode)
  {
    case PI_NORMAL:
      /* calculate the proportional term: error(k) * Kp */
      f_proportional = tPIsat_params->f_kp * f_error; /* (1) */

      /* calculate the integrator input term: error(k) * Kp * Ki */
      f_temp = tPIsat_params->f_ki * f_proportional; /* (2) */

      /* calculate the integral term: error(k)*Kp*Ki*(1+1/z)/(1-1/z) */
      f_integral = f_temp + tPIsat_params->f_integrator; /* (3) */

      /* update the integrator: integrator(k) = integrator(k-1) + 2*error(k)*Kp*Ki */
      f_temp = f_integral + f_temp; /* (4) */

      /* saturate the integrator to limits */
      tPIsat_params->f_integrator = sat(f_temp, f_ll, f_ul); /* (4) */

      /* calculate the output term: proportional(k) + integral(k) */
      f_temp = f_proportional + f_integral; /* (5) */
      /* saturate the output term between the lower limit and the upper limit */
      f_temp = sat(f_temp, f_ll, f_ul);

      /* assign it to the output variable */
      return f_temp;

    case PI_DISABLE:
    case PI_INIT:
    default:
      tPIsat_params->f_integrator = 0.0;
      return 0.0;

    case PI_HOLD:
      return tPIsat_params->f_integrator;
  }
}

int16_t fw_PI_controller (const int16_t w_error_pu, volatile tPIsat_i *tPIsat_params,
                          const int16_t w_ll,
                          const int16_t w_ul) /* saturating PI controller */
{
  int32_t l_temp_dpu;                       /* temporary variable */
  int32_t l_proportional_dpu;               /* proportional term, error(k)*Kp */
  int32_t l_integral_dpu;                   /* integral term, error(k)*Kp*Ki* */

  /* calculate the proportional term: error(k) * Kp [DPU]
     NOTE: error(k) MUST have been saturated to +/-(4PU-1) BEFORE calling this routine */
  l_proportional_dpu = (int32_t)tPIsat_params->w_kp_pu * (int32_t)w_error_pu; /* (1) */
  /* saturate to +/-(4DPU-1), to allow for rescaling to single precision */
  l_proportional_dpu = sat_l(l_proportional_dpu, -FOUR_DPU_MINUS_1, FOUR_DPU_MINUS_1); /* (1) */

  /* calculate the integrator input term: error(k) * Kp * Ki [DPU] */
  l_temp_dpu = (int32_t)tPIsat_params->w_ki_pu * dtos(l_proportional_dpu); /* (2) */
  /* saturate to +/-(8DPU-1), to prevent the integrator from overflowing */
  l_temp_dpu = sat_l(l_temp_dpu, -EIGHT_DPU_MINUS_1, EIGHT_DPU_MINUS_1); /* (2) */

  /* calculate the integral term: error(k)*Kp*Ki*(1+1/z)/(1-1/z). Because the integrator
     is saturated between +/-(16DPU-1), this term is bounded between +/-24DPU */
  l_integral_dpu = l_temp_dpu + tPIsat_params->l_integrator_dpu; /* (3) */

  /* update the integrator: integrator(k) = integrator(k-1) + 2*error(k)*Kp*Ki
     as l_temp_DPU is saturated to +/-(8DPU-1) this fits into a long word
     if the integrator is limited to +/-(16DPU-1) */
  tPIsat_params->l_integrator_dpu = l_integral_dpu + l_temp_dpu; /* (4) */

  /* saturate the integrator to +/-16DPU */
  tPIsat_params->l_integrator_dpu = sat_l(tPIsat_params->l_integrator_dpu, stod(w_ll), stod(w_ul)); /* (4) */

  /* calculate the output term: proportional(k) + integral(k) [DPU]
     this is bounded between +/-28DPU */
  l_temp_dpu = l_proportional_dpu + l_integral_dpu; /* (5) */
  /* saturate the output term between the lower limit and the upper limit */
  l_temp_dpu = dtos(l_temp_dpu);
  l_temp_dpu = sat_w(l_temp_dpu, w_ll, w_ul);

  /* assign it to the output variable */
  return((int16_t)l_temp_dpu);
}
