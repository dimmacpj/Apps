/******************************************************************************

 FileName    : ena_datatype.h
 Title       :
 Author      : Arthur de Beun
 Created     : 2015 August 31

 Description : global typedefs


******************************************************************************/
#ifndef FILE_ENA_DATATYPE_H                     /* sentinel */
#define FILE_ENA_DATATYPE_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#include "cmsis_compiler.h"

typedef float float32_t;

/* PI controller operating states */
typedef enum
{
  PI_DISABLE,                               /* PI disabled, output = 0 */
  PI_INIT,                                  /* PI disabled, output = initial value */
  PI_HOLD,                                  /* PI disabled, output held constant */
  PI_NORMAL                                 /* PI operating normally */
} tPI_modes;

typedef struct                              /* saturating PI controller coefficients */
{
  volatile float32_t f_kp;                  /* proportional gain term */
  volatile float32_t f_ki;                  /* integral gain term */
  float32_t f_integrator;                   /* accumulator for discrete-time integrator */
} tPIsat;                                   /* floating point version */

typedef struct                              /* saturating PI controller coefficients */
{
  volatile int16_t w_kp_pu;                 /* proportional gain term */
  volatile int16_t w_ki_pu;                 /* integral gain term */
  int32_t l_integrator_dpu;                 /* accumulator for discrete-time integrator */
} tPIsat_i;                                 /* integer version */

typedef struct                              /* resonant controller coefficients */
{
  volatile float32_t f_kr;                  /* resonant gain term */
  volatile float32_t f_k2wc;                /* resonant Q term */
  float32_t f_u1_1;                         /* previous value of integrator 1 input */
  float32_t f_y1;                           /* integrator 1 (forward path) */
  float32_t f_y2;                           /* integrator 2 (feedback path) */
} tR;

/* type to facilitate use of QADD16 instruction on ADC results in DMA buffer */
typedef union
{
  int32_t l;
  uint32_t ul;
  uint16_t auw[2];
  int16_t aw[2];
  uint8_t aub[4];
  int8_t ab[4];
} u32_16_t;

/* message type */
typedef enum
{
  MESSAGE_READ,
  MESSAGE_WRITE,
  MESSAGE_WRITE_INIT,                       /* used when initialising from EEPROM */
} tMSG;

/* bit-banding macro */
#define BB(VarAddr, BitNumber) (*(VarAddr + BitNumber))

#endif                                      /* sentinel */

