/**************************************************************************//**
  \file   periph_bb.h
  \brief  bit-band access to peripherals
  \author Arthur de Beun
  \date   2018 May 16 (created)

  Add to this file as the need arises.
  Sorted alphabetically by peripheral name followed by register name, then by
  bit order. The general format is:
    BB_peripheral-name_register-name_bit-name

******************************************************************************/

#define PERIPH_BB(reg, bit) (*(volatile uint32_t*)(PERIPH_BB_BASE | (((uint32_t)&reg - PERIPH_BASE) << 5) | (bit * 4)))

/* CRC */
#define BB_CRC_CR_RESET (0)

/* DMA */
#define BB_DMA_CCR_EN (0)

/* FLASH */
#define BB_FLASH_CR_PG (0)                  /* programming */
#define BB_FLASH_CR_PER (1)                 /* page erase */
#define BB_FLASH_CR_MER (2)                 /* mass erase */
#define BB_FLASH_CR_STRT (16)               /* start, triggers erase */
#define BB_FLASH_CR_LOCK (31)               /* lock, locked when set */

#define BB_FLASH_SR_EOP (0)                 /* end of operation */
#define BB_FLASH_SR_OPERR (1)               /* operation error */
#define BB_FLASH_SR_PROGERR (3)             /* programming error */
#define BB_FLASH_SR_WRPERR (4)              /* write protection error */
#define BB_FLASH_SR_PGAERR (5)              /* page alignment error */
#define BB_FLASH_SR_SIZERR (6)              /* size error */
#define BB_FLASH_SR_PGSERR (7)              /* programming sequence error */
#define BB_FLASH_SR_MISERR (8)              /* fast programming data miss error */
#define BB_FLASH_SR_FASTERR (9)             /* fast programming error */
#define BB_FLASH_SR_RDERR (14)              /* protected read error */
#define BB_FLASH_SR_OPTVERR (15)            /* option validity error */
#define BB_FLASH_SR_BSY (16)                /* busy */

/* GPIO is not mapped to bit-banding region */

/* HRTIM */
#define BB_HRTIM_CPTnCR_SWCPT (0)          /* software capture */
#define BB_HRTIM_CPTnCR_UPDCPT (1)         /* update cature */
#define BB_HRTIM_CPTnCR_EXEV1CPT (2)       /* External event 1 capture */
#define BB_HRTIM_CPTnCR_EXEV2CPT (3)       /* External event 2 capture */
#define BB_HRTIM_CPTnCR_EXEV3CPT (4)       /* External event 3 capture */
#define BB_HRTIM_CPTnCR_EXEV4CPT (5)       /* External event 4 capture */
#define BB_HRTIM_CPTnCR_EXEV5CPT (6)       /* External event 5 capture */
#define BB_HRTIM_CPTnCR_EXEV6CPT (7)       /* External event 6 capture */
#define BB_HRTIM_CPTnCR_EXEV7CPT (8)       /* External event 7 capture */
#define BB_HRTIM_CPTnCR_EXEV8CPT (9)       /* External event 8 capture */
#define BB_HRTIM_CPTnCR_EXEV9CPT (10)      /* External event 9 capture */
#define BB_HRTIM_CPTnCR_EXEV10CPT (11)     /* External event 10 capture */
#define BB_HRTIM_CPTnCR_TA1SET (12)        /* Timer A output 1 set */
#define BB_HRTIM_CPTnCR_TA1RST (13)        /* Timer A output 1 reset */
#define BB_HRTIM_CPTnCR_TA1CMP1 (14)       /* Timer A compare 1 */
#define BB_HRTIM_CPTnCR_TA1CMP2 (15)       /* Timer A compare 2 */
#define BB_HRTIM_CPTnCR_TB1SET (16)        /* Timer B output 1 set */
#define BB_HRTIM_CPTnCR_TB1RST (17)        /* Timer B output 1 reset */
#define BB_HRTIM_CPTnCR_TB1CMP1 (18)       /* Timer B compare 1 */
#define BB_HRTIM_CPTnCR_TB1CMP2 (19)       /* Timer B compare 2 */
#define BB_HRTIM_CPTnCR_TC1SET (20)        /* Timer C output 1 set */
#define BB_HRTIM_CPTnCR_TC1RST (21)        /* Timer C output 1 reset */
#define BB_HRTIM_CPTnCR_TC1CMP1 (22)       /* Timer C compare 1 */
#define BB_HRTIM_CPTnCR_TC1CMP2 (23)       /* Timer C compare 2 */
#define BB_HRTIM_CPTnCR_TD1SET (24)        /* Timer D output 1 set */
#define BB_HRTIM_CPTnCR_TD1RST (25)        /* Timer D output 1 reset */
#define BB_HRTIM_CPTnCR_TD1CMP1 (26)       /* Timer D compare 1 */
#define BB_HRTIM_CPTnCR_TD1CMP2 (27)       /* Timer D compare 2 */
#define BB_HRTIM_CPTnCR_TE1SET (28)        /* Timer E output 1 set */
#define BB_HRTIM_CPTnCR_TE1RST (29)        /* Timer E output 1 reset */
#define BB_HRTIM_CPTnCR_TE1CMP1 (30)       /* Timer E compare 1 */
#define BB_HRTIM_CPTnCR_TE1CMP2 (31)       /* Timer E compare 2 */

#define BB_HRTIM_TIMxCR_TxRSTU (18)

#define BB_HRTIM_TIMxICR_CMP4C (3)         /* compare 4 interrupt clear flag */
#define BB_HRTIM_TIMxICR_UPDC (6)          /* update interrupt clear flag */
#define BB_HRTIM_TIMxICR_CPT1C (7)         /* capture 1 interrupt clear flag */
#define BB_HRTIM_TIMxICR_CPT2C (8)         /* capture 2 interrupt clear flag */

#define BB_HRTIM_TIMxISR_CMP4 (3)          /* compare 4 interrupt flag */
#define BB_HRTIM_TIMxISR_UPD (6)           /* update interrupt flag */
#define BB_HRTIM_TIMxISR_CPT1  (7)         /* capture 1 interrupt flag */
#define BB_HRTIM_TIMxISR_CPT2  (8)         /* capture 2 interrupt flag */

/* RCC */
#define BB_RCC_AHBENR_CRCEN (6)             /* CRC clock enable */

#define BB_RCC_APB2ENR_USART1EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_USART1EN_Pos))
#define BB_RCC_APB1ENR1_USART2EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_USART2EN_Pos))
#define BB_RCC_APB1ENR1_USART3EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_USART3EN_Pos))
#define BB_RCC_APB1ENR1_UART4EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_UART4EN_Pos))
#define BB_RCC_APB1ENR1_UART5EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_UART5EN_Pos))
#define BB_RCC_APB1ENR2_LPUART1EN (PERIPH_BB(RCC->APB1ENR2, RCC_APB1ENR2_LPUART1EN_Pos))

#define BB_RCC_APB1ENR1_I2C1EN  (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_I2C1EN_Pos))
#define BB_RCC_APB1ENR1_I2C2EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_I2C2EN_Pos))
#define BB_RCC_APB1ENR1_I2C3EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_I2C3EN_Pos))
#define BB_RCC_APB1ENR2_I2C4EN (PERIPH_BB(RCC->APB1ENR2, RCC_APB1ENR2_I2C4EN_Pos))

#define BB_RCC_APB2ENR_TIM1EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM1EN_Pos))
#define BB_RCC_APB1ENR1_TIM2EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM2EN_Pos))
#define BB_RCC_APB1ENR1_TIM3EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM3EN_Pos))
#define BB_RCC_APB1ENR1_TIM4EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM4EN_Pos))
#define BB_RCC_APB1ENR1_TIM5EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM5EN_Pos))
#define BB_RCC_APB1ENR1_TIM6EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM6EN_Pos))
#define BB_RCC_APB1ENR1_TIM7EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_TIM7EN_Pos))
#define BB_RCC_APB2ENR_TIM8EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM8EN_Pos))
#define BB_RCC_APB2ENR_TIM15EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM15EN_Pos))
#define BB_RCC_APB2ENR_TIM16EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM16EN_Pos))
#define BB_RCC_APB2ENR_TIM17EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM17EN_Pos))
#define BB_RCC_APB2ENR_TIM20EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_TIM20EN_Pos))
#define BB_RCC_APB1ENR1_LPTIM1EN (PERIPH_BB(RCC->APB1ENR1, RCC_APB1ENR1_LPTIM1EN_Pos))
#define BB_RCC_APB2ENR_HRTIM1EN (PERIPH_BB(RCC->APB2ENR, RCC_APB2ENR_HRTIM1EN_Pos))

#define BB_RCC_AHB2ENR_ADC12EN (PERIPH_BB(RCC->AHB2ENR, RCC_AHB2ENR_ADC12EN_Pos))
#define BB_RCC_AHB2ENR_ADC345EN (PERIPH_BB(RCC->AHB2ENR, RCC_AHB2ENR_ADC345EN_Pos))

#define BB_RCC_AHB2ENR_DAC3EN (PERIPH_BB(RCC->AHB2ENR, RCC_AHB2ENR_DAC3EN_Pos))


/* TIM */
#define BB_TIM_CR1_CEN (0)                  /* counter enable */

/* USART */
#define BB_USART_CR1_UE (0)                 /* USART enable */
#define BB_USART_CR1_TXEIE (7)              /* TXE interrupt enable */

#define BB_USART_CR3_DMAR (6)               /* DMA enable receiver */
#define BB_USART_CR3_DMAT (7)               /* DMA enable transmitter */

#define BB_USART_ISR_ORE (3)                /* overrun error */
#define BB_USART_ISR_RXNE (5)               /* read data register not empty */
#define BB_USART_ISR_TC (6)                 /* transmission complete */
#define BB_USART_ISR_TXE (7)                /* transmit data register empty */
#define BB_USART_ISR_RTOF (11)              /* receiver timeout */
