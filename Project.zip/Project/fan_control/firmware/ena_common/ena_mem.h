/**************************************************************************//**
  \file   ena_mem.h
  \brief  generic memory functions
  \author Joseph Cooper
  \date   2023 June 20 (created)


******************************************************************************/

#ifndef FILE_ENA_MEM_H /* sentinel */
#define FILE_ENA_MEM_H

#include <stdbool.h>
#include <stdint.h>

/* memcpy() with aligned word (32bit) and half-word (16bit) copies */
__STATIC_FORCEINLINE void ena_memcpy(volatile void* dst0, const volatile void* src0, uint32_t len0)
{
  volatile uint8_t *dst = dst0;
  const volatile uint8_t *src = src0;
  uint32_t len = len0;

  while(len != 0)
  {
    if(((((uintptr_t)dst | (uintptr_t)src) & (sizeof(uint32_t) - 1U)) != 0)
       && (len >= sizeof(uint32_t)))
    {
      /* 32bit aligned copy */
      *((volatile uint32_t*)dst) = *((const volatile uint32_t*)src);
      dst += sizeof(uint32_t);
      src += sizeof(uint32_t);
      len -= sizeof(uint32_t);
    }
    else if(((((uintptr_t)dst | (uintptr_t)src) & (sizeof(uint16_t) - 1U)) != 0)
            && (len >= sizeof(uint16_t)))
    {
      /* 16bit aligned copy */
      *((volatile uint16_t*)dst) = *((const volatile uint16_t*)src);
      dst += sizeof(uint16_t);
      src += sizeof(uint16_t);
      len -= sizeof(uint16_t);
    }
    else
    {
      *dst = *src;
      dst += 1;
      src += 1;
      len -= 1;
    }
  }
}

/* memcmp()  with aligned word (32bit) and half-word (16bit) compare
   returns true if the memory is different */
__STATIC_FORCEINLINE bool ena_memcmp(const void* m1, const void* m2, uint32_t len0)
{
  const uint8_t *s1 = (const uint8_t *) m1;
  const uint8_t *s2 = (const uint8_t *) m2;
  uint32_t len = len0;
  while(len != 0)
  {
    if(((((uintptr_t)s1 | (uintptr_t)s2) & (sizeof(uint32_t) - 1U)) != 0)
       && (len >= sizeof(uint32_t)))
    {
      /* 32bit aligned compare */
      if(*((const uint32_t*)s1) != *((const uint32_t*)s2))
      {
        break;
      }
      s1 += sizeof(uint32_t);
      s2 += sizeof(uint32_t);
      len -= sizeof(uint32_t);
    }
    else if(((((uintptr_t)s1 | (uintptr_t)s2) & (sizeof(uint16_t) - 1U)) != 0)
            && (len >= sizeof(uint16_t)))
    {
      /* 16bit aligned compare */
      if(*((const uint16_t*)s1) != *((const uint16_t*)s2))
      {
        break;
      }
      s1 += sizeof(uint16_t);
      s2 += sizeof(uint16_t);
      len -= sizeof(uint16_t);
    }
    else
    {
      if(*s1 != *s2)
      {
        break;
      }
      s1 += 1;
      s2 += 1;
      len -= 1;
    }
  }
  return (len >= 1);
}

#endif /* sentinel */
