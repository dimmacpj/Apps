/**************************************************************************//**
  \file   temperature.h
  \brief  convert ADC value to degrees C header file
  \author Arthur de Beun
  \date   2014 April 02 (created)

******************************************************************************/
#ifndef FILE_TEMPERATURE_H                  /* sentinel */
#define FILE_TEMPERATURE_H

#include "ena_datatype.h"

uint8_t ntc_lookup(uint16_t adc, float32_t* f_temperature);

#endif
