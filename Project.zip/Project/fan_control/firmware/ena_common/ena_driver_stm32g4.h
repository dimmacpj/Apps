/**************************************************************************//**
  \file   ena_driver_stm32g4.h
  \copyright Enatel

  \brief  STM32G4 drivers that are improvements or not proved by ST.

******************************************************************************/

#ifndef FILE_ENA_DRIVER_STM32G4_H /* sentinel */
#define FILE_ENA_DRIVER_STM32G4_H

#include "ena_datatype.h"
#include "stm32g4xx.h"                      // from CMSIS
#include "stm32g4xx_ll_gpio.h"

/**
  * Calls LL_GPIO_SetAFPin_0_7 or LL_GPIO_SetAFPin_8_15 based on pin.
  * See LL_GPIO_SetAFPin_0_7 and LL_GPIO_SetAFPin_8_15 for paramater information.
  */
__STATIC_FORCEINLINE void ena_gpio_set_af_pin(GPIO_TypeDef *gpio_x, const uint32_t pin, const uint32_t alternate)
{
  if(pin < LL_GPIO_PIN_8)
  {
    LL_GPIO_SetAFPin_0_7(gpio_x, pin, alternate);
  }
  else
  {
    LL_GPIO_SetAFPin_8_15(gpio_x, pin, alternate);
  }
}

#endif /* sentinel */
