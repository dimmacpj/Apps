/**************************************************************************//**
  \file   fan.h
  \brief  fan hardware setup
******************************************************************************/
#ifndef FILE_FAN_H                     /* sentinel */
#define FILE_FAN_H

#include "ena_datatype.h"

void set_fan_speed(const float32_t fan_speed);
uint32_t get_fan1_tacho(const uint16_t pulses_per_rev);
uint32_t get_fan2_tacho(const uint16_t pulses_per_rev);

void fan_hardware_init(void);

#endif                                      /* end sentinel */
