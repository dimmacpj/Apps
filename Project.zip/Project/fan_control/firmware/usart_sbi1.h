/**************************************************************************//**
  \file   usart_sbi1.h
  \brief  uart for sbi comms to monitor
******************************************************************************/
#ifndef FILE_USART_SBI1_H                    /* sentinel */
#define FILE_USART_SBI1_H

#include "stm32g4xx.h"                      // from CMSIS
#include "ena_datatype.h"
#include "periph_bb.h"

#include "hardware.h"
#include "sbi_buffer.h"

void uart_sbi1_init(void);

extern const t_hw_sbi *const  p_uart_sbi1_access;


#endif                                      /* sentinel */
