/**************************************************************************//**
 *
 * \file    : watchdog.h
 * \brief   : Watchdog
 * \details : Watchdog task and related functions
 * \authors : Kevin Vernon / Joseph Cooper
 * \date    : 2024 August 21 (created)
 *
 *****************************************************************************/

#ifndef FILE_WATCHDOG_H                         /* sentinel */
#define FILE_WATCHDOG_H

/*freeRTOS*/
#include "FreeRTOS.h"
#include "task.h"

#include "ena_datatype.h"

/* Global function prototypes */
portTASK_FUNCTION_PROTO(Watchdog_Task, pvParameters);

TaskHandle_t watchdog_task_create(void);

#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

/*Watchdog task handle */
EXTERN TaskHandle_t Watchdog_Task_Handle;

#undef EXTERN
#undef INIT

#endif                                      /* sentinel */
