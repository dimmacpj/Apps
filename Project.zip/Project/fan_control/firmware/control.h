/**************************************************************************//**
  \file   control.h
  \brief  control and monitoring of the Fan's task

******************************************************************************/
#ifndef FILE_CONTROL_H                      /* sentinel */
#define FILE_CONTROL_H

#include "ena_datatype.h"

enum
{
  FANS_OFF = 0,                              /* fans off */
  FANS_ON = 1,                               /* fans on */
};

/* global function prototypes */
portTASK_FUNCTION_PROTO(Control_Task, pvParameters);
TaskHandle_t control_task_create(void);

/* global variable definitions/declarations */
#ifdef DEFINE_VARS                          // definitions
#define EXTERN
#define INIT(x) = (x)
#else                                       // declarations
#define EXTERN extern
#define INIT(x)
#endif

EXTERN TaskHandle_t Control_Task_Handle;

EXTERN volatile uint16_t fan_pulses_per_rev;
EXTERN volatile uint16_t fan_min_rpm;
EXTERN volatile int16_t fan1_rpm;
EXTERN volatile int16_t fan2_rpm;
EXTERN volatile float32_t fan_speed_demand;
EXTERN volatile bool fans_on;


#undef EXTERN
#undef INIT

#endif                                      /* end sentinel */

