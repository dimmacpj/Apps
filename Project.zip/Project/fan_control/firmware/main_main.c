/******************************************************************************

 FileName    : main_main.c
 Title       :
 Author      : Arthur de Beun / Joseph Cooper
 Created     : 2023 August 25
 Company     : Enatel
 System      : GNU Tools for ARM Embedded Processors

 Description : resource allocation (also see hardware.h):

               The SysTick timer is used for FreeRTOS, tick rate in FreeRTOSConfig.h.

               Flash CRC calculation uses srecord
               http://srecord.sourceforge.net/
******************************************************************************/

/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"

#include <stdio.h>

#include "ena_datatype.h"

/* Hardware and board configuration */
#include "hardware.h"
#include "variants.h"

#include "control.h"
#include "db_table.h"
#include "eeprom.h"
#include "events.h"
#define DEFINE_VARS
#include "main_main.h"                      /* includes global variables */
#undef DEFINE_VARS
#include "sbi.h"
#include "usart_debug.h"
#include "version.h"
#include "watchdog.h"

#if ((__GNUC__  != 13) || (__GNUC_MINOR__  != 3) || (__GNUC_PATCHLEVEL__ != 1))
#warning "Not compiling with tested GCC version 13.3.1."
#endif

#if ((__NEWLIB__   != 4) || (__NEWLIB_MINOR__  != 4) || (__NEWLIB_PATCHLEVEL__ != 0))
#warning "Not using tested standard library newlib version 4.4.0."
#endif

#define SOFTWARE_ID (0x00)                  /* 8-bit value */
/* global constants */
const uint32_t __attribute__((section (".sw_time"))) sw_time = BUILD_TIME;
const uint32_t __attribute__((section (".sw_version"))) sw_version = (SOFTWARE_ID << 24) + (VERSION << 12) + BUILD_NUM;
const uint32_t __attribute__((section (".checksum"))) sw_checksum;

void main(void)
{
  /* Initialise the Embedded Flash Interface, the PLL and update the SystemCoreClock variable. */
  SystemInit();                             // system_stm32g4xx.c

  /* Interrupt priority: 4 bits for pre-emption priority, 0 bits for subpriority this is
     necessary for FreeRtos, see http://www.freertos.org/RTOS-Cortex-M3-M4.html */
  SCB->AIRCR = 0x05FA0000U | 0x300U;          // 4 bits for pre-emption priority, 0 bits for subpriority

  /* initialise bit-band pointers */
  event_init_bb_ptr();                   // pbb_alarms --> alarms

  hardware_init();

  printf("Rectifier start.\n");

  /* generate the power-on fault */
  BB(pbb_alarms, FLT_POWER_ON) = 1;

  Watchdog_Task_Handle = watchdog_task_create();
  SBI_Task_Handle = sbi_task_create();
  Eeprom_Task_Handle = eeprom_task_create();
  Control_Task_Handle = control_task_create();

  /* Suspend tasks until after the Eeprom_Task has initialised variables from EEPROM.
   These are started from the Eeprom_Task once initialisation from EEPROM is complete. */
  vTaskSuspend(Control_Task_Handle);
  vTaskSuspend(SBI_Task_Handle);

  /* Start the scheduler. */
  vTaskStartScheduler();
}

/*-----------------------------------------------------------*/
void vApplicationIdleHook( void )
{
  /* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
  to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
  task.  It is essential that code added to this hook function never attempts
  to block in any way (for example, call xQueueReceive() with a block time
  specified, or call vTaskDelay()).  If the application makes use of the
  vTaskDelete() API function (as this demo application does) then it is also
  important that vApplicationIdleHook() is permitted to return to its calling
  function, because it is the responsibility of the idle task to clean up
  memory allocated by the kernel to any task that has since been deleted. */
//  fv_LED_OK_on();
  __WFI();
//  fv_LED_OK_off();
}

/*-----------------------------------------------------------*/
void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
  ( void ) pcTaskName;
  ( void ) pxTask;

  /* Run time stack overflow checking is performed if
  configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
  function is called if a stack overflow is detected. */
  taskDISABLE_INTERRUPTS();
  for( ;; );
}

/*-----------------------------------------------------------*/

/* configSUPPORT_STATIC_ALLOCATION is set to 1, so the application must provide an
   implementation of vApplicationGetIdleTaskMemory() to provide the memory that is
   used by the Idle task. */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer,
                                    StackType_t **ppxIdleTaskStackBuffer,
                                    uint32_t *pulIdleTaskStackSize )
{
    /* If the buffers to be provided to the Idle task are declared inside this
       function then they must be declared static - otherwise they will be allocated on
       the stack and so not exists after this function exits. */
    static StaticTask_t xIdleTaskTCB;
    static StackType_t uxIdleTaskStack[ configMINIMAL_STACK_SIZE ];

    /* Pass out a pointer to the StaticTask_t structure in which the Idle task's
       state will be stored. */
    *ppxIdleTaskTCBBuffer = &xIdleTaskTCB;

    /* Pass out the array that will be used as the Idle task's stack. */
    *ppxIdleTaskStackBuffer = uxIdleTaskStack;

    /* Pass out the size of the array pointed to by *ppxIdleTaskStackBuffer.
       Note that, as the array is necessarily of type StackType_t,
       configMINIMAL_STACK_SIZE is specified in words, not bytes. */
    *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
}

/*-----------------------------------------------------------*/

/* configSUPPORT_STATIC_ALLOCATION and configUSE_TIMERS are both set to 1, so the
   application must provide an implementation of vApplicationGetTimerTaskMemory()
   to provide the memory that is used by the Timer service task. */
void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer,
                                     StackType_t **ppxTimerTaskStackBuffer,
                                     uint32_t *pulTimerTaskStackSize )
{
    /* If the buffers to be provided to the Timer task are declared inside this
       function then they must be declared static - otherwise they will be allocated on
       the stack and so not exists after this function exits. */
    static StaticTask_t xTimerTaskTCB;
    static StackType_t uxTimerTaskStack[ configTIMER_TASK_STACK_DEPTH ];

    /* Pass out a pointer to the StaticTask_t structure in which the Timer
       task's state will be stored. */
    *ppxTimerTaskTCBBuffer = &xTimerTaskTCB;

    /* Pass out the array that will be used as the Timer task's stack. */
    *ppxTimerTaskStackBuffer = uxTimerTaskStack;

    /* Pass out the size of the array pointed to by *ppxTimerTaskStackBuffer.
       Note that, as the array is necessarily of type StackType_t,
      configTIMER_TASK_STACK_DEPTH is specified in words, not bytes. */
    *pulTimerTaskStackSize = configTIMER_TASK_STACK_DEPTH;
}

